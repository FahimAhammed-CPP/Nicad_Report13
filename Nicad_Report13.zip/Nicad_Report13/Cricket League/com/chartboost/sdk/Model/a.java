package com.chartboost.sdk.Model;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.impl.g;
import com.chartboost.sdk.impl.j;
import com.chartboost.sdk.impl.t;
import com.chartboost.sdk.impl.w;
import java.util.Date;
import org.json.JSONObject;

public final class a {
  public JSONObject a;
  
  public Date b;
  
  public b c = b.a;
  
  public c d;
  
  public String e;
  
  public boolean f;
  
  public boolean g = false;
  
  public t h;
  
  public boolean i;
  
  public boolean j = false;
  
  public boolean k = false;
  
  public j l;
  
  private com.chartboost.sdk.c m;
  
  private a n;
  
  private Runnable o;
  
  private Runnable p;
  
  public a(c paramc, boolean paramBoolean1, String paramString, boolean paramBoolean2) {
    this.f = paramBoolean1;
    this.e = paramString;
    this.d = paramc;
    this.i = paramBoolean2;
  }
  
  public void a(CBError.CBImpressionError paramCBImpressionError) {
    if (this.m.d != null)
      this.m.d.a(paramCBImpressionError); 
  }
  
  public void a(Runnable paramRunnable) {
    this.o = paramRunnable;
  }
  
  public void a(JSONObject paramJSONObject, a parama) {
    JSONObject jSONObject = paramJSONObject;
    if (paramJSONObject == null)
      jSONObject = new JSONObject(); 
    this.a = jSONObject;
    this.b = new Date();
    this.c = b.a;
    this.n = parama;
    boolean bool = jSONObject.optString("type", "").equals("native");
    if (bool && this.d == c.a) {
      this.m = (com.chartboost.sdk.c)new com.chartboost.sdk.impl.a(this);
    } else if (bool && this.d == c.b) {
      this.m = (com.chartboost.sdk.c)new g(this);
    } else {
      this.m = (com.chartboost.sdk.c)new w(this);
    } 
    this.m.c = new com.chartboost.sdk.c.a(this, this) {
        public void a() {
          if (a.a(this.a) != null)
            a.a(this.a).a(this.a); 
        }
      };
    this.m.a = new com.chartboost.sdk.c.a(this, this) {
        public void a() {
          if (a.a(this.a) != null)
            a.a(this.a).b(this.a); 
        }
      };
    this.m.b = new com.chartboost.sdk.c.c(this, this) {
        public void a(a param1a, String param1String, JSONObject param1JSONObject) {
          if (param1a.c != a.b.c || param1a.k)
            return; 
          if (param1String == null)
            param1String = this.a.a.optString("link"); 
          String str2 = this.a.a.optString("deep-link");
          String str1 = param1String;
          if (str2 != null) {
            str1 = param1String;
            if (!str2.equals(""))
              try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str2));
                int i = Chartboost.sharedChartboost().getContext().getPackageManager().queryIntentActivities(intent, 65536).size();
                String str = param1String;
                if (i > 0)
                  str = str2; 
              } catch (Exception exception) {
                str1 = param1String;
              }  
          } 
          a.a(this.a).a(this.a, str1, param1JSONObject);
        }
      };
    this.m.d = new com.chartboost.sdk.c.d(this, this) {
        public void a(CBError.CBImpressionError param1CBImpressionError) {
          if (a.a(this.a) != null)
            a.a(this.a).a(this.a, param1CBImpressionError); 
        }
      };
    this.m.a(jSONObject);
  }
  
  public boolean a() {
    this.m.b();
    return (this.m.e() != null);
  }
  
  public void b() {
    c();
    if (this.m != null)
      this.m.d(); 
    this.m = null;
  }
  
  public void b(Runnable paramRunnable) {
    this.p = paramRunnable;
  }
  
  public void c() {
    if (this.h != null) {
      this.h.d();
      try {
        if (this.m.e().getParent() != null)
          this.h.removeView((View)this.m.e()); 
      } catch (Exception exception) {
        CBLogging.b("CBImpression", "Exception raised while cleaning up views", exception);
      } 
      this.h = null;
    } 
    if (this.m != null)
      this.m.f(); 
  }
  
  public CBError.CBImpressionError d() {
    return this.m.c();
  }
  
  public t.a e() {
    return (t.a)this.m.e();
  }
  
  public void f() {
    if (this.m != null && this.m.e() != null)
      this.m.e().setVisibility(8); 
    if (this.o != null) {
      this.o.run();
      this.o = null;
    } 
  }
  
  public void g() {
    this.k = true;
  }
  
  public void h() {
    if (this.p != null) {
      this.p.run();
      this.p = null;
    } 
    this.k = false;
    this.j = false;
  }
  
  public static interface a {
    void a(a param1a);
    
    void a(a param1a, CBError.CBImpressionError param1CBImpressionError);
    
    void a(a param1a, String param1String, JSONObject param1JSONObject);
    
    void b(a param1a);
  }
  
  public enum b {
    a, b, c, d, e, f, g;
  }
  
  public enum c {
    a, b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Model\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */