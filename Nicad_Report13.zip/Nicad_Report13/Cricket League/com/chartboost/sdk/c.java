package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.t;
import org.json.JSONObject;

public abstract class c {
  public a a = null;
  
  public c b = null;
  
  public a c = null;
  
  public d d = null;
  
  protected int e = 0;
  
  protected JSONObject f;
  
  protected a g;
  
  private int h;
  
  private int i;
  
  private int j;
  
  private b k;
  
  public c(a parama) {
    this.g = parama;
    this.k = null;
  }
  
  protected abstract b a(Context paramContext);
  
  public void a() {
    this.j++;
  }
  
  public void a(g paramg) {
    if (paramg != null && paramg.d())
      this.h++; 
    this.i++;
    if (this.i != this.e || b())
      return; 
    this.g.a(CBError.CBImpressionError.INTERNAL);
  }
  
  public void a(JSONObject paramJSONObject) {
    this.i = 0;
    this.j = 0;
    this.h = 0;
    this.f = paramJSONObject.optJSONObject("assets");
    if (this.f == null)
      this.g.a(CBError.CBImpressionError.INTERNAL); 
  }
  
  public boolean b() {
    if (this.h < this.j)
      return false; 
    if (this.c != null)
      this.c.a(); 
    return true;
  }
  
  public CBError.CBImpressionError c() {
    CBError.CBImpressionError cBImpressionError = null;
    Activity activity = Chartboost.sharedChartboost().c();
    if (activity == null) {
      this.k = null;
      return CBError.CBImpressionError.NO_HOST_ACTIVITY;
    } 
    this.k = a((Context)activity);
    if (!this.k.a(activity)) {
      this.k = null;
      return CBError.CBImpressionError.INTERNAL;
    } 
    return cBImpressionError;
  }
  
  public void d() {
    f();
    this.c = null;
    this.d = null;
    this.b = null;
    this.a = null;
  }
  
  public b e() {
    return this.k;
  }
  
  public void f() {
    if (this.k != null)
      this.k.c(); 
    this.k = null;
  }
  
  public JSONObject g() {
    return this.f;
  }
  
  public static interface a {
    void a();
  }
  
  public abstract class b extends RelativeLayout implements t.a {
    protected boolean a = false;
    
    public b(c this$0, Context param1Context) {
      super(param1Context);
      setFocusableInTouchMode(true);
      requestFocus();
      setOnTouchListener(new View.OnTouchListener(this, this$0) {
            public boolean onTouch(View param2View, MotionEvent param2MotionEvent) {
              return true;
            }
          });
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      try {
        a(param1Int1, param1Int2);
        return true;
      } catch (Exception exception) {
        CBLogging.b("CBViewProtocol", "Exception raised while layouting Subviews", exception);
        return false;
      } 
    }
    
    public void a() {
      a((Activity)getContext());
    }
    
    protected abstract void a(int param1Int1, int param1Int2);
    
    public boolean a(Activity param1Activity) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual getWidth : ()I
      //   4: istore #4
      //   6: aload_0
      //   7: invokevirtual getHeight : ()I
      //   10: istore_3
      //   11: iload #4
      //   13: ifeq -> 22
      //   16: iload_3
      //   17: istore_2
      //   18: iload_3
      //   19: ifne -> 64
      //   22: aload_1
      //   23: invokevirtual getWindow : ()Landroid/view/Window;
      //   26: ldc 16908290
      //   28: invokevirtual findViewById : (I)Landroid/view/View;
      //   31: astore #6
      //   33: aload #6
      //   35: astore #5
      //   37: aload #6
      //   39: ifnonnull -> 51
      //   42: aload_1
      //   43: invokevirtual getWindow : ()Landroid/view/Window;
      //   46: invokevirtual getDecorView : ()Landroid/view/View;
      //   49: astore #5
      //   51: aload #5
      //   53: invokevirtual getWidth : ()I
      //   56: istore #4
      //   58: aload #5
      //   60: invokevirtual getHeight : ()I
      //   63: istore_2
      //   64: iload #4
      //   66: ifeq -> 75
      //   69: iload_2
      //   70: istore_3
      //   71: iload_2
      //   72: ifne -> 111
      //   75: new android/util/DisplayMetrics
      //   78: dup
      //   79: invokespecial <init> : ()V
      //   82: astore #5
      //   84: aload_1
      //   85: invokevirtual getWindowManager : ()Landroid/view/WindowManager;
      //   88: invokeinterface getDefaultDisplay : ()Landroid/view/Display;
      //   93: aload #5
      //   95: invokevirtual getMetrics : (Landroid/util/DisplayMetrics;)V
      //   98: aload #5
      //   100: getfield widthPixels : I
      //   103: istore #4
      //   105: aload #5
      //   107: getfield heightPixels : I
      //   110: istore_3
      //   111: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
      //   114: invokevirtual getForcedOrientationDifference : ()Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
      //   117: invokevirtual isOdd : ()Z
      //   120: ifeq -> 141
      //   123: aload_0
      //   124: iload_3
      //   125: iload #4
      //   127: invokespecial b : (II)Z
      //   130: ireturn
      //   131: astore #5
      //   133: iconst_0
      //   134: istore_2
      //   135: iconst_0
      //   136: istore #4
      //   138: goto -> 64
      //   141: iload_3
      //   142: istore_2
      //   143: iload #4
      //   145: istore_3
      //   146: iload_2
      //   147: istore #4
      //   149: goto -> 123
      // Exception table:
      //   from	to	target	type
      //   0	11	131	java/lang/Exception
      //   22	33	131	java/lang/Exception
      //   42	51	131	java/lang/Exception
      //   51	64	131	java/lang/Exception
    }
    
    public View b() {
      return (View)this;
    }
    
    public void c() {}
    
    protected void onSizeChanged(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      super.onSizeChanged(param1Int1, param1Int2, param1Int3, param1Int4);
      if (this.a)
        return; 
      if (CBPreferences.getInstance().getForcedOrientationDifference().isOdd()) {
        b(param1Int2, param1Int1);
        return;
      } 
      b(param1Int1, param1Int2);
    }
  }
  
  class null implements View.OnTouchListener {
    null(c this$0, c param1c) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      return true;
    }
  }
  
  public static interface c {
    void a(a param1a, String param1String, JSONObject param1JSONObject);
  }
  
  public static interface d {
    void a(CBError.CBImpressionError param1CBImpressionError);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */