package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.i;
import com.chartboost.sdk.impl.j;
import com.chartboost.sdk.impl.m;
import com.chartboost.sdk.impl.t;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

final class a {
  private static a j;
  
  private Handler a;
  
  private Chartboost b;
  
  private CBPreferences c;
  
  private i d;
  
  private m e;
  
  private ArrayList<a> f = new ArrayList<a>();
  
  private a g = null;
  
  private Map<String, a> h;
  
  private a i;
  
  private a.a k = new a.a(this) {
      public void a(a param1a) {
        synchronized (this.a) {
          boolean bool = param1a.f;
          if (param1a.c == a.b.a) {
            param1a.c = a.b.b;
            if (bool) {
              if (param1a.d == a.c.a && param1a.e != null) {
                a.b(this.a).put(param1a.e, param1a);
                if (a.f(this.a).getDelegate() != null)
                  a.f(this.a).getDelegate().didCacheInterstitial(param1a.e); 
              } else if (param1a.d == a.c.b) {
                a.d(this.a, param1a);
                if (a.f(this.a).getDelegate() != null)
                  a.f(this.a).getDelegate().didCacheMoreApps(); 
              } 
              param1a.c = a.b.d;
            } 
          } 
          if (!bool)
            if (param1a.d == a.c.a) {
              a.a(this.a, param1a);
            } else if (param1a.d == a.c.b) {
              a.c(this.a, param1a);
            }  
          this.a.b(param1a);
          return;
        } 
      }
      
      public void a(a param1a, CBError.CBImpressionError param1CBImpressionError) {
        a.a(this.a, param1a, param1CBImpressionError);
      }
      
      public void a(a param1a, String param1String, JSONObject param1JSONObject) {
        boolean bool1;
        boolean bool3 = true;
        boolean bool2 = true;
        if (param1String != null && !param1String.equals("") && !param1String.equals("null")) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1a.d == a.c.a) {
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didDismissInterstitial(param1a.e); 
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didClickInterstitial(param1a.e); 
          if (param1a.c == a.b.c) {
            b b = a.a(this.a).a();
            if (b != null) {
              if (bool1)
                bool2 = false; 
              b.a(param1a, bool2);
            } 
          } 
        } else if (param1a.d == a.c.b) {
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didDismissMoreApps(); 
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didClickMoreApps(); 
          if (param1a.c == a.b.c) {
            b b = a.a(this.a).a();
            if (b != null) {
              if (!bool1) {
                bool2 = bool3;
              } else {
                bool2 = false;
              } 
              b.a(param1a, bool2);
            } 
          } 
        } 
        if (bool1) {
          Context context;
          j j = new j("api/click");
          Activity activity2 = a.a(this.a).c();
          Activity activity1 = activity2;
          if (activity2 == null)
            context = a.a(this.a).e(); 
          j.a(context);
          j.a(param1a.a, "to");
          j.a(param1a.a, "cgn");
          j.a(param1a.a, "creative");
          j.a(param1a.a, "ad_id");
          j.a(param1JSONObject, "cgn");
          j.a(param1JSONObject, "creative");
          j.a(param1JSONObject, "type");
          j.a(param1JSONObject, "more_type");
          param1a.l = j;
          param1a.c = a.b.f;
          a.a(this.a).a(param1a);
          a.b(this.a, param1a, param1String);
          return;
        } 
        a.e(this.a).a(param1a, false, param1String, CBError.CBClickError.URI_INVALID);
      }
      
      public void b(a param1a) {
        if (param1a.d == a.c.a) {
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didDismissInterstitial(param1a.e); 
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didCloseInterstitial(param1a.e); 
          if (param1a.c == a.b.c) {
            b b = a.a(this.a).a();
            if (b != null)
              b.a(param1a, true); 
          } 
          return;
        } 
        if (param1a.d == a.c.b) {
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didDismissMoreApps(); 
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didCloseMoreApps(); 
          if (param1a.c == a.b.c) {
            b b = a.a(this.a).a();
            if (b != null) {
              b.a(param1a, true);
              return;
            } 
          } 
        } 
      }
    };
  
  private m.a l = new m.a(this) {
      public void a(a param1a, boolean param1Boolean, String param1String, CBError.CBClickError param1CBClickError) {
        param1a.c = a.b.e;
        b b = a.a(this.a).a();
        if (b != null && b.a())
          b.a(true); 
        if (!param1Boolean) {
          if (a.f(this.a).getDelegate() != null)
            a.f(this.a).getDelegate().didFailToRecordClick(param1String, param1CBClickError); 
          return;
        } 
        if (param1a.l != null) {
          param1a.l.a(true);
          a.g(this.a).a(param1a.l, new i.b(this, param1a, param1String) {
                public void a(j param2j, CBError param2CBError) {
                  a.e(this.c.a).a(this.a, false, this.b, CBError.CBClickError.INTERNAL);
                }
                
                public void a(JSONObject param2JSONObject, j param2j) {}
              });
          return;
        } 
      }
    };
  
  private a(Chartboost paramChartboost) {
    this.b = paramChartboost;
    this.c = CBPreferences.getInstance();
    this.d = this.b.b;
    this.e = m.a(this.l);
    this.h = new HashMap<String, a>();
    this.i = null;
    this.a = new Handler();
  }
  
  protected static a a(Chartboost paramChartboost) {
    if (j == null)
      j = new a(paramChartboost); 
    return j;
  }
  
  private void a(a parama, CBError.CBImpressionError paramCBImpressionError) {
    b(parama);
    b b = this.b.a();
    if (parama.d == a.c.b && b != null && b.a())
      b.a(true); 
    if (parama.d == a.c.a && this.c.getDelegate() != null)
      this.c.getDelegate().didFailToLoadInterstitial(parama.e, paramCBImpressionError); 
    if (parama.d == a.c.b && this.c.getDelegate() != null)
      this.c.getDelegate().didFailToLoadMoreApps(paramCBImpressionError); 
  }
  
  private void a(a parama, String paramString) {
    Runnable runnable = new Runnable(this, parama, paramString) {
        public void run() {
          a.d(this.c).a(this.a, this.b, a.a(this.c).getHostActivity());
        }
      };
    b b = this.b.a();
    if (b != null && b.a) {
      parama.a(runnable);
      return;
    } 
    runnable.run();
  }
  
  private void a(JSONObject paramJSONObject, a parama) {
    if (paramJSONObject.optString("status", "").equals("404")) {
      a(parama, CBError.CBImpressionError.NO_AD_FOUND);
      return;
    } 
    if (!paramJSONObject.optString("status", "").equals("200")) {
      a(parama, CBError.CBImpressionError.INTERNAL);
      return;
    } 
    if (parama.d == a.c.b && !parama.f) {
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (this.b.a() != null) {
        bool1 = bool2;
        if (this.b.a().a())
          bool1 = true; 
      } 
      if (parama.i && !bool1) {
        b(parama);
        return;
      } 
    } 
    parama.a(paramJSONObject, this.k);
  }
  
  private void b(a parama, String paramString) {
    Chartboost.CBAgeGateConfirmation cBAgeGateConfirmation = new Chartboost.CBAgeGateConfirmation(this, parama, paramString) {
        public void execute(boolean param1Boolean) {
          Runnable runnable = new Runnable(this, param1Boolean) {
              public void run() {
                if (this.a) {
                  a.a(this.b.c, this.b.a, this.b.b);
                  return;
                } 
                a.e(this.b.c).a(this.b.a, false, this.b.b, CBError.CBClickError.AGE_GATE_FAILURE);
              }
            };
          a.a(this.c).a(runnable);
        }
      };
    if (this.c.getDelegate() == null || !this.c.getDelegate().shouldPauseClickForConfirmation(cBAgeGateConfirmation)) {
      a(parama, paramString);
      return;
    } 
    b b = this.b.a();
    if (b != null && b.a()) {
      b.a(true);
      return;
    } 
  }
  
  private void d(a parama) {
    String str;
    if (parama.c != a.b.c && this.c.getDelegate() != null && !this.c.getDelegate().shouldDisplayInterstitial(parama.e)) {
      b(parama);
      return;
    } 
    CBError.CBImpressionError cBImpressionError = null;
    JSONObject jSONObject = parama.a.optJSONObject("assets");
    if (jSONObject == null)
      cBImpressionError = CBError.CBImpressionError.INTERNAL; 
    if (this.c.getOrientation().isPortrait()) {
      str = "portrait";
    } else {
      str = "landscape";
    } 
    if (jSONObject.optJSONObject(String.format(Locale.US, "ad-%s", new Object[] { str })) == null || jSONObject.optJSONObject(String.format(Locale.US, "frame-%s", new Object[] { str })) == null)
      cBImpressionError = CBError.CBImpressionError.WRONG_ORIENTATION; 
    if (cBImpressionError != null) {
      a(parama, cBImpressionError);
      return;
    } 
    if ((parama.c == a.b.d || parama.g) && this.h.get(parama.e) == parama) {
      this.h.remove(parama.e);
      parama.f = false;
      j j = new j("api/show");
      j.a(this.b.e());
      str = parama.a.optString("ad_id");
      if (str != null)
        j.a("ad_id", str); 
      this.d.a(j);
    } 
    this.b.a(parama);
  }
  
  private void e(a parama) {
    boolean bool;
    if (parama.c != a.b.c && this.c.getDelegate() != null && !this.c.getDelegate().shouldDisplayMoreApps()) {
      b(parama);
      return;
    } 
    if (parama == this.i) {
      this.i = null;
      parama.f = false;
    } 
    if (parama.c == a.b.d) {
      bool = true;
    } else {
      bool = false;
    } 
    b b = this.b.a();
    if (b != null)
      if (b.a()) {
        b.a(false);
      } else if (parama.i && !bool && parama.c != a.b.c) {
        return;
      }  
    this.b.a(parama);
  }
  
  private void f(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   4: getfield d : Z
    //   7: ifne -> 19
    //   10: aload_0
    //   11: aload_1
    //   12: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.SESSION_NOT_STARTED : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   15: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   18: return
    //   19: aload_0
    //   20: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   23: invokevirtual a : ()Lcom/chartboost/sdk/b;
    //   26: astore_2
    //   27: aload_1
    //   28: getfield f : Z
    //   31: ifne -> 54
    //   34: aload_2
    //   35: ifnull -> 54
    //   38: aload_2
    //   39: invokevirtual b : ()Z
    //   42: ifeq -> 54
    //   45: aload_0
    //   46: aload_1
    //   47: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.IMPRESSION_ALREADY_VISIBLE : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   50: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   53: return
    //   54: aload_0
    //   55: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   58: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   61: ifnull -> 83
    //   64: aload_0
    //   65: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   68: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   71: aload_1
    //   72: getfield e : Ljava/lang/String;
    //   75: invokeinterface shouldRequestInterstitial : (Ljava/lang/String;)Z
    //   80: ifeq -> 18
    //   83: invokestatic a : ()Z
    //   86: ifne -> 98
    //   89: aload_0
    //   90: aload_1
    //   91: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.INTERNET_UNAVAILABLE : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   94: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   97: return
    //   98: aload_0
    //   99: monitorenter
    //   100: aload_0
    //   101: aload_1
    //   102: invokevirtual a : (Lcom/chartboost/sdk/Model/a;)Lcom/chartboost/sdk/Model/a;
    //   105: astore_2
    //   106: aload_2
    //   107: ifnull -> 153
    //   110: aload_1
    //   111: getfield f : Z
    //   114: ifne -> 142
    //   117: aload_2
    //   118: getfield f : Z
    //   121: ifeq -> 142
    //   124: aload_2
    //   125: iconst_0
    //   126: putfield f : Z
    //   129: aload_2
    //   130: iconst_1
    //   131: putfield g : Z
    //   134: aload_0
    //   135: monitorexit
    //   136: return
    //   137: astore_1
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_1
    //   141: athrow
    //   142: aload_0
    //   143: aload_1
    //   144: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.TOO_MANY_CONNECTIONS : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   147: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   150: aload_0
    //   151: monitorexit
    //   152: return
    //   153: aload_0
    //   154: aload_1
    //   155: invokevirtual c : (Lcom/chartboost/sdk/Model/a;)V
    //   158: aload_0
    //   159: monitorexit
    //   160: new com/chartboost/sdk/impl/j
    //   163: dup
    //   164: ldc_w 'api/get'
    //   167: invokespecial <init> : (Ljava/lang/String;)V
    //   170: astore_2
    //   171: aload_2
    //   172: aload_0
    //   173: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   176: invokevirtual e : ()Landroid/content/Context;
    //   179: invokevirtual a : (Landroid/content/Context;)V
    //   182: aload_2
    //   183: ldc_w 'location'
    //   186: aload_1
    //   187: getfield e : Ljava/lang/String;
    //   190: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   193: aload_1
    //   194: getfield f : Z
    //   197: ifeq -> 210
    //   200: aload_2
    //   201: ldc_w 'cache'
    //   204: ldc_w '1'
    //   207: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   210: aload_0
    //   211: getfield d : Lcom/chartboost/sdk/impl/i;
    //   214: aload_2
    //   215: new com/chartboost/sdk/a$5
    //   218: dup
    //   219: aload_0
    //   220: aload_1
    //   221: invokespecial <init> : (Lcom/chartboost/sdk/a;Lcom/chartboost/sdk/Model/a;)V
    //   224: invokevirtual a : (Lcom/chartboost/sdk/impl/j;Lcom/chartboost/sdk/impl/i$b;)V
    //   227: return
    // Exception table:
    //   from	to	target	type
    //   100	106	137	finally
    //   110	136	137	finally
    //   138	140	137	finally
    //   142	152	137	finally
    //   153	160	137	finally
  }
  
  protected a a() {
    t t;
    b b = this.b.a();
    if (b == null) {
      b = null;
    } else {
      t = b.c();
    } 
    return (t == null) ? null : t.h();
  }
  
  public a a(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   6: getstatic com/chartboost/sdk/Model/a$c.b : Lcom/chartboost/sdk/Model/a$c;
    //   9: if_acmpne -> 21
    //   12: aload_0
    //   13: getfield g : Lcom/chartboost/sdk/Model/a;
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: areturn
    //   21: aload_1
    //   22: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   25: getstatic com/chartboost/sdk/Model/a$c.a : Lcom/chartboost/sdk/Model/a$c;
    //   28: if_acmpne -> 136
    //   31: aload_1
    //   32: getfield e : Ljava/lang/String;
    //   35: ifnonnull -> 98
    //   38: ldc ''
    //   40: astore_1
    //   41: goto -> 146
    //   44: iload_2
    //   45: aload_0
    //   46: getfield f : Ljava/util/ArrayList;
    //   49: invokevirtual size : ()I
    //   52: if_icmpge -> 131
    //   55: aload_0
    //   56: getfield f : Ljava/util/ArrayList;
    //   59: iload_2
    //   60: invokevirtual get : (I)Ljava/lang/Object;
    //   63: checkcast com/chartboost/sdk/Model/a
    //   66: getfield e : Ljava/lang/String;
    //   69: ifnonnull -> 106
    //   72: ldc ''
    //   74: astore_3
    //   75: aload_1
    //   76: aload_3
    //   77: invokevirtual equals : (Ljava/lang/Object;)Z
    //   80: ifeq -> 124
    //   83: aload_0
    //   84: getfield f : Ljava/util/ArrayList;
    //   87: iload_2
    //   88: invokevirtual get : (I)Ljava/lang/Object;
    //   91: checkcast com/chartboost/sdk/Model/a
    //   94: astore_1
    //   95: goto -> 17
    //   98: aload_1
    //   99: getfield e : Ljava/lang/String;
    //   102: astore_1
    //   103: goto -> 146
    //   106: aload_0
    //   107: getfield f : Ljava/util/ArrayList;
    //   110: iload_2
    //   111: invokevirtual get : (I)Ljava/lang/Object;
    //   114: checkcast com/chartboost/sdk/Model/a
    //   117: getfield e : Ljava/lang/String;
    //   120: astore_3
    //   121: goto -> 75
    //   124: iload_2
    //   125: iconst_1
    //   126: iadd
    //   127: istore_2
    //   128: goto -> 44
    //   131: aconst_null
    //   132: astore_1
    //   133: goto -> 17
    //   136: aconst_null
    //   137: astore_1
    //   138: goto -> 17
    //   141: astore_1
    //   142: aload_0
    //   143: monitorexit
    //   144: aload_1
    //   145: athrow
    //   146: iconst_0
    //   147: istore_2
    //   148: goto -> 44
    // Exception table:
    //   from	to	target	type
    //   2	17	141	finally
    //   21	38	141	finally
    //   44	72	141	finally
    //   75	95	141	finally
    //   98	103	141	finally
    //   106	121	141	finally
  }
  
  public void a(Activity paramActivity, a parama) {
    if (parama != null) {
      switch (null.a[parama.c.ordinal()]) {
        default:
          return;
        case 1:
        case 2:
        case 3:
        case 4:
          if (parama.c != a.b.a || parama.i) {
            this.b.a(parama);
            return;
          } 
        case 5:
          break;
      } 
      if (!parama.a()) {
        b b = this.b.a();
        if (b != null) {
          CBLogging.b("CBImpressionManager", "Error onActivityStart " + parama.c.name());
          b.c(parama);
          return;
        } 
      } 
    } 
  }
  
  public void a(String paramString) {
    a a1 = new a(a.c.a, true, paramString, false);
    if (this.c.getDelegate() != null && !this.c.getDelegate().shouldRequestInterstitialsInFirstSession() && CBUtility.a().getInt("cbPrefSessionCount", 0) <= 1) {
      a(a1, CBError.CBImpressionError.FIRST_SESSION_INTERSTITIALS_DISABLED);
      return;
    } 
    f(a1);
  }
  
  protected void a(boolean paramBoolean) {
    // Byte code:
    //   0: new com/chartboost/sdk/Model/a
    //   3: dup
    //   4: getstatic com/chartboost/sdk/Model/a$c.b : Lcom/chartboost/sdk/Model/a$c;
    //   7: iload_1
    //   8: aconst_null
    //   9: iconst_0
    //   10: invokespecial <init> : (Lcom/chartboost/sdk/Model/a$c;ZLjava/lang/String;Z)V
    //   13: astore_2
    //   14: aload_0
    //   15: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   18: getfield d : Z
    //   21: ifne -> 33
    //   24: aload_0
    //   25: aload_2
    //   26: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.SESSION_NOT_STARTED : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   29: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   32: return
    //   33: aload_0
    //   34: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   37: invokevirtual a : ()Lcom/chartboost/sdk/b;
    //   40: astore_3
    //   41: iload_1
    //   42: ifne -> 65
    //   45: aload_3
    //   46: ifnull -> 65
    //   49: aload_3
    //   50: invokevirtual b : ()Z
    //   53: ifeq -> 65
    //   56: aload_0
    //   57: aload_2
    //   58: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.IMPRESSION_ALREADY_VISIBLE : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   61: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   64: return
    //   65: aload_0
    //   66: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   69: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   72: ifnull -> 90
    //   75: aload_0
    //   76: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   79: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   82: invokeinterface shouldRequestMoreApps : ()Z
    //   87: ifeq -> 32
    //   90: invokestatic a : ()Z
    //   93: ifne -> 105
    //   96: aload_0
    //   97: aload_2
    //   98: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.INTERNET_UNAVAILABLE : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   101: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   104: return
    //   105: aload_0
    //   106: monitorenter
    //   107: aload_0
    //   108: aload_2
    //   109: invokevirtual a : (Lcom/chartboost/sdk/Model/a;)Lcom/chartboost/sdk/Model/a;
    //   112: astore_3
    //   113: aload_3
    //   114: ifnull -> 157
    //   117: iload_1
    //   118: ifne -> 146
    //   121: aload_3
    //   122: getfield f : Z
    //   125: ifeq -> 146
    //   128: aload_3
    //   129: iconst_0
    //   130: putfield f : Z
    //   133: aload_3
    //   134: iconst_1
    //   135: putfield g : Z
    //   138: aload_0
    //   139: monitorexit
    //   140: return
    //   141: astore_2
    //   142: aload_0
    //   143: monitorexit
    //   144: aload_2
    //   145: athrow
    //   146: aload_0
    //   147: aload_2
    //   148: getstatic com/chartboost/sdk/Model/CBError$CBImpressionError.TOO_MANY_CONNECTIONS : Lcom/chartboost/sdk/Model/CBError$CBImpressionError;
    //   151: invokespecial a : (Lcom/chartboost/sdk/Model/a;Lcom/chartboost/sdk/Model/CBError$CBImpressionError;)V
    //   154: aload_0
    //   155: monitorexit
    //   156: return
    //   157: aload_0
    //   158: aload_2
    //   159: invokevirtual c : (Lcom/chartboost/sdk/Model/a;)V
    //   162: aload_0
    //   163: monitorexit
    //   164: iload_1
    //   165: ifne -> 206
    //   168: aload_0
    //   169: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   172: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   175: ifnull -> 193
    //   178: aload_0
    //   179: getfield c : Lcom/chartboost/sdk/CBPreferences;
    //   182: invokevirtual getDelegate : ()Lcom/chartboost/sdk/ChartboostDelegate;
    //   185: invokeinterface shouldDisplayLoadingViewForMoreApps : ()Z
    //   190: ifeq -> 206
    //   193: aload_2
    //   194: iconst_1
    //   195: putfield i : Z
    //   198: aload_0
    //   199: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   202: aload_2
    //   203: invokevirtual a : (Lcom/chartboost/sdk/Model/a;)V
    //   206: new com/chartboost/sdk/impl/j
    //   209: dup
    //   210: ldc_w 'api/more'
    //   213: invokespecial <init> : (Ljava/lang/String;)V
    //   216: astore_3
    //   217: aload_3
    //   218: aload_0
    //   219: getfield b : Lcom/chartboost/sdk/Chartboost;
    //   222: invokevirtual e : ()Landroid/content/Context;
    //   225: invokevirtual a : (Landroid/content/Context;)V
    //   228: iload_1
    //   229: ifeq -> 242
    //   232: aload_3
    //   233: ldc_w 'cache'
    //   236: ldc_w '1'
    //   239: invokevirtual a : (Ljava/lang/String;Ljava/lang/Object;)V
    //   242: aload_0
    //   243: getfield d : Lcom/chartboost/sdk/impl/i;
    //   246: aload_3
    //   247: new com/chartboost/sdk/a$6
    //   250: dup
    //   251: aload_0
    //   252: aload_2
    //   253: invokespecial <init> : (Lcom/chartboost/sdk/a;Lcom/chartboost/sdk/Model/a;)V
    //   256: invokevirtual a : (Lcom/chartboost/sdk/impl/j;Lcom/chartboost/sdk/impl/i$b;)V
    //   259: return
    // Exception table:
    //   from	to	target	type
    //   107	113	141	finally
    //   121	140	141	finally
    //   142	144	141	finally
    //   146	156	141	finally
    //   157	164	141	finally
  }
  
  protected void b() {
    this.a.post(new Runnable(this) {
          public void run() {
            if (a.c(this.a) != null) {
              a.c(this.a, a.c(this.a));
              return;
            } 
            this.a.a(false);
          }
        });
  }
  
  public void b(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   6: getstatic com/chartboost/sdk/Model/a$c.b : Lcom/chartboost/sdk/Model/a$c;
    //   9: if_acmpne -> 20
    //   12: aload_0
    //   13: aconst_null
    //   14: putfield g : Lcom/chartboost/sdk/Model/a;
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_1
    //   21: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   24: getstatic com/chartboost/sdk/Model/a$c.a : Lcom/chartboost/sdk/Model/a$c;
    //   27: if_acmpne -> 17
    //   30: aload_0
    //   31: aload_1
    //   32: invokevirtual a : (Lcom/chartboost/sdk/Model/a;)Lcom/chartboost/sdk/Model/a;
    //   35: astore_1
    //   36: aload_1
    //   37: ifnull -> 17
    //   40: aload_0
    //   41: getfield f : Ljava/util/ArrayList;
    //   44: aload_1
    //   45: invokevirtual remove : (Ljava/lang/Object;)Z
    //   48: pop
    //   49: goto -> 17
    //   52: astore_1
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	52	finally
    //   20	36	52	finally
    //   40	49	52	finally
  }
  
  protected void b(String paramString) {
    a a1 = new a(a.c.a, false, paramString, false);
    if (this.c.getDelegate() != null && !this.c.getDelegate().shouldRequestInterstitialsInFirstSession() && CBUtility.a().getInt("cbPrefSessionCount", 0) == 1) {
      a(a1, CBError.CBImpressionError.FIRST_SESSION_INTERSTITIALS_DISABLED);
      return;
    } 
    this.a.post(new Runnable(this, paramString, a1) {
          public void run() {
            if (a.a(this.c).hasCachedInterstitial(this.a)) {
              a.a(this.c, (a)a.b(this.c).get(this.a));
              return;
            } 
            a.b(this.c, this.b);
          }
        });
  }
  
  public void c(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   6: getstatic com/chartboost/sdk/Model/a$c.b : Lcom/chartboost/sdk/Model/a$c;
    //   9: if_acmpne -> 20
    //   12: aload_0
    //   13: aload_1
    //   14: putfield g : Lcom/chartboost/sdk/Model/a;
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_1
    //   21: getfield d : Lcom/chartboost/sdk/Model/a$c;
    //   24: getstatic com/chartboost/sdk/Model/a$c.a : Lcom/chartboost/sdk/Model/a$c;
    //   27: if_acmpne -> 17
    //   30: aload_0
    //   31: getfield f : Ljava/util/ArrayList;
    //   34: aload_1
    //   35: invokevirtual add : (Ljava/lang/Object;)Z
    //   38: pop
    //   39: goto -> 17
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	42	finally
    //   20	39	42	finally
  }
  
  protected boolean c() {
    return (this.i != null);
  }
  
  protected boolean c(String paramString) {
    a a1 = this.h.get(paramString);
    return (a1 == null) ? false : ((TimeUnit.MILLISECONDS.toSeconds((new Date()).getTime() - a1.b.getTime()) < 86400L));
  }
  
  protected boolean d() {
    if (a() == null)
      return false; 
    this.k.b(a());
    return true;
  }
  
  protected void e() {
    this.h.clear();
    this.i = null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */