package com.chartboost.sdk;

import com.chartboost.sdk.Model.CBError;

public interface ChartboostDelegate {
  void didCacheInterstitial(String paramString);
  
  void didCacheMoreApps();
  
  void didClickInterstitial(String paramString);
  
  void didClickMoreApps();
  
  void didCloseInterstitial(String paramString);
  
  void didCloseMoreApps();
  
  void didDismissInterstitial(String paramString);
  
  void didDismissMoreApps();
  
  void didFailToLoadInterstitial(String paramString, CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToLoadMoreApps(CBError.CBImpressionError paramCBImpressionError);
  
  void didFailToRecordClick(String paramString, CBError.CBClickError paramCBClickError);
  
  void didShowInterstitial(String paramString);
  
  void didShowMoreApps();
  
  boolean shouldDisplayInterstitial(String paramString);
  
  boolean shouldDisplayLoadingViewForMoreApps();
  
  boolean shouldDisplayMoreApps();
  
  boolean shouldPauseClickForConfirmation(Chartboost.CBAgeGateConfirmation paramCBAgeGateConfirmation);
  
  boolean shouldRequestInterstitial(String paramString);
  
  boolean shouldRequestInterstitialsInFirstSession();
  
  boolean shouldRequestMoreApps();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\ChartboostDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */