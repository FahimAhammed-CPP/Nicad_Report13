package com.chartboost.sdk;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.util.SparseBooleanArray;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.c;
import com.chartboost.sdk.Libraries.f;
import com.chartboost.sdk.Libraries.h;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.i;
import com.chartboost.sdk.impl.j;
import com.chartboost.sdk.impl.n;
import java.util.Locale;
import org.json.JSONObject;

public final class Chartboost {
  private static volatile Chartboost e = null;
  
  protected h a = null;
  
  protected i b;
  
  protected Handler c;
  
  protected boolean d = false;
  
  private Context f = null;
  
  private CBImpressionActivity g = null;
  
  private a h;
  
  private a i = null;
  
  private CBPreferences j = null;
  
  private boolean k = false;
  
  private SparseBooleanArray l = new SparseBooleanArray();
  
  private b m = null;
  
  private long n = 0L;
  
  private long o = 0L;
  
  private boolean p = false;
  
  private Runnable q = new a();
  
  private Chartboost() {
    e = this;
    this.c = new Handler();
    this.b = new i(null, "main");
    this.h = a.a(this);
    this.m = b.a(this);
    this.j = CBPreferences.getInstance();
  }
  
  private void a(int paramInt, boolean paramBoolean) {
    this.l.put(paramInt, paramBoolean);
  }
  
  private void a(Activity paramActivity, String paramString1, String paramString2, ChartboostDelegate paramChartboostDelegate) {
    if (!this.j.getIgnoreErrors() && !CBUtility.b())
      throw new IllegalStateException("It is illegal to call this method from any thread other than the UI thread. Please call it from the onCreate() method of your host activity."); 
    if (this.a != null && !this.a.b(paramActivity) && f()) {
      b(this.a);
      a(this.a, false);
    } 
    this.c.removeCallbacks(this.q);
    this.a = h.a(paramActivity);
    this.f = paramActivity.getApplicationContext();
    c.a();
    this.j.setAppID(paramString1);
    this.j.setAppSignature(paramString2);
    this.j.setDelegate(paramChartboostDelegate);
    this.b.b();
  }
  
  private void a(Activity paramActivity, boolean paramBoolean) {
    if (paramActivity == null)
      return; 
    a(paramActivity.hashCode(), paramBoolean);
  }
  
  private void a(h paramh, boolean paramBoolean) {
    if (paramh == null)
      return; 
    a(paramh.a(), paramBoolean);
  }
  
  private void b(h paramh) {
    if (!this.j.getImpressionsUseActivities())
      c(paramh); 
    if (!(paramh.get() instanceof CBImpressionActivity))
      a(paramh, false); 
    this.n = (long)(System.nanoTime() / 1000000.0D);
  }
  
  private void b(h paramh, boolean paramBoolean) {}
  
  private void c(h paramh) {
    b b1 = a();
    if (d(paramh) && b1 != null) {
      a a1 = this.h.a();
      if (a1 != null) {
        b1.b(a1);
        this.i = a1;
      } 
      b(paramh, false);
      if (paramh.get() instanceof CBImpressionActivity)
        d(); 
    } 
    if (!(paramh.get() instanceof CBImpressionActivity))
      a(paramh, false); 
  }
  
  private void cacheInterstitialData(String paramString, CBAPIResponseCallback paramCBAPIResponseCallback) {
    d.a(paramString, paramCBAPIResponseCallback);
  }
  
  private void cacheInterstitialDataBatch(String paramString, int paramInt, CBAPIResponseCallback paramCBAPIResponseCallback) {
    d.a(paramString, paramInt, paramCBAPIResponseCallback);
  }
  
  private boolean d(Activity paramActivity) {
    return this.j.getImpressionsUseActivities() ? (!(this.g != paramActivity)) : ((this.a == null) ? (!(paramActivity != null)) : this.a.b(paramActivity));
  }
  
  private boolean d(h paramh) {
    return this.j.getImpressionsUseActivities() ? ((paramh == null) ? (!(this.g != null)) : paramh.b(this.g)) : ((this.a == null) ? (!(paramh != null)) : this.a.a(paramh));
  }
  
  private boolean f() {
    return a(this.a);
  }
  
  public static Chartboost sharedChartboost() {
    // Byte code:
    //   0: getstatic com/chartboost/sdk/Chartboost.e : Lcom/chartboost/sdk/Chartboost;
    //   3: ifnonnull -> 28
    //   6: ldc com/chartboost/sdk/Chartboost
    //   8: monitorenter
    //   9: getstatic com/chartboost/sdk/Chartboost.e : Lcom/chartboost/sdk/Chartboost;
    //   12: ifnonnull -> 25
    //   15: new com/chartboost/sdk/Chartboost
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/chartboost/sdk/Chartboost.e : Lcom/chartboost/sdk/Chartboost;
    //   25: ldc com/chartboost/sdk/Chartboost
    //   27: monitorexit
    //   28: getstatic com/chartboost/sdk/Chartboost.e : Lcom/chartboost/sdk/Chartboost;
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/chartboost/sdk/Chartboost
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   9	25	32	finally
    //   25	28	32	finally
    //   33	36	32	finally
  }
  
  private void showInterstitialData(String paramString, CBAPIResponseCallback paramCBAPIResponseCallback) {
    d.b(paramString, paramCBAPIResponseCallback);
  }
  
  protected b a() {
    return (c() == null) ? null : this.m;
  }
  
  protected void a(Activity paramActivity) {
    this.f = paramActivity.getApplicationContext();
    if (!(paramActivity instanceof CBImpressionActivity)) {
      this.a = h.a(paramActivity);
      a(this.a, true);
    } else {
      a((CBImpressionActivity)paramActivity);
    } 
    this.c.removeCallbacks(this.q);
    if (paramActivity == null || !d(paramActivity))
      return; 
    b(h.a(paramActivity), true);
    if (paramActivity instanceof CBImpressionActivity)
      this.p = false; 
    this.h.a(paramActivity, this.i);
    this.i = null;
  }
  
  protected void a(CBImpressionActivity paramCBImpressionActivity) {
    if (!this.k) {
      this.f = paramCBImpressionActivity.getApplicationContext();
      this.g = paramCBImpressionActivity;
      this.k = true;
    } 
    this.c.removeCallbacks(this.q);
  }
  
  protected void a(a parama) {
    boolean bool = true;
    if (this.j.getImpressionsUseActivities()) {
      boolean bool1;
      boolean bool2;
      if (this.k) {
        b b2 = a();
        if (c() != null && b2 != null) {
          b2.a(parama);
          return;
        } 
        CBLogging.b("Chartboost", "Missing CBViewController to manage the open CBImpressionActivity");
        return;
      } 
      if (!f()) {
        parama.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
        return;
      } 
      Activity activity = getHostActivity();
      if (activity == null) {
        CBLogging.b("Chartboost", "Failed to display impression as the host activity reference has been lost!");
        parama.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
        return;
      } 
      if (this.i != null && this.i != parama) {
        parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
        return;
      } 
      this.i = parama;
      Intent intent = new Intent((Context)activity, CBImpressionActivity.class);
      if (((activity.getWindow().getAttributes()).flags & 0x400) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (((activity.getWindow().getAttributes()).flags & 0x800) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (!bool1 || bool2)
        bool = false; 
      intent.putExtra("paramFullscreen", bool);
      try {
        activity.startActivity(intent);
        this.p = true;
        return;
      } catch (ActivityNotFoundException activityNotFoundException) {
        throw new RuntimeException("Chartboost impression activity not declared in manifest. Please add the following inside your manifest's <application> tag: \n<activity android:name=\"com.chartboost.sdk.CBImpressionActivity\" android:theme=\"@android:style/Theme.Translucent.NoTitleBar\" android:excludeFromRecents=\"true\" />");
      } 
    } 
    b b1 = a();
    if (b1 != null && f()) {
      b1.a((a)activityNotFoundException);
      return;
    } 
    activityNotFoundException.a(CBError.CBImpressionError.NO_HOST_ACTIVITY);
  }
  
  protected void a(Runnable paramRunnable) {
    if (!CBUtility.b()) {
      this.c.post(paramRunnable);
      return;
    } 
    paramRunnable.run();
  }
  
  protected boolean a(h paramh) {
    if (paramh != null) {
      Boolean bool = Boolean.valueOf(this.l.get(paramh.a()));
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return false;
  }
  
  protected void b(Activity paramActivity) {
    c(h.a(paramActivity));
  }
  
  protected boolean b() {
    if (this.h.a() != null && (this.h.a()).c == a.b.c) {
      a(new Runnable(this) {
            public void run() {
              Chartboost.a(this.a).d();
            }
          });
      return true;
    } 
    b b1 = a();
    if (b1 != null && b1.a()) {
      a(new Runnable(this, b1) {
            public void run() {
              this.a.a(true);
            }
          });
      return true;
    } 
    return false;
  }
  
  protected Activity c() {
    return this.j.getImpressionsUseActivities() ? this.g : getHostActivity();
  }
  
  protected void c(Activity paramActivity) {
    b(h.a(paramActivity), false);
  }
  
  public void cacheInterstitial() {
    cacheInterstitial("Default");
  }
  
  public void cacheInterstitial(String paramString) {
    if (this.a == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling cacheInterstitial()."); 
    this.h.a(paramString);
  }
  
  public void cacheMoreApps() {
    if (this.a == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling cacheMoreApps()."); 
    this.h.a(true);
  }
  
  public void clearCache() {
    this.h.e();
  }
  
  public void clearImageCache() {
    if (getContext() == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling clearImageCache()."); 
    n.a().b();
  }
  
  protected void d() {
    if (this.k) {
      this.g = null;
      this.k = false;
    } 
  }
  
  protected Context e() {
    return (this.a != null) ? this.a.b() : getContext();
  }
  
  public Context getContext() {
    return this.f;
  }
  
  public String getDeviceIdentifier() {
    return c.b();
  }
  
  protected Activity getHostActivity() {
    return (this.a != null) ? (Activity)this.a.get() : null;
  }
  
  public CBPreferences getPreferences() {
    return this.j;
  }
  
  public boolean hasCachedInterstitial() {
    return hasCachedInterstitial("Default");
  }
  
  public boolean hasCachedInterstitial(String paramString) {
    return this.h.c(paramString);
  }
  
  public boolean hasCachedMoreApps() {
    return this.h.c();
  }
  
  public boolean onBackPressed() {
    boolean bool = false;
    if (!this.j.getIgnoreErrors() && !CBUtility.b())
      throw new IllegalStateException("It is illegal to call this method from any thread other than the UI thread. Please call it from the onBackPressed() method of your host activity."); 
    if (this.a == null)
      throw new IllegalStateException("The Chartboost methods onCreate(), onStart(), onStop(), and onDestroy() must be called in the corresponding methods of your activity in order for Chartboost to function properly."); 
    if (this.j.getImpressionsUseActivities()) {
      if (this.p) {
        this.p = false;
        b();
        bool = true;
      } 
      return bool;
    } 
    return b();
  }
  
  public void onCreate(Activity paramActivity, String paramString1, String paramString2, ChartboostDelegate paramChartboostDelegate) {
    a(paramActivity, paramString1, paramString2, paramChartboostDelegate);
  }
  
  public void onDestroy(Activity paramActivity) {
    if (this.a == null || this.a.b(paramActivity)) {
      this.c.removeCallbacks(this.q);
      this.q = new a();
      this.c.postDelayed(this.q, 10000L);
    } 
    c(paramActivity);
  }
  
  public void onStart(Activity paramActivity) {
    if (!this.j.getIgnoreErrors() && !CBUtility.b())
      throw new IllegalStateException("It is illegal to call this method from any thread other than the UI thread. Please call it from the onStart() method of your host activity."); 
    this.c.removeCallbacks(this.q);
    if (this.a != null && !this.a.b(paramActivity) && f()) {
      b(this.a);
      a(this.a, false);
    } 
    a(paramActivity, true);
    this.a = h.a(paramActivity);
    this.f = paramActivity.getApplicationContext();
    if (!this.j.getImpressionsUseActivities())
      a(paramActivity); 
  }
  
  public void onStop(Activity paramActivity) {
    if (!this.j.getIgnoreErrors() && !CBUtility.b())
      throw new IllegalStateException("It is illegal to call this method from any thread other than the UI thread. Please call it from the onStop() method of your host activity."); 
    h h1 = h.a(paramActivity);
    if (a(h1))
      b(h1); 
  }
  
  public void showInterstitial() {
    showInterstitial("Default");
  }
  
  public void showInterstitial(String paramString) {
    if (this.a == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling showInterstitial()."); 
    this.h.b(paramString);
  }
  
  public void showMoreApps() {
    if (this.a == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling showMoreApps()."); 
    this.h.b();
  }
  
  public void showMoreAppsData(CBAPIResponseCallback paramCBAPIResponseCallback) {
    d.a(paramCBAPIResponseCallback);
  }
  
  public void startSession() {
    if (this.a == null)
      throw new IllegalStateException("The context must be set through the Chartboost method onCreate() before calling startSession()."); 
    this.d = true;
    long l = (long)(System.nanoTime() / 1000000.0D);
    if (l - this.n >= 10000L && l - this.o >= 60000L) {
      this.o = l;
      SharedPreferences sharedPreferences = CBUtility.a();
      int j = sharedPreferences.getInt("cbPrefSessionCount", 0);
      SharedPreferences.Editor editor = sharedPreferences.edit();
      editor.putInt("cbPrefSessionCount", j + 1);
      editor.commit();
      j j1 = new j("api/install");
      j1.a(e());
      j1.a(new f.g[] { f.a("status", i.a) });
      this.b.a(j1, (i.b)new i.c(this) {
            public void a(JSONObject param1JSONObject, j param1j) {
              if (CBUtility.a(this.a.getContext())) {
                String str = param1JSONObject.optString("latest-sdk-version");
                if (str != null && !str.equals("") && !str.equals("4.0.1"))
                  CBLogging.a(String.format(Locale.US, "Chartboost SDK is not up to date. (Current: %s, Latest: %s)\n Download latest SDK at:\n\thttps://www.chartboost.com/support/sdk_download/?os=ios", new Object[] { "4.0.1", str })); 
              } 
            }
          });
      return;
    } 
  }
  
  public static interface CBAPIResponseCallback {
    void onFailure(CBError.CBImpressionError param1CBImpressionError);
    
    void onSuccess(JSONObject param1JSONObject);
  }
  
  public static interface CBAgeGateConfirmation {
    void execute(boolean param1Boolean);
  }
  
  private class a implements Runnable {
    private int b;
    
    private int c;
    
    private int d;
    
    private a(Chartboost this$0) {
      int i;
      ChartboostDelegate chartboostDelegate = a();
      if (Chartboost.c(Chartboost.this) == null) {
        i = -1;
      } else {
        i = Chartboost.c(Chartboost.this).hashCode();
      } 
      this.b = i;
      if (Chartboost.this.a == null) {
        i = -1;
      } else {
        i = Chartboost.this.a.hashCode();
      } 
      this.c = i;
      if (chartboostDelegate == null) {
        i = b;
      } else {
        i = chartboostDelegate.hashCode();
      } 
      this.d = i;
    }
    
    private ChartboostDelegate a() {
      return (Chartboost.b(this.a) != null) ? Chartboost.b(this.a).getDelegate() : null;
    }
    
    public void run() {
      ChartboostDelegate chartboostDelegate = a();
      if (this.a.getContext() != null)
        this.a.clearImageCache(); 
      if (this.a.a != null && this.a.a.hashCode() == this.c)
        this.a.a = null; 
      if (Chartboost.c(this.a) != null && Chartboost.c(this.a).hashCode() == this.b)
        Chartboost.a(this.a, (CBImpressionActivity)null); 
      if (chartboostDelegate != null && chartboostDelegate.hashCode() == this.d)
        Chartboost.b(this.a).setDelegate(null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Chartboost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */