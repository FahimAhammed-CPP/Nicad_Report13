package com.chartboost.sdk.impl;

import java.io.Serializable;

public class bc implements Serializable {
  public boolean equals(Object paramObject) {
    return paramObject instanceof bc;
  }
  
  public int hashCode() {
    return 0;
  }
  
  public String toString() {
    return "MinKey";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */