package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBOrientation;

public final class s extends LinearLayout implements t.a {
  private TextView a;
  
  private u b;
  
  private v c;
  
  public s(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    setGravity(17);
    this.a = new TextView(getContext());
    this.a.setTextColor(-1);
    this.a.setTextSize(2, 16.0F);
    this.a.setTypeface(null, 1);
    this.a.setText("Loading...");
    this.a.setGravity(17);
    this.b = new u(paramContext, (View)this.a);
    this.c = new v(getContext());
    addView((View)this.b);
    addView(this.c);
    a();
  }
  
  public void a() {
    removeView((View)this.b);
    removeView(this.c);
    float f = (getContext().getResources().getDisplayMetrics()).density;
    int i = Math.round(20.0F * f);
    CBOrientation.Difference difference = CBPreferences.getInstance().getForcedOrientationDifference();
    switch (null.a[difference.ordinal()]) {
      default:
        setOrientation(1);
        layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(i, i, i, 0);
        addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
        layoutParams = new LinearLayout.LayoutParams(-1, Math.round(f * 32.0F));
        layoutParams.setMargins(i, i, i, i);
        addView(this.c, (ViewGroup.LayoutParams)layoutParams);
        return;
      case 1:
        setOrientation(0);
        layoutParams = new LinearLayout.LayoutParams(Math.round(f * 32.0F), -1);
        layoutParams.setMargins(i, i, 0, i);
        addView(this.c, (ViewGroup.LayoutParams)layoutParams);
        layoutParams = new LinearLayout.LayoutParams(-2, -1);
        layoutParams.setMargins(i, i, i, i);
        addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
        return;
      case 2:
        setOrientation(1);
        layoutParams = new LinearLayout.LayoutParams(-1, Math.round(f * 32.0F));
        layoutParams.setMargins(i, i, i, 0);
        addView(this.c, (ViewGroup.LayoutParams)layoutParams);
        layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(i, i, i, i);
        addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
        return;
      case 3:
        break;
    } 
    setOrientation(0);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
    layoutParams.setMargins(i, i, 0, i);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
    layoutParams = new LinearLayout.LayoutParams(Math.round(f * 32.0F), -1);
    layoutParams.setMargins(i, i, i, i);
    addView(this.c, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public View b() {
    return (View)this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */