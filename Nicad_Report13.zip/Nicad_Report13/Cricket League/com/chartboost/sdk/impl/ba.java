package com.chartboost.sdk.impl;

public class ba extends az {
  final ao b;
  
  public ao b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof ba) {
      paramObject = paramObject;
      if (this.a.equals(((ba)paramObject).a) && this.b.equals(((ba)paramObject).b))
        return true; 
    } 
    return false;
  }
  
  public int hashCode() {
    return this.a.hashCode() ^ this.b.hashCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */