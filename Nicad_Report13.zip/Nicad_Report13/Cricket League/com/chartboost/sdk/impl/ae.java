package com.chartboost.sdk.impl;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Map;
import java.util.SimpleTimeZone;
import java.util.UUID;
import java.util.regex.Pattern;

public class ae {
  public static ag a() {
    ac ac = b();
    ac.a(Date.class, new i(ac));
    ac.a(ax.class, new g(ac));
    ac.a(ay.class, new h());
    ac.a(byte[].class, new h());
    return ac;
  }
  
  static ac b() {
    ac ac = new ac();
    ac.a(Object[].class, new m(ac));
    ac.a(Boolean.class, new q());
    ac.a(az.class, new a(ac));
    ac.a(ba.class, new b(ac));
    ac.a(z.class, new d(ac));
    ac.a(aa.class, new e(ac));
    ac.a(Iterable.class, new f(ac));
    ac.a(Map.class, new j(ac));
    ac.a(bb.class, new k(ac));
    ac.a(bc.class, new l(ac));
    ac.a(Number.class, new q());
    ac.a(bd.class, new n(ac));
    ac.a(Pattern.class, new o(ac));
    ac.a(String.class, new p());
    ac.a(UUID.class, new r(ac));
    return ac;
  }
  
  private static class a extends c {
    a(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      x x = new x();
      x.a("$code", param1Object.a());
      this.a.a(x, param1StringBuilder);
    }
  }
  
  private static class b extends c {
    b(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      x x = new x();
      x.a("$code", param1Object.a());
      x.a("$scope", param1Object.b());
      this.a.a(x, param1StringBuilder);
    }
  }
  
  private static abstract class c extends ab {
    protected final ag a;
    
    c(ag param1ag) {
      this.a = param1ag;
    }
  }
  
  private static class d extends c {
    d(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("{ ");
      param1Object = param1Object;
      Iterator<String> iterator = param1Object.keySet().iterator();
      boolean bool = true;
      while (iterator.hasNext()) {
        String str = iterator.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        ad.a(param1StringBuilder, str);
        param1StringBuilder.append(" : ");
        this.a.a(param1Object.a(str), param1StringBuilder);
      } 
      param1StringBuilder.append("}");
    }
  }
  
  private static class e extends c {
    e(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      x x = new x();
      x.a("$ref", param1Object.b());
      x.a("$id", param1Object.a());
      this.a.a(x, param1StringBuilder);
    }
  }
  
  private static class f extends c {
    f(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      boolean bool = true;
      param1StringBuilder.append("[ ");
      param1Object = ((Iterable)param1Object).iterator();
      while (param1Object.hasNext()) {
        Object object = param1Object.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        this.a.a(object, param1StringBuilder);
      } 
      param1StringBuilder.append("]");
    }
  }
  
  private static class g extends c {
    g(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      x x = new x();
      x.a("$ts", Integer.valueOf(param1Object.a()));
      x.a("$inc", Integer.valueOf(param1Object.b()));
      this.a.a(x, param1StringBuilder);
    }
  }
  
  private static class h extends ab {
    private h() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("<Binary Data>");
    }
  }
  
  private static class i extends c {
    i(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
      simpleDateFormat.setCalendar(new GregorianCalendar(new SimpleTimeZone(0, "GMT")));
      this.a.a(new x("$date", simpleDateFormat.format((Date)param1Object)), param1StringBuilder);
    }
  }
  
  private static class j extends c {
    j(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("{ ");
      param1Object = ((Map)param1Object).entrySet().iterator();
      boolean bool = true;
      while (param1Object.hasNext()) {
        Map.Entry entry = param1Object.next();
        if (bool) {
          bool = false;
        } else {
          param1StringBuilder.append(" , ");
        } 
        ad.a(param1StringBuilder, entry.getKey().toString());
        param1StringBuilder.append(" : ");
        this.a.a(entry.getValue(), param1StringBuilder);
      } 
      param1StringBuilder.append("}");
    }
  }
  
  private static class k extends c {
    k(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new x("$maxKey", Integer.valueOf(1)), param1StringBuilder);
    }
  }
  
  private static class l extends c {
    l(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new x("$minKey", Integer.valueOf(1)), param1StringBuilder);
    }
  }
  
  private static class m extends c {
    m(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append("[ ");
      for (int i = 0; i < Array.getLength(param1Object); i++) {
        if (i > 0)
          param1StringBuilder.append(" , "); 
        this.a.a(Array.get(param1Object, i), param1StringBuilder);
      } 
      param1StringBuilder.append("]");
    }
  }
  
  private static class n extends c {
    n(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      this.a.a(new x("$oid", param1Object.toString()), param1StringBuilder);
    }
  }
  
  private static class o extends c {
    o(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      x x = new x();
      x.a("$regex", param1Object.toString());
      if (((Pattern)param1Object).flags() != 0)
        x.a("$options", y.a(((Pattern)param1Object).flags())); 
      this.a.a(x, param1StringBuilder);
    }
  }
  
  private static class p extends ab {
    private p() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      ad.a(param1StringBuilder, (String)param1Object);
    }
  }
  
  private static class q extends ab {
    private q() {}
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1StringBuilder.append(param1Object.toString());
    }
  }
  
  private static class r extends c {
    r(ag param1ag) {
      super(param1ag);
    }
    
    public void a(Object param1Object, StringBuilder param1StringBuilder) {
      param1Object = param1Object;
      x x = new x();
      x.a("$uuid", param1Object.toString());
      this.a.a(x, param1StringBuilder);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */