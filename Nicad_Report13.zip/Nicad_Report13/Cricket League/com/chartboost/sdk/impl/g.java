package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBOrientation;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.c;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class g extends c {
  private static int h = 50;
  
  private static int i = 50;
  
  private static int j = 30;
  
  private List<JSONObject> k = new ArrayList<JSONObject>();
  
  private com.chartboost.sdk.Libraries.g l = new com.chartboost.sdk.Libraries.g(this);
  
  private com.chartboost.sdk.Libraries.g m = new com.chartboost.sdk.Libraries.g(this);
  
  private com.chartboost.sdk.Libraries.g n = new com.chartboost.sdk.Libraries.g(this);
  
  private Map<String, com.chartboost.sdk.Libraries.g> o;
  
  public g(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  protected c.b a(Context paramContext) {
    return new a(paramContext);
  }
  
  public void a(JSONObject paramJSONObject) {
    super.a(paramJSONObject);
    JSONArray jSONArray = paramJSONObject.optJSONArray("cells");
    if (jSONArray == null) {
      this.g.a(CBError.CBImpressionError.INTERNAL);
      return;
    } 
    this.o = new HashMap<String, com.chartboost.sdk.Libraries.g>();
    for (int i = 0; i < jSONArray.length(); i++) {
      com.chartboost.sdk.Libraries.g g1;
      JSONObject jSONObject = jSONArray.optJSONObject(i);
      this.k.add(jSONObject);
      String str = jSONObject.optString("type", "");
      if (str.equals("regular")) {
        jSONObject = jSONObject.optJSONObject("assets");
        if (jSONObject != null) {
          this.e++;
          g1 = new com.chartboost.sdk.Libraries.g(this);
          this.o.put("" + i, g1);
          g1.a(jSONObject, "icon", new Bundle());
        } 
      } else if (g1.equals("featured")) {
        jSONObject = jSONObject.optJSONObject("assets");
        if (jSONObject != null) {
          this.e++;
          g1 = new com.chartboost.sdk.Libraries.g(this);
          this.o.put(String.format(Locale.US, "%d-%s", new Object[] { Integer.valueOf(i), "portrait" }), g1);
          g1.a(jSONObject, "portrait", new Bundle());
          this.e++;
          g1 = new com.chartboost.sdk.Libraries.g(this);
          this.o.put(String.format(Locale.US, "%d-%s", new Object[] { Integer.valueOf(i), "landscape" }), g1);
          g1.a(jSONObject, "landscape", new Bundle());
        } 
      } else if (g1.equals("webview")) {
      
      } 
    } 
    this.l.a("close");
    this.m.a("header-center");
    this.n.a("header-tile");
  }
  
  public void d() {
    super.d();
    this.k = null;
    Iterator<Map.Entry> iterator = this.o.entrySet().iterator();
    while (iterator.hasNext())
      ((com.chartboost.sdk.Libraries.g)((Map.Entry)iterator.next()).getValue()).c(); 
    this.o.clear();
    this.l.c();
    this.m.c();
    this.n.c();
    this.l = null;
    this.n = null;
    this.m = null;
  }
  
  public class a extends c.b {
    private ImageView d;
    
    private ImageView e;
    
    private FrameLayout f;
    
    private r g;
    
    private u h;
    
    private u i;
    
    private a j;
    
    private a(g this$0, Context param1Context) {
      super(g.this, param1Context);
      boolean bool;
      setBackgroundColor(-1842205);
      this.f = new FrameLayout(param1Context);
      this.e = new ImageView(param1Context);
      this.d = new ImageView(param1Context);
      if (CBPreferences.getInstance().getForcedOrientationDifference().isOdd()) {
        bool = false;
      } else {
        bool = true;
      } 
      this.g = new r(param1Context, bool);
      this.g.b().setBackgroundColor(-1842205);
      this.f.setFocusable(false);
      this.e.setFocusable(false);
      this.d.setFocusable(false);
      this.d.setClickable(true);
      this.h = new u(param1Context, (View)this.d);
      this.i = new u(param1Context, (View)this.f);
      addView((View)this.i);
      this.f.addView((View)this.e);
      addView((View)this.h);
      a((View)this.e);
      a((View)this.f);
      a((View)this.d);
      a((View)this.i);
      a((View)this.h);
      this.d.setOnClickListener(new View.OnClickListener(this, g.this) {
            public void onClick(View param2View) {
              if (this.b.c.a != null)
                this.b.c.a.a(); 
            }
          });
      this.j = new a(this, param1Context);
    }
    
    private void a(View param1View) {
      int i = 200;
      if (200 == getId())
        i = 201; 
      for (View view = findViewById(i); view != null; view = findViewById(++i));
      param1View.setId(i);
      param1View.setSaveEnabled(false);
    }
    
    protected void a(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield g : Lcom/chartboost/sdk/impl/r;
      //   4: invokevirtual a : ()Landroid/view/ViewGroup;
      //   7: ifnull -> 21
      //   10: aload_0
      //   11: aload_0
      //   12: getfield g : Lcom/chartboost/sdk/impl/r;
      //   15: invokevirtual a : ()Landroid/view/ViewGroup;
      //   18: invokevirtual removeView : (Landroid/view/View;)V
      //   21: new android/widget/FrameLayout$LayoutParams
      //   24: dup
      //   25: bipush #-2
      //   27: bipush #-2
      //   29: bipush #17
      //   31: invokespecial <init> : (III)V
      //   34: astore_3
      //   35: new android/widget/RelativeLayout$LayoutParams
      //   38: dup
      //   39: bipush #-2
      //   41: bipush #-2
      //   43: invokespecial <init> : (II)V
      //   46: astore #4
      //   48: new android/widget/RelativeLayout$LayoutParams
      //   51: dup
      //   52: bipush #-2
      //   54: bipush #-2
      //   56: invokespecial <init> : (II)V
      //   59: astore #5
      //   61: new android/widget/RelativeLayout$LayoutParams
      //   64: dup
      //   65: bipush #-2
      //   67: bipush #-2
      //   69: invokespecial <init> : (II)V
      //   72: astore #6
      //   74: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
      //   77: invokevirtual getForcedOrientationDifference : ()Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
      //   80: astore #7
      //   82: aload #7
      //   84: invokevirtual isOdd : ()Z
      //   87: ifeq -> 616
      //   90: invokestatic h : ()I
      //   93: aload_0
      //   94: invokevirtual getContext : ()Landroid/content/Context;
      //   97: invokestatic a : (ILandroid/content/Context;)I
      //   100: istore_1
      //   101: aload #4
      //   103: iload_1
      //   104: putfield width : I
      //   107: aload #7
      //   109: invokevirtual isOdd : ()Z
      //   112: ifeq -> 621
      //   115: iconst_m1
      //   116: istore_1
      //   117: aload #4
      //   119: iload_1
      //   120: putfield height : I
      //   123: getstatic com/chartboost/sdk/impl/g$1.a : [I
      //   126: aload #7
      //   128: invokevirtual ordinal : ()I
      //   131: iaload
      //   132: tableswitch default -> 156, 1 -> 635, 2 -> 645
      //   156: new android/graphics/drawable/BitmapDrawable
      //   159: dup
      //   160: aload_0
      //   161: getfield c : Lcom/chartboost/sdk/impl/g;
      //   164: invokestatic a : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   167: invokevirtual e : ()Landroid/graphics/Bitmap;
      //   170: invokespecial <init> : (Landroid/graphics/Bitmap;)V
      //   173: astore #8
      //   175: aload #8
      //   177: getstatic android/graphics/Shader$TileMode.REPEAT : Landroid/graphics/Shader$TileMode;
      //   180: invokevirtual setTileModeX : (Landroid/graphics/Shader$TileMode;)V
      //   183: aload #8
      //   185: getstatic android/graphics/Shader$TileMode.CLAMP : Landroid/graphics/Shader$TileMode;
      //   188: invokevirtual setTileModeY : (Landroid/graphics/Shader$TileMode;)V
      //   191: aload_0
      //   192: getfield f : Landroid/widget/FrameLayout;
      //   195: aload #8
      //   197: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
      //   200: aload_0
      //   201: getfield c : Lcom/chartboost/sdk/impl/g;
      //   204: invokestatic b : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   207: ifnull -> 275
      //   210: aload_0
      //   211: getfield e : Landroid/widget/ImageView;
      //   214: aload_0
      //   215: getfield c : Lcom/chartboost/sdk/impl/g;
      //   218: invokestatic b : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   221: invokevirtual e : ()Landroid/graphics/Bitmap;
      //   224: invokevirtual setImageBitmap : (Landroid/graphics/Bitmap;)V
      //   227: aload_3
      //   228: aload_0
      //   229: getfield c : Lcom/chartboost/sdk/impl/g;
      //   232: invokestatic b : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   235: invokevirtual a : ()I
      //   238: aload_0
      //   239: invokevirtual getContext : ()Landroid/content/Context;
      //   242: invokestatic a : (ILandroid/content/Context;)I
      //   245: putfield width : I
      //   248: aload_3
      //   249: invokestatic h : ()I
      //   252: aload_0
      //   253: getfield c : Lcom/chartboost/sdk/impl/g;
      //   256: invokestatic b : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   259: invokevirtual b : ()I
      //   262: invokestatic min : (II)I
      //   265: aload_0
      //   266: invokevirtual getContext : ()Landroid/content/Context;
      //   269: invokestatic a : (ILandroid/content/Context;)I
      //   272: putfield height : I
      //   275: aload_0
      //   276: getfield d : Landroid/widget/ImageView;
      //   279: aload_0
      //   280: getfield c : Lcom/chartboost/sdk/impl/g;
      //   283: invokestatic c : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Libraries/g;
      //   286: invokevirtual e : ()Landroid/graphics/Bitmap;
      //   289: invokevirtual setImageBitmap : (Landroid/graphics/Bitmap;)V
      //   292: aload #7
      //   294: invokevirtual isOdd : ()Z
      //   297: ifeq -> 655
      //   300: invokestatic i : ()I
      //   303: istore_1
      //   304: aload #5
      //   306: iload_1
      //   307: aload_0
      //   308: invokevirtual getContext : ()Landroid/content/Context;
      //   311: invokestatic a : (ILandroid/content/Context;)I
      //   314: putfield width : I
      //   317: aload #7
      //   319: invokevirtual isOdd : ()Z
      //   322: ifeq -> 662
      //   325: invokestatic j : ()I
      //   328: istore_1
      //   329: aload #5
      //   331: iload_1
      //   332: aload_0
      //   333: invokevirtual getContext : ()Landroid/content/Context;
      //   336: invokestatic a : (ILandroid/content/Context;)I
      //   339: putfield height : I
      //   342: getstatic com/chartboost/sdk/impl/g$1.a : [I
      //   345: aload #7
      //   347: invokevirtual ordinal : ()I
      //   350: iaload
      //   351: tableswitch default -> 376, 1 -> 669, 2 -> 721, 3 -> 766
      //   376: aload #5
      //   378: bipush #10
      //   380: aload_0
      //   381: invokevirtual getContext : ()Landroid/content/Context;
      //   384: invokestatic a : (ILandroid/content/Context;)I
      //   387: putfield rightMargin : I
      //   390: aload #5
      //   392: invokestatic h : ()I
      //   395: invokestatic i : ()I
      //   398: isub
      //   399: iconst_2
      //   400: idiv
      //   401: aload_0
      //   402: invokevirtual getContext : ()Landroid/content/Context;
      //   405: invokestatic a : (ILandroid/content/Context;)I
      //   408: putfield topMargin : I
      //   411: aload #5
      //   413: bipush #11
      //   415: invokevirtual addRule : (I)V
      //   418: aload #6
      //   420: iconst_m1
      //   421: putfield width : I
      //   424: aload #6
      //   426: iconst_m1
      //   427: putfield height : I
      //   430: getstatic com/chartboost/sdk/impl/g$1.a : [I
      //   433: aload #7
      //   435: invokevirtual ordinal : ()I
      //   438: iaload
      //   439: tableswitch default -> 464, 1 -> 804, 2 -> 820, 3 -> 836
      //   464: aload #6
      //   466: iconst_3
      //   467: aload_0
      //   468: getfield i : Lcom/chartboost/sdk/impl/u;
      //   471: invokevirtual getId : ()I
      //   474: invokevirtual addRule : (II)V
      //   477: aload_0
      //   478: getfield g : Lcom/chartboost/sdk/impl/r;
      //   481: astore #8
      //   483: aload #7
      //   485: invokevirtual isOdd : ()Z
      //   488: ifeq -> 852
      //   491: iconst_0
      //   492: istore_1
      //   493: aload #8
      //   495: iload_1
      //   496: invokevirtual a : (I)V
      //   499: aload_0
      //   500: aload_0
      //   501: getfield g : Lcom/chartboost/sdk/impl/r;
      //   504: invokevirtual a : ()Landroid/view/ViewGroup;
      //   507: invokespecial a : (Landroid/view/View;)V
      //   510: aload_0
      //   511: getfield g : Lcom/chartboost/sdk/impl/r;
      //   514: aload_0
      //   515: getfield j : Lcom/chartboost/sdk/impl/g$a$a;
      //   518: invokevirtual a : (Landroid/widget/BaseAdapter;)V
      //   521: aload_0
      //   522: aload_0
      //   523: getfield g : Lcom/chartboost/sdk/impl/r;
      //   526: invokevirtual a : ()Landroid/view/ViewGroup;
      //   529: aload #6
      //   531: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
      //   534: aload #7
      //   536: getstatic com/chartboost/sdk/Libraries/CBOrientation$Difference.ANGLE_180 : Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
      //   539: if_acmpne -> 857
      //   542: aload_0
      //   543: getfield g : Lcom/chartboost/sdk/impl/r;
      //   546: invokevirtual b : ()Landroid/widget/LinearLayout;
      //   549: bipush #80
      //   551: invokevirtual setGravity : (I)V
      //   554: aload_0
      //   555: getfield i : Lcom/chartboost/sdk/impl/u;
      //   558: aload #4
      //   560: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   563: aload_0
      //   564: getfield e : Landroid/widget/ImageView;
      //   567: aload_3
      //   568: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   571: aload_0
      //   572: getfield e : Landroid/widget/ImageView;
      //   575: getstatic android/widget/ImageView$ScaleType.FIT_CENTER : Landroid/widget/ImageView$ScaleType;
      //   578: invokevirtual setScaleType : (Landroid/widget/ImageView$ScaleType;)V
      //   581: aload_0
      //   582: getfield h : Lcom/chartboost/sdk/impl/u;
      //   585: aload #5
      //   587: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   590: aload_0
      //   591: getfield d : Landroid/widget/ImageView;
      //   594: getstatic android/widget/ImageView$ScaleType.FIT_CENTER : Landroid/widget/ImageView$ScaleType;
      //   597: invokevirtual setScaleType : (Landroid/widget/ImageView$ScaleType;)V
      //   600: aload_0
      //   601: new com/chartboost/sdk/impl/g$a$2
      //   604: dup
      //   605: aload_0
      //   606: aload #7
      //   608: invokespecial <init> : (Lcom/chartboost/sdk/impl/g$a;Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;)V
      //   611: invokevirtual post : (Ljava/lang/Runnable;)Z
      //   614: pop
      //   615: return
      //   616: iconst_m1
      //   617: istore_1
      //   618: goto -> 101
      //   621: invokestatic h : ()I
      //   624: aload_0
      //   625: invokevirtual getContext : ()Landroid/content/Context;
      //   628: invokestatic a : (ILandroid/content/Context;)I
      //   631: istore_1
      //   632: goto -> 117
      //   635: aload #4
      //   637: bipush #11
      //   639: invokevirtual addRule : (I)V
      //   642: goto -> 156
      //   645: aload #4
      //   647: bipush #12
      //   649: invokevirtual addRule : (I)V
      //   652: goto -> 156
      //   655: invokestatic j : ()I
      //   658: istore_1
      //   659: goto -> 304
      //   662: invokestatic i : ()I
      //   665: istore_1
      //   666: goto -> 329
      //   669: aload #5
      //   671: bipush #10
      //   673: aload_0
      //   674: invokevirtual getContext : ()Landroid/content/Context;
      //   677: invokestatic a : (ILandroid/content/Context;)I
      //   680: putfield bottomMargin : I
      //   683: aload #5
      //   685: invokestatic h : ()I
      //   688: invokestatic i : ()I
      //   691: isub
      //   692: iconst_2
      //   693: idiv
      //   694: aload_0
      //   695: invokevirtual getContext : ()Landroid/content/Context;
      //   698: invokestatic a : (ILandroid/content/Context;)I
      //   701: putfield rightMargin : I
      //   704: aload #5
      //   706: bipush #11
      //   708: invokevirtual addRule : (I)V
      //   711: aload #5
      //   713: bipush #12
      //   715: invokevirtual addRule : (I)V
      //   718: goto -> 418
      //   721: aload #5
      //   723: bipush #10
      //   725: aload_0
      //   726: invokevirtual getContext : ()Landroid/content/Context;
      //   729: invokestatic a : (ILandroid/content/Context;)I
      //   732: putfield leftMargin : I
      //   735: aload #5
      //   737: invokestatic h : ()I
      //   740: invokestatic i : ()I
      //   743: isub
      //   744: iconst_2
      //   745: idiv
      //   746: aload_0
      //   747: invokevirtual getContext : ()Landroid/content/Context;
      //   750: invokestatic a : (ILandroid/content/Context;)I
      //   753: putfield bottomMargin : I
      //   756: aload #5
      //   758: bipush #12
      //   760: invokevirtual addRule : (I)V
      //   763: goto -> 418
      //   766: aload #5
      //   768: bipush #10
      //   770: aload_0
      //   771: invokevirtual getContext : ()Landroid/content/Context;
      //   774: invokestatic a : (ILandroid/content/Context;)I
      //   777: putfield topMargin : I
      //   780: aload #5
      //   782: invokestatic h : ()I
      //   785: invokestatic i : ()I
      //   788: isub
      //   789: iconst_2
      //   790: idiv
      //   791: aload_0
      //   792: invokevirtual getContext : ()Landroid/content/Context;
      //   795: invokestatic a : (ILandroid/content/Context;)I
      //   798: putfield leftMargin : I
      //   801: goto -> 418
      //   804: aload #6
      //   806: iconst_0
      //   807: aload_0
      //   808: getfield i : Lcom/chartboost/sdk/impl/u;
      //   811: invokevirtual getId : ()I
      //   814: invokevirtual addRule : (II)V
      //   817: goto -> 477
      //   820: aload #6
      //   822: iconst_2
      //   823: aload_0
      //   824: getfield i : Lcom/chartboost/sdk/impl/u;
      //   827: invokevirtual getId : ()I
      //   830: invokevirtual addRule : (II)V
      //   833: goto -> 477
      //   836: aload #6
      //   838: iconst_1
      //   839: aload_0
      //   840: getfield i : Lcom/chartboost/sdk/impl/u;
      //   843: invokevirtual getId : ()I
      //   846: invokevirtual addRule : (II)V
      //   849: goto -> 477
      //   852: iconst_1
      //   853: istore_1
      //   854: goto -> 493
      //   857: aload #7
      //   859: getstatic com/chartboost/sdk/Libraries/CBOrientation$Difference.ANGLE_90 : Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
      //   862: if_acmpne -> 879
      //   865: aload_0
      //   866: getfield g : Lcom/chartboost/sdk/impl/r;
      //   869: invokevirtual b : ()Landroid/widget/LinearLayout;
      //   872: iconst_5
      //   873: invokevirtual setGravity : (I)V
      //   876: goto -> 554
      //   879: aload_0
      //   880: getfield g : Lcom/chartboost/sdk/impl/r;
      //   883: invokevirtual b : ()Landroid/widget/LinearLayout;
      //   886: iconst_0
      //   887: invokevirtual setGravity : (I)V
      //   890: goto -> 554
    }
    
    public void c() {
      super.c();
      this.d = null;
      this.e = null;
      this.g = null;
    }
    
    public class a extends ArrayAdapter<JSONObject> {
      private Context b;
      
      public a(g.a this$0, Context param2Context) {
        super(param2Context, 0, g.d(this$0.c));
        this.b = param2Context;
      }
      
      public JSONObject a(int param2Int) {
        return g.d(this.a.c).get(param2Int);
      }
      
      public int getCount() {
        return g.d(this.a.c).size();
      }
      
      public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
        g.b b;
        u u;
        CBOrientation.Difference difference = CBPreferences.getInstance().getForcedOrientationDifference();
        int i = param2Int;
        if (difference.isReverse())
          i = getCount() - 1 - param2Int; 
        JSONObject jSONObject = a(i);
        String str = jSONObject.optString("type", "");
        param2ViewGroup = null;
        if (param2View == null) {
          if (str.equals("featured")) {
            c c = new c(this.b);
          } else if (str.equals("regular")) {
            d d = new d(this.b);
          } else {
            ViewGroup viewGroup = param2ViewGroup;
            if (str.equals("webview"))
              b = new h(this.b); 
          } 
          u = new u(this.b, (View)b);
        } else {
          u = (u)b;
          b = (g.b)u.a();
        } 
        b.a(jSONObject, i);
        b b1 = (b)b;
        if (difference.isOdd()) {
          u.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(b.a(), -1));
        } else {
          u.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, b.a()));
        } 
        View.OnClickListener onClickListener = new View.OnClickListener(this, jSONObject) {
            public void onClick(View param3View) {
              // Byte code:
              //   0: aload_0
              //   1: getfield a : Lorg/json/JSONObject;
              //   4: ldc 'deep-link'
              //   6: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
              //   9: astore_2
              //   10: aload_2
              //   11: ifnull -> 25
              //   14: aload_2
              //   15: astore_1
              //   16: aload_2
              //   17: ldc ''
              //   19: invokevirtual equals : (Ljava/lang/Object;)Z
              //   22: ifeq -> 35
              //   25: aload_0
              //   26: getfield a : Lorg/json/JSONObject;
              //   29: ldc 'link'
              //   31: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
              //   34: astore_1
              //   35: aload_0
              //   36: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
              //   39: getfield a : Lcom/chartboost/sdk/impl/g$a;
              //   42: getfield c : Lcom/chartboost/sdk/impl/g;
              //   45: getfield b : Lcom/chartboost/sdk/c$c;
              //   48: ifnull -> 87
              //   51: aload_0
              //   52: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
              //   55: getfield a : Lcom/chartboost/sdk/impl/g$a;
              //   58: getfield c : Lcom/chartboost/sdk/impl/g;
              //   61: getfield b : Lcom/chartboost/sdk/c$c;
              //   64: aload_0
              //   65: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
              //   68: getfield a : Lcom/chartboost/sdk/impl/g$a;
              //   71: getfield c : Lcom/chartboost/sdk/impl/g;
              //   74: invokestatic e : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Model/a;
              //   77: aload_1
              //   78: aload_0
              //   79: getfield a : Lorg/json/JSONObject;
              //   82: invokeinterface a : (Lcom/chartboost/sdk/Model/a;Ljava/lang/String;Lorg/json/JSONObject;)V
              //   87: return
            }
          };
        b1.a = onClickListener;
        b1.setOnClickListener(onClickListener);
        if (b instanceof d)
          ((d)b).b.setOnClickListener(onClickListener); 
        return (View)u;
      }
    }
    
    class null implements View.OnClickListener {
      null(g.a this$0, JSONObject param2JSONObject) {}
      
      public void onClick(View param2View) {
        // Byte code:
        //   0: aload_0
        //   1: getfield a : Lorg/json/JSONObject;
        //   4: ldc 'deep-link'
        //   6: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
        //   9: astore_2
        //   10: aload_2
        //   11: ifnull -> 25
        //   14: aload_2
        //   15: astore_1
        //   16: aload_2
        //   17: ldc ''
        //   19: invokevirtual equals : (Ljava/lang/Object;)Z
        //   22: ifeq -> 35
        //   25: aload_0
        //   26: getfield a : Lorg/json/JSONObject;
        //   29: ldc 'link'
        //   31: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
        //   34: astore_1
        //   35: aload_0
        //   36: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
        //   39: getfield a : Lcom/chartboost/sdk/impl/g$a;
        //   42: getfield c : Lcom/chartboost/sdk/impl/g;
        //   45: getfield b : Lcom/chartboost/sdk/c$c;
        //   48: ifnull -> 87
        //   51: aload_0
        //   52: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
        //   55: getfield a : Lcom/chartboost/sdk/impl/g$a;
        //   58: getfield c : Lcom/chartboost/sdk/impl/g;
        //   61: getfield b : Lcom/chartboost/sdk/c$c;
        //   64: aload_0
        //   65: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
        //   68: getfield a : Lcom/chartboost/sdk/impl/g$a;
        //   71: getfield c : Lcom/chartboost/sdk/impl/g;
        //   74: invokestatic e : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Model/a;
        //   77: aload_1
        //   78: aload_0
        //   79: getfield a : Lorg/json/JSONObject;
        //   82: invokeinterface a : (Lcom/chartboost/sdk/Model/a;Ljava/lang/String;Lorg/json/JSONObject;)V
        //   87: return
      }
    }
  }
  
  class null implements View.OnClickListener {
    null(g this$0, g param1g) {}
    
    public void onClick(View param1View) {
      if (this.b.c.a != null)
        this.b.c.a.a(); 
    }
  }
  
  class null implements Runnable {
    null(g this$0, CBOrientation.Difference param1Difference) {}
    
    public void run() {
      if (g.a.a(this.b) != null) {
        g.a.a(this.b, true);
        this.b.requestLayout();
        g.a.a(this.b).a().requestLayout();
        g.a.a(this.b).b().requestLayout();
        g.a.b(this.b, false);
        if (this.a == CBOrientation.Difference.ANGLE_180 || this.a == CBOrientation.Difference.ANGLE_90) {
          g.a.a(this.b).c();
          return;
        } 
      } 
    }
  }
  
  public class a extends ArrayAdapter<JSONObject> {
    private Context b;
    
    public a(g this$0, Context param1Context) {
      super(param1Context, 0, g.d(((g.a)this$0).c));
      this.b = param1Context;
    }
    
    public JSONObject a(int param1Int) {
      return g.d(this.a.c).get(param1Int);
    }
    
    public int getCount() {
      return g.d(this.a.c).size();
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      g.b b;
      u u;
      CBOrientation.Difference difference = CBPreferences.getInstance().getForcedOrientationDifference();
      int i = param1Int;
      if (difference.isReverse())
        i = getCount() - 1 - param1Int; 
      JSONObject jSONObject = a(i);
      String str = jSONObject.optString("type", "");
      param1ViewGroup = null;
      if (param1View == null) {
        if (str.equals("featured")) {
          c c = new c(this.b);
        } else if (str.equals("regular")) {
          d d = new d(this.b);
        } else {
          ViewGroup viewGroup = param1ViewGroup;
          if (str.equals("webview"))
            b = new h(this.b); 
        } 
        u = new u(this.b, (View)b);
      } else {
        u = (u)b;
        b = (g.b)u.a();
      } 
      b.a(jSONObject, i);
      b b1 = (b)b;
      if (difference.isOdd()) {
        u.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(b.a(), -1));
      } else {
        u.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, b.a()));
      } 
      View.OnClickListener onClickListener = new View.OnClickListener(this, jSONObject) {
          public void onClick(View param3View) {
            // Byte code:
            //   0: aload_0
            //   1: getfield a : Lorg/json/JSONObject;
            //   4: ldc 'deep-link'
            //   6: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
            //   9: astore_2
            //   10: aload_2
            //   11: ifnull -> 25
            //   14: aload_2
            //   15: astore_1
            //   16: aload_2
            //   17: ldc ''
            //   19: invokevirtual equals : (Ljava/lang/Object;)Z
            //   22: ifeq -> 35
            //   25: aload_0
            //   26: getfield a : Lorg/json/JSONObject;
            //   29: ldc 'link'
            //   31: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
            //   34: astore_1
            //   35: aload_0
            //   36: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
            //   39: getfield a : Lcom/chartboost/sdk/impl/g$a;
            //   42: getfield c : Lcom/chartboost/sdk/impl/g;
            //   45: getfield b : Lcom/chartboost/sdk/c$c;
            //   48: ifnull -> 87
            //   51: aload_0
            //   52: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
            //   55: getfield a : Lcom/chartboost/sdk/impl/g$a;
            //   58: getfield c : Lcom/chartboost/sdk/impl/g;
            //   61: getfield b : Lcom/chartboost/sdk/c$c;
            //   64: aload_0
            //   65: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
            //   68: getfield a : Lcom/chartboost/sdk/impl/g$a;
            //   71: getfield c : Lcom/chartboost/sdk/impl/g;
            //   74: invokestatic e : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Model/a;
            //   77: aload_1
            //   78: aload_0
            //   79: getfield a : Lorg/json/JSONObject;
            //   82: invokeinterface a : (Lcom/chartboost/sdk/Model/a;Ljava/lang/String;Lorg/json/JSONObject;)V
            //   87: return
          }
        };
      b1.a = onClickListener;
      b1.setOnClickListener(onClickListener);
      if (b instanceof d)
        ((d)b).b.setOnClickListener(onClickListener); 
      return (View)u;
    }
  }
  
  class null implements View.OnClickListener {
    null(g this$0, JSONObject param1JSONObject) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Lorg/json/JSONObject;
      //   4: ldc 'deep-link'
      //   6: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   9: astore_2
      //   10: aload_2
      //   11: ifnull -> 25
      //   14: aload_2
      //   15: astore_1
      //   16: aload_2
      //   17: ldc ''
      //   19: invokevirtual equals : (Ljava/lang/Object;)Z
      //   22: ifeq -> 35
      //   25: aload_0
      //   26: getfield a : Lorg/json/JSONObject;
      //   29: ldc 'link'
      //   31: invokevirtual optString : (Ljava/lang/String;)Ljava/lang/String;
      //   34: astore_1
      //   35: aload_0
      //   36: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
      //   39: getfield a : Lcom/chartboost/sdk/impl/g$a;
      //   42: getfield c : Lcom/chartboost/sdk/impl/g;
      //   45: getfield b : Lcom/chartboost/sdk/c$c;
      //   48: ifnull -> 87
      //   51: aload_0
      //   52: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
      //   55: getfield a : Lcom/chartboost/sdk/impl/g$a;
      //   58: getfield c : Lcom/chartboost/sdk/impl/g;
      //   61: getfield b : Lcom/chartboost/sdk/c$c;
      //   64: aload_0
      //   65: getfield b : Lcom/chartboost/sdk/impl/g$a$a;
      //   68: getfield a : Lcom/chartboost/sdk/impl/g$a;
      //   71: getfield c : Lcom/chartboost/sdk/impl/g;
      //   74: invokestatic e : (Lcom/chartboost/sdk/impl/g;)Lcom/chartboost/sdk/Model/a;
      //   77: aload_1
      //   78: aload_0
      //   79: getfield a : Lorg/json/JSONObject;
      //   82: invokeinterface a : (Lcom/chartboost/sdk/Model/a;Ljava/lang/String;Lorg/json/JSONObject;)V
      //   87: return
    }
  }
  
  public static interface b {
    int a();
    
    void a(JSONObject param1JSONObject, int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */