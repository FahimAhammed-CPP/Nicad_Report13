package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.widget.Button;

public final class e extends Button {
  private Path a;
  
  private Path b;
  
  private Path c;
  
  private RectF d;
  
  private Paint e;
  
  private Paint f;
  
  private Shader g;
  
  private Shader h;
  
  private int i;
  
  public e(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a() {
    int i = getHeight();
    if (i == this.i)
      return; 
    this.i = i;
    float f = getHeight();
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    this.g = (Shader)new LinearGradient(0.0F, 0.0F, 0.0F, f, new int[] { -81366, -89600, -97280 }, null, tileMode);
    f = getHeight();
    tileMode = Shader.TileMode.CLAMP;
    this.h = (Shader)new LinearGradient(0.0F, 0.0F, 0.0F, f, new int[] { -97280, -89600, -81366 }, null, tileMode);
  }
  
  private void a(Context paramContext) {
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    setTextSize(2, 13.0F);
    setShadowLayer(1.0F * f, 1.0F * f, 1.0F * f, -16757901);
    setTypeface(null, 1);
    setTextColor(-1);
    setClickable(true);
    setGravity(17);
    setPadding(Math.round(12.0F * f), Math.round(5.0F * f), Math.round(12.0F * f), Math.round(f * 5.0F));
    this.a = new Path();
    this.b = new Path();
    this.c = new Path();
    this.d = new RectF();
    this.e = new Paint();
    this.e.setStyle(Paint.Style.STROKE);
    this.e.setColor(-4496384);
    this.e.setAntiAlias(true);
    this.i = -1;
    this.f = new Paint();
    this.f.setStyle(Paint.Style.FILL);
    this.f.setAntiAlias(true);
    setBackgroundDrawable(new Drawable(this) {
          boolean a = false;
          
          public void draw(Canvas param1Canvas) {
            Shader shader;
            int i = 0;
            float f2 = (this.b.getContext().getResources().getDisplayMetrics()).density;
            int[] arrayOfInt = getState();
            boolean bool = false;
            while (i < arrayOfInt.length) {
              if (arrayOfInt[i] == 16842919)
                bool = true; 
              i++;
            } 
            float f1 = 6.0F * f2;
            e.a(this.b).reset();
            e.b(this.b).set(getBounds());
            e.a(this.b).addRoundRect(e.b(this.b), f1, f1, Path.Direction.CW);
            e.c(this.b);
            Paint paint = e.f(this.b);
            if (bool) {
              shader = e.d(this.b);
            } else {
              shader = e.e(this.b);
            } 
            paint.setShader(shader);
            param1Canvas.drawPath(e.a(this.b), e.f(this.b));
            f2 = 1.0F * f2;
            e.g(this.b).reset();
            e.b(this.b).inset(f2 / 2.0F, f2 / 2.0F);
            e.g(this.b).addRoundRect(e.b(this.b), f1, f1, Path.Direction.CW);
            e.h(this.b).reset();
            e.b(this.b).offset(0.0F, f2 / 2.0F);
            e.h(this.b).addRoundRect(e.b(this.b), f1, f1, Path.Direction.CW);
            if (!bool) {
              e.i(this.b).setColor(-1);
              param1Canvas.drawPath(e.h(this.b), e.i(this.b));
            } 
            e.i(this.b).setColor(-4496384);
            param1Canvas.drawPath(e.g(this.b), e.i(this.b));
          }
          
          public int getOpacity() {
            return 1;
          }
          
          public boolean isStateful() {
            return true;
          }
          
          protected boolean onStateChange(int[] param1ArrayOfint) {
            int i = 0;
            boolean bool = false;
            while (i < param1ArrayOfint.length) {
              if (param1ArrayOfint[i] == 16842919)
                bool = true; 
              i++;
            } 
            if (this.a != bool) {
              this.a = bool;
              invalidateSelf();
              return true;
            } 
            return false;
          }
          
          public void setAlpha(int param1Int) {
            e.i(this.b).setAlpha(param1Int);
            e.f(this.b).setAlpha(param1Int);
          }
          
          public void setColorFilter(ColorFilter param1ColorFilter) {
            e.i(this.b).setColorFilter(param1ColorFilter);
            e.f(this.b).setColorFilter(param1ColorFilter);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */