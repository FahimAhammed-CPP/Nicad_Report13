package com.chartboost.sdk.impl;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public abstract class bm<T> {
  final int a;
  
  private Queue<T> b = new ConcurrentLinkedQueue<T>();
  
  public bm(int paramInt) {
    this.a = paramInt;
  }
  
  protected boolean a(T paramT) {
    return true;
  }
  
  protected abstract T b();
  
  public void b(T paramT) {
    if (a(paramT) && this.b.size() <= this.a) {
      this.b.add(paramT);
      return;
    } 
  }
  
  public T c() {
    T t = this.b.poll();
    return (t != null) ? t : b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */