package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.g;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.c;
import java.util.Locale;
import org.json.JSONObject;

public class a extends c {
  private static Point n = null;
  
  public g h = new g(this);
  
  public g i = new g(this);
  
  public g j = new g(this);
  
  public g k = new g(this);
  
  public g l = new g(this);
  
  public g m = new g(this);
  
  public a(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  private Point a(String paramString) {
    JSONObject jSONObject = this.f.optJSONObject(paramString);
    if (jSONObject != null) {
      jSONObject = jSONObject.optJSONObject("offset");
      if (jSONObject != null)
        return new Point(jSONObject.optInt("x", 0), jSONObject.optInt("y", 0)); 
    } 
    return new Point(0, 0);
  }
  
  private static Point c(Context paramContext) {
    if (n == null)
      n = new Point(-((int)(CBUtility.b(10, paramContext) + 0.5F)), -((int)(CBUtility.b(10, paramContext) + 0.5F))); 
    return n;
  }
  
  protected c.b a(Context paramContext) {
    return new a(paramContext);
  }
  
  public void a(JSONObject paramJSONObject) {
    String str;
    super.a(paramJSONObject);
    if (CBPreferences.getInstance().getOrientation().isPortrait()) {
      str = "portrait";
    } else {
      str = "landscape";
    } 
    if (this.f.optJSONObject(String.format(Locale.US, "ad-%s", new Object[] { str })) == null || this.f.optJSONObject(String.format(Locale.US, "frame-%s", new Object[] { str })) == null) {
      this.g.a(CBError.CBImpressionError.WRONG_ORIENTATION);
      return;
    } 
    this.i.a("ad-landscape");
    this.h.a("ad-portrait");
    this.k.a("frame-landscape");
    this.j.a("frame-portrait");
    this.m.a("close-landscape");
    this.l.a("close-portrait");
  }
  
  public void d() {
    super.d();
    this.i.c();
    this.h.c();
    this.k.c();
    this.j.c();
    this.m.c();
    this.l.c();
    this.i = null;
    this.h = null;
    this.k = null;
    this.j = null;
    this.m = null;
    this.l = null;
  }
  
  public class a extends c.b {
    public ImageView c;
    
    public ImageView d;
    
    public Button e;
    
    public u f;
    
    private a(a this$0, Context param1Context) {
      super(a.this, param1Context);
      setBackgroundColor(0);
      setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      this.f = new u(param1Context);
      this.c = new ImageView(param1Context);
      this.e = new Button(param1Context);
      this.d = new ImageView(param1Context);
      this.e.setOnClickListener(new View.OnClickListener(this, a.this) {
            public void onClick(View param2View) {
              if (this.b.g.a != null)
                this.b.g.a.a(); 
            }
          });
      this.c.setClickable(true);
      this.c.setOnClickListener(new View.OnClickListener(this, a.this) {
            public void onClick(View param2View) {
              if (this.b.g.b != null)
                this.b.g.b.a(a.a(this.b.g), null, null); 
            }
          });
      this.f.a((View)this.d);
      this.f.a((View)this.c);
      this.f.a((View)this.e);
      addView((View)this.f, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    }
    
    protected void a(int param1Int1, int param1Int2) {
      g g1;
      g g2;
      g g3;
      String str3;
      String str2;
      String str1;
      boolean bool = CBPreferences.getInstance().getOrientation().isPortrait();
      if (bool) {
        g1 = this.g.j;
      } else {
        g1 = this.g.k;
      } 
      if (bool) {
        g2 = this.g.h;
      } else {
        g2 = this.g.i;
      } 
      if (bool) {
        g3 = this.g.l;
      } else {
        g3 = this.g.m;
      } 
      RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
      RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(-2, -2);
      CBLogging.a("CBNativeInterstitialViewProtocol", "Layout orientation changed");
      layoutParams1.width = (int)(g1.a() / g1.f());
      layoutParams1.height = (int)(g1.b() / g1.f());
      a a1 = this.g;
      if (bool) {
        str3 = "frame-portrait";
      } else {
        str3 = "frame-landscape";
      } 
      Point point3 = a.a(a1, str3);
      layoutParams1.leftMargin = Math.round((param1Int1 - layoutParams1.width) / 2.0F + point3.x / g1.f());
      float f = (param1Int2 - layoutParams1.height) / 2.0F;
      layoutParams1.topMargin = Math.round(point3.y / g1.f() + f);
      this.c.setId(100);
      layoutParams2.width = (int)(g2.a() / g2.f());
      layoutParams2.height = (int)(g2.b() / g2.f());
      a1 = this.g;
      if (bool) {
        str2 = "ad-portrait";
      } else {
        str2 = "ad-landscape";
      } 
      Point point2 = a.a(a1, str2);
      layoutParams2.leftMargin = Math.round((param1Int1 - layoutParams2.width) / 2.0F + point2.x / g2.f());
      f = (param1Int2 - layoutParams2.height) / 2.0F;
      layoutParams2.topMargin = Math.round(point2.y / g2.f() + f);
      layoutParams3.width = (int)(g3.a() / g3.f());
      layoutParams3.height = (int)(g3.b() / g3.f());
      a1 = this.g;
      if (bool) {
        str1 = "close-portrait";
      } else {
        str1 = "close-landscape";
      } 
      Point point1 = a.a(a1, str1);
      Point point4 = a.b(getContext());
      int i = layoutParams2.leftMargin;
      int j = layoutParams2.width;
      int k = Math.round((point1.x + point4.x));
      int m = layoutParams2.topMargin;
      int n = layoutParams3.height;
      int i1 = Math.round((point1.y + point4.y));
      layoutParams3.leftMargin = Math.min(Math.max(0, i + j + k), param1Int1 - layoutParams3.width);
      layoutParams3.topMargin = Math.min(Math.max(0, i1 + m - n), param1Int2 - layoutParams3.height);
      this.d.setLayoutParams((ViewGroup.LayoutParams)layoutParams1);
      this.c.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
      this.e.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
      BitmapDrawable bitmapDrawable = new BitmapDrawable(g1.e());
      this.d.setScaleType(ImageView.ScaleType.FIT_CENTER);
      this.d.setImageDrawable((Drawable)bitmapDrawable);
      bitmapDrawable = new BitmapDrawable(g2.e());
      this.c.setScaleType(ImageView.ScaleType.FIT_CENTER);
      this.c.setImageDrawable((Drawable)bitmapDrawable);
      bitmapDrawable = new BitmapDrawable(g3.e());
      this.e.setBackgroundDrawable((Drawable)bitmapDrawable);
    }
    
    public void c() {
      super.c();
      this.d = null;
      this.c = null;
      this.e = null;
    }
  }
  
  class null implements View.OnClickListener {
    null(a this$0, a param1a) {}
    
    public void onClick(View param1View) {
      if (this.b.g.a != null)
        this.b.g.a.a(); 
    }
  }
  
  class null implements View.OnClickListener {
    null(a this$0, a param1a) {}
    
    public void onClick(View param1View) {
      if (this.b.g.b != null)
        this.b.g.b.a(a.a(this.b.g), null, null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */