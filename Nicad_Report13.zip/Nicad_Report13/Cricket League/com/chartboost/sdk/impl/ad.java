package com.chartboost.sdk.impl;

public class ad {
  public static String a(Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    a(paramObject, stringBuilder);
    return stringBuilder.toString();
  }
  
  public static void a(Object paramObject, StringBuilder paramStringBuilder) {
    ae.a().a(paramObject, paramStringBuilder);
  }
  
  static void a(StringBuilder paramStringBuilder, String paramString) {
    paramStringBuilder.append("\"");
    for (int i = 0; i < paramString.length(); i++) {
      char c = paramString.charAt(i);
      if (c == '\\') {
        paramStringBuilder.append("\\\\");
      } else if (c == '"') {
        paramStringBuilder.append("\\\"");
      } else if (c == '\n') {
        paramStringBuilder.append("\\n");
      } else if (c == '\r') {
        paramStringBuilder.append("\\r");
      } else if (c == '\t') {
        paramStringBuilder.append("\\t");
      } else if (c == '\b') {
        paramStringBuilder.append("\\b");
      } else if (c >= ' ') {
        paramStringBuilder.append(c);
      } 
    } 
    paramStringBuilder.append("\"");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */