package com.chartboost.sdk.impl;

public class x extends ar implements z {
  public x() {}
  
  public x(String paramString, Object paramObject) {
    super(paramString, paramObject);
  }
  
  public String toString() {
    return ad.a(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */