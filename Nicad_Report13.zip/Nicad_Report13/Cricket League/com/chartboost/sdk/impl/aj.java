package com.chartboost.sdk.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class aj extends OutputStream {
  private static final byte[] a = new byte[0];
  
  private final List<byte[]> b;
  
  private int c;
  
  private int d;
  
  private byte[] e;
  
  private int f;
  
  public aj() {
    this(1024);
  }
  
  public aj(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: new java/util/ArrayList
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: putfield b : Ljava/util/List;
    //   15: iload_1
    //   16: ifge -> 46
    //   19: new java/lang/IllegalArgumentException
    //   22: dup
    //   23: new java/lang/StringBuilder
    //   26: dup
    //   27: invokespecial <init> : ()V
    //   30: ldc 'Negative initial size: '
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: iload_1
    //   36: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   39: invokevirtual toString : ()Ljava/lang/String;
    //   42: invokespecial <init> : (Ljava/lang/String;)V
    //   45: athrow
    //   46: aload_0
    //   47: monitorenter
    //   48: aload_0
    //   49: iload_1
    //   50: invokespecial a : (I)V
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: astore_2
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_2
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   48	55	56	finally
    //   57	59	56	finally
  }
  
  private void a(int paramInt) {
    if (this.c < this.b.size() - 1) {
      this.d += this.e.length;
      this.c++;
      this.e = this.b.get(this.c);
      return;
    } 
    if (this.e == null) {
      this.d = 0;
    } else {
      paramInt = Math.max(this.e.length << 1, paramInt - this.d);
      this.d += this.e.length;
    } 
    this.c++;
    this.e = new byte[paramInt];
    this.b.add(this.e);
  }
  
  public byte[] a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : I
    //   6: istore_2
    //   7: iload_2
    //   8: ifne -> 21
    //   11: getstatic com/chartboost/sdk/impl/aj.a : [B
    //   14: astore #4
    //   16: aload_0
    //   17: monitorexit
    //   18: aload #4
    //   20: areturn
    //   21: iload_2
    //   22: newarray byte
    //   24: astore #4
    //   26: aload_0
    //   27: getfield b : Ljava/util/List;
    //   30: invokeinterface iterator : ()Ljava/util/Iterator;
    //   35: astore #5
    //   37: iconst_0
    //   38: istore_1
    //   39: aload #5
    //   41: invokeinterface hasNext : ()Z
    //   46: ifeq -> 87
    //   49: aload #5
    //   51: invokeinterface next : ()Ljava/lang/Object;
    //   56: checkcast [B
    //   59: astore #6
    //   61: aload #6
    //   63: arraylength
    //   64: iload_2
    //   65: invokestatic min : (II)I
    //   68: istore_3
    //   69: aload #6
    //   71: iconst_0
    //   72: aload #4
    //   74: iload_1
    //   75: iload_3
    //   76: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   79: iload_2
    //   80: iload_3
    //   81: isub
    //   82: istore_2
    //   83: iload_2
    //   84: ifne -> 90
    //   87: goto -> 16
    //   90: iload_1
    //   91: iload_3
    //   92: iadd
    //   93: istore_1
    //   94: goto -> 39
    //   97: astore #4
    //   99: aload_0
    //   100: monitorexit
    //   101: aload #4
    //   103: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	97	finally
    //   11	16	97	finally
    //   21	37	97	finally
    //   39	79	97	finally
  }
  
  public void close() throws IOException {}
  
  public String toString() {
    return new String(a());
  }
  
  public void write(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : I
    //   6: aload_0
    //   7: getfield d : I
    //   10: isub
    //   11: istore_3
    //   12: iload_3
    //   13: istore_2
    //   14: iload_3
    //   15: aload_0
    //   16: getfield e : [B
    //   19: arraylength
    //   20: if_icmpne -> 35
    //   23: aload_0
    //   24: aload_0
    //   25: getfield f : I
    //   28: iconst_1
    //   29: iadd
    //   30: invokespecial a : (I)V
    //   33: iconst_0
    //   34: istore_2
    //   35: aload_0
    //   36: getfield e : [B
    //   39: iload_2
    //   40: iload_1
    //   41: i2b
    //   42: bastore
    //   43: aload_0
    //   44: aload_0
    //   45: getfield f : I
    //   48: iconst_1
    //   49: iadd
    //   50: putfield f : I
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: astore #4
    //   58: aload_0
    //   59: monitorexit
    //   60: aload #4
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	56	finally
    //   14	33	56	finally
    //   35	53	56	finally
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: iflt -> 28
    //   4: iload_2
    //   5: aload_1
    //   6: arraylength
    //   7: if_icmpgt -> 28
    //   10: iload_3
    //   11: iflt -> 28
    //   14: iload_2
    //   15: iload_3
    //   16: iadd
    //   17: aload_1
    //   18: arraylength
    //   19: if_icmpgt -> 28
    //   22: iload_2
    //   23: iload_3
    //   24: iadd
    //   25: ifge -> 36
    //   28: new java/lang/IndexOutOfBoundsException
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: athrow
    //   36: iload_3
    //   37: ifne -> 41
    //   40: return
    //   41: aload_0
    //   42: monitorenter
    //   43: aload_0
    //   44: getfield f : I
    //   47: iload_3
    //   48: iadd
    //   49: istore #7
    //   51: aload_0
    //   52: getfield f : I
    //   55: aload_0
    //   56: getfield d : I
    //   59: isub
    //   60: istore #5
    //   62: iload_3
    //   63: istore #4
    //   65: iload #4
    //   67: ifle -> 135
    //   70: iload #4
    //   72: aload_0
    //   73: getfield e : [B
    //   76: arraylength
    //   77: iload #5
    //   79: isub
    //   80: invokestatic min : (II)I
    //   83: istore #6
    //   85: aload_1
    //   86: iload_2
    //   87: iload_3
    //   88: iadd
    //   89: iload #4
    //   91: isub
    //   92: aload_0
    //   93: getfield e : [B
    //   96: iload #5
    //   98: iload #6
    //   100: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   103: iload #4
    //   105: iload #6
    //   107: isub
    //   108: istore #6
    //   110: iload #6
    //   112: istore #4
    //   114: iload #6
    //   116: ifle -> 65
    //   119: aload_0
    //   120: iload #7
    //   122: invokespecial a : (I)V
    //   125: iconst_0
    //   126: istore #5
    //   128: iload #6
    //   130: istore #4
    //   132: goto -> 65
    //   135: aload_0
    //   136: iload #7
    //   138: putfield f : I
    //   141: aload_0
    //   142: monitorexit
    //   143: return
    //   144: astore_1
    //   145: aload_0
    //   146: monitorexit
    //   147: aload_1
    //   148: athrow
    // Exception table:
    //   from	to	target	type
    //   43	62	144	finally
    //   70	103	144	finally
    //   119	125	144	finally
    //   135	143	144	finally
    //   145	147	144	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */