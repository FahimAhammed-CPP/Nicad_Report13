package com.chartboost.sdk.impl;

import java.util.LinkedHashMap;
import java.util.Map;

public class ar extends LinkedHashMap<String, Object> implements ao {
  public ar() {}
  
  public ar(String paramString, Object paramObject) {
    a(paramString, paramObject);
  }
  
  public Object a(String paramString) {
    return get(paramString);
  }
  
  public Object a(String paramString, Object paramObject) {
    return super.put(paramString, paramObject);
  }
  
  public boolean b(String paramString) {
    return containsKey(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof ao))
      return false; 
    paramObject = paramObject;
    if (!keySet().equals(paramObject.keySet()))
      return false; 
    for (String str : keySet()) {
      Object object1 = a(str);
      Object object2 = paramObject.a(str);
      if (object1 == null && object2 != null)
        return false; 
      if (object2 == null) {
        if (object1 != null)
          return false; 
        continue;
      } 
      if (object1 instanceof Number && object2 instanceof Number) {
        if (((Number)object1).doubleValue() != ((Number)object2).doubleValue())
          return false; 
        continue;
      } 
      if (object1 instanceof java.util.regex.Pattern && object2 instanceof java.util.regex.Pattern) {
        object1 = object1;
        object2 = object2;
        if (!object1.pattern().equals(object2.pattern()) || object1.flags() != object2.flags())
          return false; 
        continue;
      } 
      if (!object1.equals(object2))
        return false; 
    } 
    return true;
  }
  
  public void putAll(Map paramMap) {
    for (Map.Entry entry : paramMap.entrySet())
      a(entry.getKey().toString(), entry.getValue()); 
  }
  
  public String toString() {
    return ad.a(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */