package com.chartboost.sdk.impl;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.view.View;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBOrientation;

public final class v extends View {
  private Handler a;
  
  private float b;
  
  private long c;
  
  private Paint d;
  
  private Paint e;
  
  private Path f;
  
  private Path g;
  
  private RectF h;
  
  private RectF i;
  
  private Bitmap j = null;
  
  private Canvas k = null;
  
  private Runnable l = new Runnable(this) {
      public void run() {
        float f1;
        CBOrientation.Difference difference = CBPreferences.getInstance().getForcedOrientationDifference();
        float f2 = (this.a.getContext().getResources().getDisplayMetrics()).density;
        v.a(this.a, 1.0F * f2);
        if (difference.isOdd()) {
          f1 = this.a.getWidth();
        } else {
          f1 = this.a.getHeight();
        } 
        f1 -= f2 * 9.0F;
        if (v.a(this.a) > f1)
          v.b(this.a, f1 * 2.0F); 
        if (this.a.getWindowVisibility() == 0)
          this.a.invalidate(); 
      }
    };
  
  public v(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.b = 0.0F;
    this.a = new Handler();
    this.c = (long)(System.nanoTime() / 1000000.0D);
    this.d = new Paint();
    this.d.setColor(-1);
    this.d.setStyle(Paint.Style.STROKE);
    this.d.setStrokeWidth(f * 3.0F);
    this.d.setAntiAlias(true);
    this.e = new Paint();
    this.e.setColor(-1);
    this.e.setStyle(Paint.Style.FILL);
    this.e.setAntiAlias(true);
    this.f = new Path();
    this.g = new Path();
    this.i = new RectF();
    this.h = new RectF();
    try {
      getClass().getMethod("setLayerType", new Class[] { int.class, Paint.class }).invoke(this, new Object[] { Integer.valueOf(1), null });
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  private boolean a(Canvas paramCanvas) {
    try {
      return ((Boolean)Canvas.class.getMethod("isHardwareAccelerated", new Class[0]).invoke(paramCanvas, new Object[0])).booleanValue();
    } catch (Exception exception) {
      return false;
    } 
  }
  
  protected void onAttachedToWindow() {
    this.a.removeCallbacks(this.l);
    this.a.post(this.l);
  }
  
  protected void onDetachedFromWindow() {
    this.a.removeCallbacks(this.l);
    if (this.j != null && !this.j.isRecycled())
      this.j.recycle(); 
    this.j = null;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   7: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   10: getfield density : F
    //   13: fstore_2
    //   14: aload_0
    //   15: aload_1
    //   16: invokespecial a : (Landroid/graphics/Canvas;)Z
    //   19: istore #6
    //   21: aconst_null
    //   22: astore #10
    //   24: aload_1
    //   25: astore #9
    //   27: iload #6
    //   29: ifeq -> 141
    //   32: aload_0
    //   33: getfield j : Landroid/graphics/Bitmap;
    //   36: ifnull -> 67
    //   39: aload_0
    //   40: getfield j : Landroid/graphics/Bitmap;
    //   43: invokevirtual getWidth : ()I
    //   46: aload_1
    //   47: invokevirtual getWidth : ()I
    //   50: if_icmpne -> 67
    //   53: aload_0
    //   54: getfield j : Landroid/graphics/Bitmap;
    //   57: invokevirtual getHeight : ()I
    //   60: aload_1
    //   61: invokevirtual getHeight : ()I
    //   64: if_icmpeq -> 124
    //   67: aload_0
    //   68: getfield j : Landroid/graphics/Bitmap;
    //   71: ifnull -> 91
    //   74: aload_0
    //   75: getfield j : Landroid/graphics/Bitmap;
    //   78: invokevirtual isRecycled : ()Z
    //   81: ifne -> 91
    //   84: aload_0
    //   85: getfield j : Landroid/graphics/Bitmap;
    //   88: invokevirtual recycle : ()V
    //   91: aload_0
    //   92: aload_1
    //   93: invokevirtual getWidth : ()I
    //   96: aload_1
    //   97: invokevirtual getHeight : ()I
    //   100: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
    //   103: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    //   106: putfield j : Landroid/graphics/Bitmap;
    //   109: aload_0
    //   110: new android/graphics/Canvas
    //   113: dup
    //   114: aload_0
    //   115: getfield j : Landroid/graphics/Bitmap;
    //   118: invokespecial <init> : (Landroid/graphics/Bitmap;)V
    //   121: putfield k : Landroid/graphics/Canvas;
    //   124: aload_0
    //   125: getfield j : Landroid/graphics/Bitmap;
    //   128: iconst_0
    //   129: invokevirtual eraseColor : (I)V
    //   132: aload_0
    //   133: getfield k : Landroid/graphics/Canvas;
    //   136: astore #9
    //   138: aload_1
    //   139: astore #10
    //   141: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
    //   144: invokevirtual getForcedOrientationDifference : ()Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
    //   147: astore_1
    //   148: aload #9
    //   150: invokevirtual save : ()I
    //   153: pop
    //   154: aload_1
    //   155: invokevirtual isReverse : ()Z
    //   158: ifeq -> 182
    //   161: aload #9
    //   163: ldc 180.0
    //   165: aload_0
    //   166: invokevirtual getWidth : ()I
    //   169: i2f
    //   170: fconst_2
    //   171: fdiv
    //   172: aload_0
    //   173: invokevirtual getHeight : ()I
    //   176: i2f
    //   177: fconst_2
    //   178: fdiv
    //   179: invokevirtual rotate : (FFF)V
    //   182: aload_0
    //   183: getfield h : Landroid/graphics/RectF;
    //   186: fconst_0
    //   187: fconst_0
    //   188: aload_0
    //   189: invokevirtual getWidth : ()I
    //   192: i2f
    //   193: aload_0
    //   194: invokevirtual getHeight : ()I
    //   197: i2f
    //   198: invokevirtual set : (FFFF)V
    //   201: aload_0
    //   202: getfield h : Landroid/graphics/RectF;
    //   205: ldc_w 1.5
    //   208: fload_2
    //   209: fmul
    //   210: ldc_w 1.5
    //   213: fload_2
    //   214: fmul
    //   215: invokevirtual inset : (FF)V
    //   218: aload_1
    //   219: invokevirtual isOdd : ()Z
    //   222: ifeq -> 527
    //   225: aload_0
    //   226: invokevirtual getWidth : ()I
    //   229: istore #5
    //   231: iload #5
    //   233: i2f
    //   234: fconst_2
    //   235: fdiv
    //   236: fstore_3
    //   237: aload #9
    //   239: aload_0
    //   240: getfield h : Landroid/graphics/RectF;
    //   243: fload_3
    //   244: fload_3
    //   245: aload_0
    //   246: getfield d : Landroid/graphics/Paint;
    //   249: invokevirtual drawRoundRect : (Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V
    //   252: aload_0
    //   253: getfield i : Landroid/graphics/RectF;
    //   256: aload_0
    //   257: getfield h : Landroid/graphics/RectF;
    //   260: invokevirtual set : (Landroid/graphics/RectF;)V
    //   263: aload_0
    //   264: getfield i : Landroid/graphics/RectF;
    //   267: ldc 3.0
    //   269: fload_2
    //   270: fmul
    //   271: fload_2
    //   272: ldc 3.0
    //   274: fmul
    //   275: invokevirtual inset : (FF)V
    //   278: aload_1
    //   279: invokevirtual isOdd : ()Z
    //   282: ifeq -> 536
    //   285: aload_0
    //   286: getfield i : Landroid/graphics/RectF;
    //   289: invokevirtual width : ()F
    //   292: fstore_2
    //   293: fload_2
    //   294: fconst_2
    //   295: fdiv
    //   296: fstore_2
    //   297: aload_0
    //   298: getfield f : Landroid/graphics/Path;
    //   301: invokevirtual reset : ()V
    //   304: aload_0
    //   305: getfield f : Landroid/graphics/Path;
    //   308: aload_0
    //   309: getfield i : Landroid/graphics/RectF;
    //   312: fload_2
    //   313: fload_2
    //   314: getstatic android/graphics/Path$Direction.CW : Landroid/graphics/Path$Direction;
    //   317: invokevirtual addRoundRect : (Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V
    //   320: aload_1
    //   321: invokevirtual isOdd : ()Z
    //   324: ifeq -> 547
    //   327: aload_0
    //   328: getfield i : Landroid/graphics/RectF;
    //   331: invokevirtual width : ()F
    //   334: fstore_2
    //   335: aload_0
    //   336: getfield g : Landroid/graphics/Path;
    //   339: invokevirtual reset : ()V
    //   342: aload_1
    //   343: invokevirtual isOdd : ()Z
    //   346: ifeq -> 558
    //   349: aload_0
    //   350: getfield g : Landroid/graphics/Path;
    //   353: fload_2
    //   354: fconst_0
    //   355: invokevirtual moveTo : (FF)V
    //   358: aload_0
    //   359: getfield g : Landroid/graphics/Path;
    //   362: fload_2
    //   363: fload_2
    //   364: invokevirtual lineTo : (FF)V
    //   367: aload_0
    //   368: getfield g : Landroid/graphics/Path;
    //   371: fconst_0
    //   372: fload_2
    //   373: fconst_2
    //   374: fmul
    //   375: invokevirtual lineTo : (FF)V
    //   378: aload_0
    //   379: getfield g : Landroid/graphics/Path;
    //   382: fconst_0
    //   383: fload_2
    //   384: invokevirtual lineTo : (FF)V
    //   387: aload_0
    //   388: getfield g : Landroid/graphics/Path;
    //   391: invokevirtual close : ()V
    //   394: aload #9
    //   396: invokevirtual save : ()I
    //   399: pop
    //   400: iconst_1
    //   401: istore #5
    //   403: aload #9
    //   405: aload_0
    //   406: getfield f : Landroid/graphics/Path;
    //   409: invokevirtual clipPath : (Landroid/graphics/Path;)Z
    //   412: pop
    //   413: iload #5
    //   415: ifeq -> 648
    //   418: fload_2
    //   419: fneg
    //   420: aload_0
    //   421: getfield b : F
    //   424: fadd
    //   425: fstore_3
    //   426: aload_1
    //   427: invokevirtual isOdd : ()Z
    //   430: ifeq -> 607
    //   433: aload_0
    //   434: getfield i : Landroid/graphics/RectF;
    //   437: invokevirtual height : ()F
    //   440: fstore #4
    //   442: fload_3
    //   443: fload #4
    //   445: fload_2
    //   446: fadd
    //   447: fcmpg
    //   448: ifge -> 648
    //   451: aload_1
    //   452: invokevirtual isOdd : ()Z
    //   455: ifeq -> 619
    //   458: aload_0
    //   459: getfield i : Landroid/graphics/RectF;
    //   462: getfield top : F
    //   465: fstore #4
    //   467: fload #4
    //   469: fload_3
    //   470: fadd
    //   471: fstore #4
    //   473: aload #9
    //   475: invokevirtual save : ()I
    //   478: pop
    //   479: aload_1
    //   480: invokevirtual isOdd : ()Z
    //   483: ifeq -> 631
    //   486: aload #9
    //   488: aload_0
    //   489: getfield i : Landroid/graphics/RectF;
    //   492: getfield left : F
    //   495: fload #4
    //   497: invokevirtual translate : (FF)V
    //   500: aload #9
    //   502: aload_0
    //   503: getfield g : Landroid/graphics/Path;
    //   506: aload_0
    //   507: getfield e : Landroid/graphics/Paint;
    //   510: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   513: aload #9
    //   515: invokevirtual restore : ()V
    //   518: fload_3
    //   519: fconst_2
    //   520: fload_2
    //   521: fmul
    //   522: fadd
    //   523: fstore_3
    //   524: goto -> 426
    //   527: aload_0
    //   528: invokevirtual getHeight : ()I
    //   531: istore #5
    //   533: goto -> 231
    //   536: aload_0
    //   537: getfield i : Landroid/graphics/RectF;
    //   540: invokevirtual height : ()F
    //   543: fstore_2
    //   544: goto -> 293
    //   547: aload_0
    //   548: getfield i : Landroid/graphics/RectF;
    //   551: invokevirtual height : ()F
    //   554: fstore_2
    //   555: goto -> 335
    //   558: aload_0
    //   559: getfield g : Landroid/graphics/Path;
    //   562: fconst_0
    //   563: fload_2
    //   564: invokevirtual moveTo : (FF)V
    //   567: aload_0
    //   568: getfield g : Landroid/graphics/Path;
    //   571: fload_2
    //   572: fload_2
    //   573: invokevirtual lineTo : (FF)V
    //   576: aload_0
    //   577: getfield g : Landroid/graphics/Path;
    //   580: fload_2
    //   581: fconst_2
    //   582: fmul
    //   583: fconst_0
    //   584: invokevirtual lineTo : (FF)V
    //   587: aload_0
    //   588: getfield g : Landroid/graphics/Path;
    //   591: fload_2
    //   592: fconst_0
    //   593: invokevirtual lineTo : (FF)V
    //   596: goto -> 387
    //   599: astore #11
    //   601: iconst_0
    //   602: istore #5
    //   604: goto -> 413
    //   607: aload_0
    //   608: getfield i : Landroid/graphics/RectF;
    //   611: invokevirtual width : ()F
    //   614: fstore #4
    //   616: goto -> 442
    //   619: aload_0
    //   620: getfield i : Landroid/graphics/RectF;
    //   623: getfield left : F
    //   626: fstore #4
    //   628: goto -> 467
    //   631: aload #9
    //   633: fload #4
    //   635: aload_0
    //   636: getfield i : Landroid/graphics/RectF;
    //   639: getfield top : F
    //   642: invokevirtual translate : (FF)V
    //   645: goto -> 500
    //   648: aload #9
    //   650: invokevirtual restore : ()V
    //   653: aload #9
    //   655: invokevirtual restore : ()V
    //   658: iload #6
    //   660: ifeq -> 680
    //   663: aload #10
    //   665: ifnull -> 680
    //   668: aload #10
    //   670: aload_0
    //   671: getfield j : Landroid/graphics/Bitmap;
    //   674: fconst_0
    //   675: fconst_0
    //   676: aconst_null
    //   677: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V
    //   680: lconst_0
    //   681: ldc2_w 16
    //   684: invokestatic nanoTime : ()J
    //   687: l2d
    //   688: ldc2_w 1000000.0
    //   691: ddiv
    //   692: d2l
    //   693: aload_0
    //   694: getfield c : J
    //   697: lsub
    //   698: lsub
    //   699: invokestatic max : (JJ)J
    //   702: lstore #7
    //   704: aload_0
    //   705: getfield a : Landroid/os/Handler;
    //   708: aload_0
    //   709: getfield l : Ljava/lang/Runnable;
    //   712: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   715: aload_0
    //   716: getfield a : Landroid/os/Handler;
    //   719: aload_0
    //   720: getfield l : Ljava/lang/Runnable;
    //   723: lload #7
    //   725: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   728: pop
    //   729: return
    //   730: astore_1
    //   731: return
    // Exception table:
    //   from	to	target	type
    //   91	124	730	java/lang/Throwable
    //   403	413	599	java/lang/UnsupportedOperationException
  }
  
  protected void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.a.removeCallbacks(this.l);
    if (paramInt == 0)
      this.a.post(this.l); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */