package com.chartboost.sdk.impl;

import android.content.SharedPreferences;
import android.os.Handler;
import android.util.SparseArray;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBUtility;
import com.chartboost.sdk.Libraries.f;
import com.chartboost.sdk.Model.CBError;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public final class i {
  public static f.a a = f.a(new f.a[] { f.a(), (f.a)new f.c() {
          public String a() {
            return "Must be a valid status code (>=200 && <300)";
          }
          
          public boolean a(Object param1Object) {
            int i = ((Number)param1Object).intValue();
            return (i >= 200 && i < 300);
          }
        } });
  
  private static int b = 0;
  
  private static List<Runnable> h = new ArrayList<Runnable>();
  
  private String c;
  
  private String d;
  
  private SparseArray<a> e;
  
  private int f;
  
  private Handler g = new Handler();
  
  public i(String paramString1, String paramString2) {
    this.c = paramString1;
    this.d = paramString2;
    this.e = new SparseArray();
    this.f = 1;
  }
  
  public static void a() {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: ldc com/chartboost/sdk/Libraries/c
    //   10: monitorenter
    //   11: aload_1
    //   12: getstatic com/chartboost/sdk/impl/i.h : Ljava/util/List;
    //   15: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   20: pop
    //   21: getstatic com/chartboost/sdk/impl/i.h : Ljava/util/List;
    //   24: invokeinterface clear : ()V
    //   29: ldc com/chartboost/sdk/Libraries/c
    //   31: monitorexit
    //   32: iconst_0
    //   33: istore_0
    //   34: iload_0
    //   35: aload_1
    //   36: invokeinterface size : ()I
    //   41: if_icmpge -> 75
    //   44: invokestatic a : ()Ljava/util/concurrent/ExecutorService;
    //   47: aload_1
    //   48: iload_0
    //   49: invokeinterface get : (I)Ljava/lang/Object;
    //   54: checkcast java/lang/Runnable
    //   57: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   62: iload_0
    //   63: iconst_1
    //   64: iadd
    //   65: istore_0
    //   66: goto -> 34
    //   69: astore_1
    //   70: ldc com/chartboost/sdk/Libraries/c
    //   72: monitorexit
    //   73: aload_1
    //   74: athrow
    //   75: return
    // Exception table:
    //   from	to	target	type
    //   11	32	69	finally
    //   70	73	69	finally
  }
  
  public void a(j paramj) {
    a(paramj, null);
  }
  
  public void a(j paramj, b paramb) {
    int k = this.f;
    this.f = k + 1;
    a a1 = new a(this, k, paramj, paramb);
    if (!l.a()) {
      a1.a(new CBError(CBError.a.b, null));
      return;
    } 
    this.e.put(k, a1);
    a(new d(this, a1));
  }
  
  public void a(Runnable paramRunnable) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: ldc com/chartboost/sdk/Libraries/c
    //   4: monitorenter
    //   5: invokestatic c : ()Lcom/chartboost/sdk/Libraries/c$a;
    //   8: astore_3
    //   9: aload_3
    //   10: getstatic com/chartboost/sdk/Libraries/c$a.a : Lcom/chartboost/sdk/Libraries/c$a;
    //   13: if_acmpeq -> 23
    //   16: aload_3
    //   17: getstatic com/chartboost/sdk/Libraries/c$a.b : Lcom/chartboost/sdk/Libraries/c$a;
    //   20: if_acmpne -> 50
    //   23: getstatic com/chartboost/sdk/impl/i.h : Ljava/util/List;
    //   26: aload_1
    //   27: invokeinterface add : (Ljava/lang/Object;)Z
    //   32: pop
    //   33: ldc com/chartboost/sdk/Libraries/c
    //   35: monitorexit
    //   36: iload_2
    //   37: ifeq -> 49
    //   40: invokestatic a : ()Ljava/util/concurrent/ExecutorService;
    //   43: aload_1
    //   44: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   49: return
    //   50: iconst_1
    //   51: istore_2
    //   52: goto -> 33
    //   55: astore_1
    //   56: ldc com/chartboost/sdk/Libraries/c
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   5	23	55	finally
    //   23	33	55	finally
    //   33	36	55	finally
    //   56	59	55	finally
  }
  
  public void b() {
    if (l.a()) {
      SharedPreferences sharedPreferences = CBUtility.a();
      String str1 = "CBQueuedRequests-" + this.d;
      String str2 = sharedPreferences.getString(str1, null);
      if (str2 != null) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(str1, null);
        editor.commit();
        try {
          JSONArray jSONArray = new JSONArray(new JSONTokener(str2));
          for (int j = 0;; j++) {
            int k = jSONArray.length();
            if (j < k) {
              try {
                j j1 = j.a(jSONArray.getJSONObject(j));
                if (j1 != null)
                  a(j1); 
              } catch (Exception exception) {}
            } else {
              return;
            } 
          } 
        } catch (Exception exception) {
          CBLogging.d("CBAPIConnection", "Retrying request list failed", exception);
          return;
        } 
      } 
    } 
  }
  
  private class a implements Serializable {
    private j b;
    
    private JSONObject c;
    
    private Integer d;
    
    private i.b e;
    
    public a(i this$0, int param1Int, j param1j, i.b param1b) {
      this.d = Integer.valueOf(param1Int);
      this.b = param1j;
      this.e = param1b;
      this.c = null;
    }
    
    public void a(CBError param1CBError) {
      if (this.b.f() && i.a(this.a) != null) {
        SharedPreferences sharedPreferences = CBUtility.a();
        String str = "CBQueuedRequests-" + i.a(this.a);
        try {
          JSONArray jSONArray;
          JSONObject jSONObject = this.b.h();
          if (jSONObject != null) {
            String str1 = sharedPreferences.getString(str, null);
            if (str1 != null) {
              try {
                jSONArray = new JSONArray(new JSONTokener(str1));
              } catch (Exception null) {}
            } else {
              jSONArray = new JSONArray();
            } 
          } else {
            return;
          } 
          jSONArray.put(jSONObject);
          SharedPreferences.Editor editor = sharedPreferences.edit();
          editor.putString(str, jSONArray.toString());
          editor.commit();
          return;
        } catch (Exception exception) {
          CBLogging.d("CBAPIConnection", "Unable to save failed request", exception);
          return;
        } 
      } 
      if (this.e != null)
        this.e.a(this.b, (CBError)exception); 
    }
  }
  
  public static interface b {
    void a(j param1j, CBError param1CBError);
    
    void a(JSONObject param1JSONObject, j param1j);
  }
  
  public static abstract class c implements b {
    public void a(j param1j, CBError param1CBError) {}
  }
  
  private class d implements Runnable {
    private i.a b;
    
    public d(i this$0, i.a param1a) {
      this.b = param1a;
    }
    
    private void a(boolean param1Boolean, CBError param1CBError) {
      i.d(this.a).post(new Runnable(this, param1Boolean, param1CBError) {
            public void run() {
              i.a a = i.d.a(this.c);
              if (this.a && i.a.c(a) != null) {
                if (i.a.d(a) != null)
                  i.a.d(a).a(i.a.c(a), i.a.a(a)); 
                return;
              } 
              a.a(this.b);
            }
          });
    }
    
    public void run() {
      // Byte code:
      //   0: aconst_null
      //   1: astore #4
      //   3: aconst_null
      //   4: astore #6
      //   6: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
      //   9: astore #8
      //   11: aload_0
      //   12: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   15: invokestatic a : (Lcom/chartboost/sdk/impl/i$a;)Lcom/chartboost/sdk/impl/j;
      //   18: astore #5
      //   20: aload #5
      //   22: invokevirtual a : ()V
      //   25: aload #5
      //   27: aload #8
      //   29: invokevirtual getAppID : ()Ljava/lang/String;
      //   32: aload #8
      //   34: invokevirtual getAppSignature : ()Ljava/lang/String;
      //   37: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
      //   40: aload_0
      //   41: getfield a : Lcom/chartboost/sdk/impl/i;
      //   44: invokestatic b : (Lcom/chartboost/sdk/impl/i;)Ljava/lang/String;
      //   47: ifnonnull -> 220
      //   50: ldc 'https://live.chartboost.com'
      //   52: astore_3
      //   53: new org/apache/http/client/methods/HttpPost
      //   56: dup
      //   57: new java/lang/StringBuilder
      //   60: dup
      //   61: invokespecial <init> : ()V
      //   64: aload_3
      //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   68: aload #5
      //   70: invokevirtual b : ()Ljava/lang/String;
      //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   76: invokevirtual toString : ()Ljava/lang/String;
      //   79: invokespecial <init> : (Ljava/lang/String;)V
      //   82: astore #7
      //   84: aload #7
      //   86: ldc 'Content-Type'
      //   88: ldc 'application/json; charset=UTF-8'
      //   90: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   93: aload #7
      //   95: ldc 'Accept'
      //   97: ldc 'application/json; charset=UTF-8'
      //   99: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   102: aload #7
      //   104: ldc 'X-Chartboost-Client'
      //   106: aload #8
      //   108: invokestatic a : (Lcom/chartboost/sdk/CBPreferences;)Ljava/lang/String;
      //   111: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   114: aload #7
      //   116: ldc 'X-Chartboost-API'
      //   118: ldc '3.4.0'
      //   120: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   123: aload #7
      //   125: ldc 'X-Chartboost-Client'
      //   127: aload #8
      //   129: invokestatic a : (Lcom/chartboost/sdk/CBPreferences;)Ljava/lang/String;
      //   132: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   135: aload #5
      //   137: invokevirtual e : ()Ljava/util/Map;
      //   140: astore_3
      //   141: aload_3
      //   142: ifnull -> 236
      //   145: aload_3
      //   146: invokeinterface entrySet : ()Ljava/util/Set;
      //   151: invokeinterface iterator : ()Ljava/util/Iterator;
      //   156: astore #8
      //   158: aload #8
      //   160: invokeinterface hasNext : ()Z
      //   165: ifeq -> 236
      //   168: aload #8
      //   170: invokeinterface next : ()Ljava/lang/Object;
      //   175: checkcast java/util/Map$Entry
      //   178: astore_3
      //   179: aload_3
      //   180: invokeinterface getKey : ()Ljava/lang/Object;
      //   185: checkcast java/lang/String
      //   188: astore #9
      //   190: aload_3
      //   191: invokeinterface getValue : ()Ljava/lang/Object;
      //   196: ifnull -> 231
      //   199: aload_3
      //   200: invokeinterface getValue : ()Ljava/lang/Object;
      //   205: invokevirtual toString : ()Ljava/lang/String;
      //   208: astore_3
      //   209: aload #7
      //   211: aload #9
      //   213: aload_3
      //   214: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
      //   217: goto -> 158
      //   220: aload_0
      //   221: getfield a : Lcom/chartboost/sdk/impl/i;
      //   224: invokestatic b : (Lcom/chartboost/sdk/impl/i;)Ljava/lang/String;
      //   227: astore_3
      //   228: goto -> 53
      //   231: aconst_null
      //   232: astore_3
      //   233: goto -> 209
      //   236: aload_0
      //   237: getfield a : Lcom/chartboost/sdk/impl/i;
      //   240: astore_3
      //   241: aload_3
      //   242: monitorenter
      //   243: invokestatic c : ()I
      //   246: pop
      //   247: aload_3
      //   248: monitorexit
      //   249: aload #5
      //   251: invokevirtual d : ()Lorg/json/JSONObject;
      //   254: ifnull -> 294
      //   257: new org/apache/http/entity/StringEntity
      //   260: dup
      //   261: aload #5
      //   263: invokevirtual d : ()Lorg/json/JSONObject;
      //   266: invokevirtual toString : ()Ljava/lang/String;
      //   269: invokespecial <init> : (Ljava/lang/String;)V
      //   272: astore_3
      //   273: aload_3
      //   274: new org/apache/http/message/BasicHeader
      //   277: dup
      //   278: ldc 'Content-Type'
      //   280: ldc 'application/json'
      //   282: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
      //   285: invokevirtual setContentType : (Lorg/apache/http/Header;)V
      //   288: aload #7
      //   290: aload_3
      //   291: invokevirtual setEntity : (Lorg/apache/http/HttpEntity;)V
      //   294: invokestatic b : ()Lorg/apache/http/client/HttpClient;
      //   297: aload #7
      //   299: invokeinterface execute : (Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
      //   304: astore #5
      //   306: aload #5
      //   308: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
      //   313: invokeinterface getStatusCode : ()I
      //   318: istore_1
      //   319: aload #5
      //   321: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
      //   326: astore #6
      //   328: aload #6
      //   330: invokeinterface getContent : ()Ljava/io/InputStream;
      //   335: astore #7
      //   337: new java/io/BufferedReader
      //   340: dup
      //   341: new java/io/InputStreamReader
      //   344: dup
      //   345: aload #7
      //   347: ldc 'UTF-8'
      //   349: invokespecial <init> : (Ljava/io/InputStream;Ljava/lang/String;)V
      //   352: sipush #2048
      //   355: invokespecial <init> : (Ljava/io/Reader;I)V
      //   358: astore_3
      //   359: new java/lang/StringBuilder
      //   362: dup
      //   363: aload #7
      //   365: invokevirtual available : ()I
      //   368: invokespecial <init> : (I)V
      //   371: astore #7
      //   373: aload_3
      //   374: invokevirtual readLine : ()Ljava/lang/String;
      //   377: astore #8
      //   379: aload #8
      //   381: ifnull -> 566
      //   384: aload #7
      //   386: aload #8
      //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   391: ldc '\\n'
      //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   396: pop
      //   397: goto -> 373
      //   400: astore_3
      //   401: aload #5
      //   403: invokevirtual toString : ()Ljava/lang/String;
      //   406: astore_3
      //   407: iload_1
      //   408: sipush #300
      //   411: if_icmpge -> 717
      //   414: iload_1
      //   415: sipush #200
      //   418: if_icmplt -> 717
      //   421: aload_3
      //   422: ifnull -> 677
      //   425: new org/json/JSONObject
      //   428: dup
      //   429: new org/json/JSONTokener
      //   432: dup
      //   433: aload_3
      //   434: invokespecial <init> : (Ljava/lang/String;)V
      //   437: invokespecial <init> : (Lorg/json/JSONTokener;)V
      //   440: astore_3
      //   441: aload_0
      //   442: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   445: invokestatic a : (Lcom/chartboost/sdk/impl/i$a;)Lcom/chartboost/sdk/impl/j;
      //   448: invokevirtual g : ()Lcom/chartboost/sdk/Libraries/f$a;
      //   451: astore #7
      //   453: new java/lang/StringBuilder
      //   456: dup
      //   457: invokespecial <init> : ()V
      //   460: astore #8
      //   462: aload #7
      //   464: ifnull -> 579
      //   467: aload #7
      //   469: aload_3
      //   470: aload #8
      //   472: invokevirtual a : (Ljava/lang/Object;Ljava/lang/StringBuilder;)Z
      //   475: ifne -> 579
      //   478: new com/chartboost/sdk/Model/CBError
      //   481: dup
      //   482: getstatic com/chartboost/sdk/Model/CBError$a.d : Lcom/chartboost/sdk/Model/CBError$a;
      //   485: new java/lang/StringBuilder
      //   488: dup
      //   489: invokespecial <init> : ()V
      //   492: ldc 'Json response failed validation: '
      //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   497: aload #8
      //   499: invokevirtual toString : ()Ljava/lang/String;
      //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   505: invokevirtual toString : ()Ljava/lang/String;
      //   508: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   511: astore_3
      //   512: goto -> 775
      //   515: aload #6
      //   517: invokestatic a : (Lorg/apache/http/HttpEntity;)V
      //   520: aload_0
      //   521: getfield a : Lcom/chartboost/sdk/impl/i;
      //   524: invokestatic c : (Lcom/chartboost/sdk/impl/i;)Landroid/util/SparseArray;
      //   527: aload_0
      //   528: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   531: invokestatic b : (Lcom/chartboost/sdk/impl/i$a;)Ljava/lang/Integer;
      //   534: invokevirtual intValue : ()I
      //   537: invokevirtual remove : (I)V
      //   540: aload_0
      //   541: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   544: invokestatic c : (Lcom/chartboost/sdk/impl/i$a;)Lorg/json/JSONObject;
      //   547: ifnull -> 762
      //   550: iconst_1
      //   551: istore_2
      //   552: aload_0
      //   553: iload_2
      //   554: aload_3
      //   555: invokespecial a : (ZLcom/chartboost/sdk/Model/CBError;)V
      //   558: return
      //   559: astore #4
      //   561: aload_3
      //   562: monitorexit
      //   563: aload #4
      //   565: athrow
      //   566: aload_3
      //   567: invokevirtual close : ()V
      //   570: aload #7
      //   572: invokevirtual toString : ()Ljava/lang/String;
      //   575: astore_3
      //   576: goto -> 407
      //   579: aload_0
      //   580: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   583: aload_3
      //   584: invokestatic a : (Lcom/chartboost/sdk/impl/i$a;Lorg/json/JSONObject;)Lorg/json/JSONObject;
      //   587: pop
      //   588: aload #4
      //   590: astore_3
      //   591: goto -> 775
      //   594: astore_3
      //   595: aload #5
      //   597: astore #4
      //   599: new com/chartboost/sdk/Model/CBError
      //   602: dup
      //   603: getstatic com/chartboost/sdk/Model/CBError$a.a : Lcom/chartboost/sdk/Model/CBError$a;
      //   606: new java/lang/StringBuilder
      //   609: dup
      //   610: invokespecial <init> : ()V
      //   613: ldc_w 'Exception on http request: '
      //   616: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   619: aload_3
      //   620: invokevirtual getLocalizedMessage : ()Ljava/lang/String;
      //   623: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   626: invokevirtual toString : ()Ljava/lang/String;
      //   629: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   632: astore #5
      //   634: ldc_w 'CBAPIConnection'
      //   637: aload #5
      //   639: invokevirtual a : ()Ljava/lang/String;
      //   642: aload_3
      //   643: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Throwable;)V
      //   646: aload #4
      //   648: invokestatic a : (Lorg/apache/http/HttpResponse;)V
      //   651: aload_0
      //   652: getfield a : Lcom/chartboost/sdk/impl/i;
      //   655: invokestatic c : (Lcom/chartboost/sdk/impl/i;)Landroid/util/SparseArray;
      //   658: aload_0
      //   659: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   662: invokestatic b : (Lcom/chartboost/sdk/impl/i$a;)Ljava/lang/Integer;
      //   665: invokevirtual intValue : ()I
      //   668: invokevirtual remove : (I)V
      //   671: aload #5
      //   673: astore_3
      //   674: goto -> 540
      //   677: new com/chartboost/sdk/Model/CBError
      //   680: dup
      //   681: getstatic com/chartboost/sdk/Model/CBError$a.c : Lcom/chartboost/sdk/Model/CBError$a;
      //   684: ldc_w 'Response is not a valid json object'
      //   687: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   690: astore_3
      //   691: goto -> 515
      //   694: astore_3
      //   695: aload_0
      //   696: getfield a : Lcom/chartboost/sdk/impl/i;
      //   699: invokestatic c : (Lcom/chartboost/sdk/impl/i;)Landroid/util/SparseArray;
      //   702: aload_0
      //   703: getfield b : Lcom/chartboost/sdk/impl/i$a;
      //   706: invokestatic b : (Lcom/chartboost/sdk/impl/i$a;)Ljava/lang/Integer;
      //   709: invokevirtual intValue : ()I
      //   712: invokevirtual remove : (I)V
      //   715: aload_3
      //   716: athrow
      //   717: aload #6
      //   719: invokestatic a : (Lorg/apache/http/HttpEntity;)V
      //   722: new com/chartboost/sdk/Model/CBError
      //   725: dup
      //   726: getstatic com/chartboost/sdk/Model/CBError$a.e : Lcom/chartboost/sdk/Model/CBError$a;
      //   729: new java/lang/StringBuilder
      //   732: dup
      //   733: invokespecial <init> : ()V
      //   736: ldc_w 'Request failed. Response code: '
      //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   742: iload_1
      //   743: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   746: ldc_w ' is not valid (>=200 and <300)'
      //   749: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   752: invokevirtual toString : ()Ljava/lang/String;
      //   755: invokespecial <init> : (Lcom/chartboost/sdk/Model/CBError$a;Ljava/lang/String;)V
      //   758: astore_3
      //   759: goto -> 520
      //   762: iconst_0
      //   763: istore_2
      //   764: goto -> 552
      //   767: astore_3
      //   768: aload #6
      //   770: astore #4
      //   772: goto -> 599
      //   775: goto -> 515
      // Exception table:
      //   from	to	target	type
      //   243	249	559	finally
      //   249	294	767	java/lang/Exception
      //   249	294	694	finally
      //   294	306	767	java/lang/Exception
      //   294	306	694	finally
      //   306	328	594	java/lang/Exception
      //   306	328	694	finally
      //   328	373	400	java/lang/Exception
      //   328	373	694	finally
      //   373	379	400	java/lang/Exception
      //   373	379	694	finally
      //   384	397	400	java/lang/Exception
      //   384	397	694	finally
      //   401	407	594	java/lang/Exception
      //   401	407	694	finally
      //   425	462	594	java/lang/Exception
      //   425	462	694	finally
      //   467	512	594	java/lang/Exception
      //   467	512	694	finally
      //   515	520	594	java/lang/Exception
      //   515	520	694	finally
      //   561	563	559	finally
      //   566	576	400	java/lang/Exception
      //   566	576	694	finally
      //   579	588	594	java/lang/Exception
      //   579	588	694	finally
      //   599	651	694	finally
      //   677	691	594	java/lang/Exception
      //   677	691	694	finally
      //   717	759	594	java/lang/Exception
      //   717	759	694	finally
    }
  }
  
  class null implements Runnable {
    null(i this$0, boolean param1Boolean, CBError param1CBError) {}
    
    public void run() {
      i.a a = i.d.a(this.c);
      if (this.a && i.a.c(a) != null) {
        if (i.a.d(a) != null)
          i.a.d(a).a(i.a.c(a), i.a.a(a)); 
        return;
      } 
      a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */