package com.chartboost.sdk.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

abstract class bf<K, V, M extends Map<K, V>> implements Serializable, ConcurrentMap<K, V> {
  private volatile M a;
  
  private final transient Lock b = new ReentrantLock();
  
  private final h<K, V> c;
  
  protected <N extends Map<? extends K, ? extends V>> bf(N paramN, h.a parama) {
    this.a = (M)bg.<Map>a("delegate", a(bg.<Map>a("map", (Map)paramN)));
    this.c = ((h.a)bg.<h.a>a("viewType", parama)).a(this);
  }
  
  private boolean a(Object paramObject1, Object paramObject2) {
    return (paramObject1 == null) ? ((paramObject2 == null)) : paramObject1.equals(paramObject2);
  }
  
  protected M a() {
    this.b.lock();
    try {
      return (M)a((Map<?, ?>)this.a);
    } finally {
      this.b.unlock();
    } 
  }
  
  abstract <N extends Map<? extends K, ? extends V>> M a(N paramN);
  
  protected void b(M paramM) {
    this.a = paramM;
  }
  
  public final void clear() {
    this.b.lock();
    try {
      b(a(Collections.emptyMap()));
      return;
    } finally {
      this.b.unlock();
    } 
  }
  
  public final boolean containsKey(Object paramObject) {
    return this.a.containsKey(paramObject);
  }
  
  public final boolean containsValue(Object paramObject) {
    return this.a.containsValue(paramObject);
  }
  
  public final Set<Map.Entry<K, V>> entrySet() {
    return this.c.b();
  }
  
  public final boolean equals(Object paramObject) {
    return this.a.equals(paramObject);
  }
  
  public final V get(Object paramObject) {
    return (V)this.a.get(paramObject);
  }
  
  public final int hashCode() {
    return this.a.hashCode();
  }
  
  public final boolean isEmpty() {
    return this.a.isEmpty();
  }
  
  public final Set<K> keySet() {
    return this.c.a();
  }
  
  public final V put(K paramK, V paramV) {
    this.b.lock();
    try {
      M m = a();
    } finally {
      this.b.unlock();
    } 
  }
  
  public final void putAll(Map<? extends K, ? extends V> paramMap) {
    this.b.lock();
    try {
      M m = a();
      m.putAll(paramMap);
      b(m);
      return;
    } finally {
      this.b.unlock();
    } 
  }
  
  public V putIfAbsent(K paramK, V paramV) {
    this.b.lock();
    try {
      if (!this.a.containsKey(paramK)) {
        M m = a();
        try {
          paramK = m.put(paramK, (K)paramV);
          return (V)paramK;
        } finally {
          b(m);
        } 
      } 
    } finally {
      this.b.unlock();
    } 
    this.b.unlock();
    return (V)paramK;
  }
  
  public final V remove(Object paramObject) {
    this.b.lock();
    try {
      boolean bool = this.a.containsKey(paramObject);
      if (!bool)
        return null; 
      M m = a();
    } finally {
      this.b.unlock();
    } 
  }
  
  public boolean remove(Object paramObject1, Object paramObject2) {
    this.b.lock();
    try {
      if (this.a.containsKey(paramObject1) && a(paramObject2, this.a.get(paramObject1))) {
        paramObject2 = a();
        paramObject2.remove(paramObject1);
        b((M)paramObject2);
        return true;
      } 
      return false;
    } finally {
      this.b.unlock();
    } 
  }
  
  public V replace(K paramK, V paramV) {
    this.b.lock();
    try {
      boolean bool = this.a.containsKey(paramK);
      if (!bool)
        return null; 
      M m = a();
    } finally {
      this.b.unlock();
    } 
  }
  
  public boolean replace(K paramK, V paramV1, V paramV2) {
    this.b.lock();
    try {
      if (this.a.containsKey(paramK)) {
        boolean bool = a(paramV1, this.a.get(paramK));
        if (bool) {
          paramV1 = (V)a();
          paramV1.put(paramK, paramV2);
          b((M)paramV1);
          return true;
        } 
      } 
      return false;
    } finally {
      this.b.unlock();
    } 
  }
  
  public final int size() {
    return this.a.size();
  }
  
  public String toString() {
    return this.a.toString();
  }
  
  public final Collection<V> values() {
    return this.c.c();
  }
  
  protected static abstract class a<E> implements Collection<E> {
    abstract Collection<E> a();
    
    public final boolean add(E param1E) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean addAll(Collection<? extends E> param1Collection) {
      throw new UnsupportedOperationException();
    }
    
    public final boolean contains(Object param1Object) {
      return a().contains(param1Object);
    }
    
    public final boolean containsAll(Collection<?> param1Collection) {
      return a().containsAll(param1Collection);
    }
    
    public boolean equals(Object param1Object) {
      return a().equals(param1Object);
    }
    
    public int hashCode() {
      return a().hashCode();
    }
    
    public final boolean isEmpty() {
      return a().isEmpty();
    }
    
    public final Iterator<E> iterator() {
      return new bf.f<E>(a().iterator());
    }
    
    public final int size() {
      return a().size();
    }
    
    public final Object[] toArray() {
      return a().toArray();
    }
    
    public final <T> T[] toArray(T[] param1ArrayOfT) {
      return a().toArray(param1ArrayOfT);
    }
    
    public String toString() {
      return a().toString();
    }
  }
  
  private class b extends a<Map.Entry<K, V>> implements Set<Map.Entry<K, V>> {
    private b(bf this$0) {}
    
    Collection<Map.Entry<K, V>> a() {
      return bf.a(this.a).entrySet();
    }
    
    public void clear() {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
        object.entrySet().clear();
        this.a.b(object);
        return;
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean remove(Object param1Object) {
      bf.b(this.a).lock();
      try {
        boolean bool = contains(param1Object);
        if (!bool)
          return false; 
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
  }
  
  final class c extends h<K, V> implements Serializable {
    c(bf this$0) {}
    
    public Set<K> a() {
      return Collections.unmodifiableSet(bf.a(this.a).keySet());
    }
    
    public Set<Map.Entry<K, V>> b() {
      return Collections.unmodifiableSet(bf.a(this.a).entrySet());
    }
    
    public Collection<V> c() {
      return Collections.unmodifiableCollection(bf.a(this.a).values());
    }
  }
  
  private class d extends a<K> implements Set<K> {
    private d(bf this$0) {}
    
    Collection<K> a() {
      return bf.a(this.a).keySet();
    }
    
    public void clear() {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
        object.keySet().clear();
        this.a.b(object);
        return;
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean remove(Object param1Object) {
      return (this.a.remove(param1Object) != null);
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
  }
  
  final class e extends h<K, V> implements Serializable {
    private final transient bf<K, V, M>.d b = new bf.d();
    
    private final transient bf<K, V, M>.b c = new bf.b();
    
    private final transient bf<K, V, M>.g d = new bf.g();
    
    e(bf this$0) {}
    
    public Set<K> a() {
      return this.b;
    }
    
    public Set<Map.Entry<K, V>> b() {
      return this.c;
    }
    
    public Collection<V> c() {
      return this.d;
    }
  }
  
  private static class f<T> implements Iterator<T> {
    private final Iterator<T> a;
    
    public f(Iterator<T> param1Iterator) {
      this.a = param1Iterator;
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public T next() {
      return this.a.next();
    }
    
    public void remove() {
      throw new UnsupportedOperationException();
    }
  }
  
  private final class g extends a<V> {
    private g(bf this$0) {}
    
    Collection<V> a() {
      return bf.a(this.a).values();
    }
    
    public void clear() {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
        object.values().clear();
        this.a.b(object);
        return;
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean remove(Object param1Object) {
      bf.b(this.a).lock();
      try {
        boolean bool = contains(param1Object);
        if (!bool)
          return false; 
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      bf.b(this.a).lock();
      try {
        Object object = this.a.a();
      } finally {
        bf.b(this.a).unlock();
      } 
    }
  }
  
  public static abstract class h<K, V> {
    abstract Set<K> a();
    
    abstract Set<Map.Entry<K, V>> b();
    
    abstract Collection<V> c();
    
    public enum a {
      a {
        <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param3bf) {
          param3bf.getClass();
          return new bf.c(param3bf);
        }
      },
      b {
        <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param3bf) {
          param3bf.getClass();
          return new bf.e(param3bf);
        }
      };
      
      abstract <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param2bf);
    }
    
    enum null {
      <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param2bf) {
        param2bf.getClass();
        return new bf.c(param2bf);
      }
    }
    
    enum null {
      <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param2bf) {
        param2bf.getClass();
        return new bf.e(param2bf);
      }
    }
  }
  
  public enum a {
    a {
      <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param3bf) {
        param3bf.getClass();
        return new bf.c(param3bf);
      }
    },
    b {
      <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param3bf) {
        param3bf.getClass();
        return new bf.e(param3bf);
      }
    };
    
    abstract <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param1bf);
  }
  
  enum null {
    <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param1bf) {
      param1bf.getClass();
      return new bf.c(param1bf);
    }
  }
  
  enum null {
    <K, V, M extends Map<K, V>> bf.h<K, V> a(bf<K, V, M> param1bf) {
      param1bf.getClass();
      return new bf.e(param1bf);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */