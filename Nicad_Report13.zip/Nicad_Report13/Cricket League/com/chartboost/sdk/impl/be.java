package com.chartboost.sdk.impl;

import java.io.Serializable;

public class be implements Serializable {
  private final String a;
  
  public String a() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (paramObject instanceof be) {
        paramObject = ((be)paramObject).a;
      } else if (paramObject instanceof String) {
        paramObject = paramObject;
      } else {
        return false;
      } 
      if ((this.a != null) ? !this.a.equals(paramObject) : (paramObject != null))
        return false; 
    } 
    return true;
  }
  
  public int hashCode() {
    return (this.a != null) ? this.a.hashCode() : 0;
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\be.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */