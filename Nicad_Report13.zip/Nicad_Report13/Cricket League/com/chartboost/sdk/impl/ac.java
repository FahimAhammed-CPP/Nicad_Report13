package com.chartboost.sdk.impl;

class ac extends ab {
  private bi<ag> a = new bi<ag>();
  
  void a(Class<?> paramClass, ag paramag) {
    this.a.a(paramClass, paramag);
  }
  
  public void a(Class<?> paramObject, StringBuilder paramStringBuilder) {
    ag ag;
    Object object = y.a(paramObject);
    if (object == null) {
      paramStringBuilder.append(" null ");
      return;
    } 
    paramObject = null;
    for (Class<?> paramObject : bi.a(object.getClass())) {
      ag = this.a.a(paramObject);
      paramObject = (Class<?>)ag;
      if (ag != null) {
        paramObject = (Class<?>)ag;
        break;
      } 
    } 
    Class<?> clazz = paramObject;
    if (paramObject == null) {
      clazz = paramObject;
      if (object.getClass().isArray())
        ag = this.a.a(Object[].class); 
    } 
    if (ag == null)
      throw new RuntimeException("json can't serialize type : " + object.getClass()); 
    ag.a(object, paramStringBuilder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */