package com.chartboost.sdk.impl;

public class bg {
  public static <T> T a(String paramString, T paramT) throws IllegalArgumentException {
    if (paramT == null)
      throw new a(paramString); 
    return paramT;
  }
  
  static class a extends IllegalArgumentException {
    a(String param1String) {
      super(param1String + " should not be null!");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */