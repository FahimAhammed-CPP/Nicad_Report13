package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBOrientation;

public final class t extends RelativeLayout {
  private a a;
  
  private p b;
  
  private p c;
  
  private s d;
  
  private OrientationEventListener e;
  
  private CBOrientation.Difference f = null;
  
  private com.chartboost.sdk.Model.a g = null;
  
  public t(Context paramContext, com.chartboost.sdk.Model.a parama) {
    super(paramContext);
    this.g = parama;
    this.b = new p(paramContext);
    addView(this.b, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.c = new p(paramContext);
    addView(this.c, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    this.c.setVisibility(8);
    CBPreferences cBPreferences = CBPreferences.getInstance();
    if (cBPreferences.getOrientation() != null && cBPreferences.getOrientation() != CBOrientation.UNSPECIFIED) {
      this.f = cBPreferences.getForcedOrientationDifference();
      this.e = new OrientationEventListener(this, paramContext, 1, cBPreferences) {
          public void onOrientationChanged(int param1Int) {
            CBOrientation.Difference difference = this.a.getForcedOrientationDifference();
            if (t.a(this.b) == difference)
              return; 
            t.a(this.b, difference);
            if (t.b(this.b) != null)
              t.b(this.b).a(); 
            if (t.c(this.b) != null && t.c(this.b).getVisibility() == 0)
              t.c(this.b).a(); 
            this.b.invalidate();
          }
        };
      this.e.enable();
    } 
    setOnTouchListener(new View.OnTouchListener(this) {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            return true;
          }
        });
  }
  
  public void a() {
    if (this.a == null) {
      this.a = this.g.e();
      addView(this.a.b(), (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    } 
    c();
  }
  
  public void b() {
    boolean bool;
    if (!this.g.j) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g.j = true;
    if (this.d == null) {
      this.d = new s(getContext());
      this.d.setVisibility(8);
      addView((View)this.d, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
    } else {
      this.c.bringToFront();
      this.c.setVisibility(0);
      this.c.a();
      o.b(this.b);
      this.d.bringToFront();
      this.d.a();
    } 
    if (!g()) {
      this.d.setVisibility(0);
      if (bool) {
        e().a();
        o.a((View)this.d);
      } 
    } 
  }
  
  public void c() {
    if (this.d != null) {
      this.d.clearAnimation();
      this.d.setVisibility(8);
    } 
  }
  
  public void d() {
    if (this.e != null) {
      this.e.disable();
      this.e = null;
    } 
  }
  
  public p e() {
    return this.b;
  }
  
  public View f() {
    return (this.a == null) ? null : this.a.b();
  }
  
  public boolean g() {
    return (this.d != null && this.d.getVisibility() == 0);
  }
  
  public com.chartboost.sdk.Model.a h() {
    return this.g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return true;
  }
  
  public static interface a {
    void a();
    
    View b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */