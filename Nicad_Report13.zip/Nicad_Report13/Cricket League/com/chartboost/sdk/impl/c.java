package com.chartboost.sdk.impl;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.chartboost.sdk.CBPreferences;
import com.chartboost.sdk.Libraries.CBUtility;
import org.json.JSONObject;

public class c extends b implements g.b {
  private static int b = 100;
  
  private static int c = 5;
  
  private f d;
  
  public c(Context paramContext) {
    super(paramContext);
    this.d = new f(paramContext);
    addView((View)this.d, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
  }
  
  public int a() {
    return CBUtility.a(b + c * 2, getContext());
  }
  
  public void a(JSONObject paramJSONObject, int paramInt) {
    boolean bool = CBPreferences.getInstance().getOrientation().isPortrait();
    JSONObject jSONObject = paramJSONObject.optJSONObject("assets");
    if (jSONObject != null) {
      String str;
      if (bool) {
        str = "portrait";
      } else {
        str = "landscape";
      } 
      JSONObject jSONObject1 = jSONObject.optJSONObject(str);
      if (jSONObject1 != null) {
        Bundle bundle = new Bundle();
        bundle.putInt("index", paramInt);
        n.a().a(jSONObject1.optString("url"), jSONObject1.optString("checksum"), null, this.d, bundle);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */