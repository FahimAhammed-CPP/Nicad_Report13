package com.chartboost.sdk.impl;

abstract class ab implements ag {}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */