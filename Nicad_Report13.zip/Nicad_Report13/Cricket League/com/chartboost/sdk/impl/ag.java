package com.chartboost.sdk.impl;

public interface ag {
  void a(Object paramObject, StringBuilder paramStringBuilder);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */