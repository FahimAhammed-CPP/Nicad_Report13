package com.chartboost.sdk.impl;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.c;
import java.net.URI;
import java.net.URLDecoder;
import org.json.JSONObject;
import org.json.JSONTokener;

public final class w extends c {
  private String h = null;
  
  public w(com.chartboost.sdk.Model.a parama) {
    super(parama);
  }
  
  protected c.b a(Context paramContext) {
    return new a(this, paramContext, this.h);
  }
  
  public void a(JSONObject paramJSONObject) {
    String str = paramJSONObject.optString("html");
    if (str == null) {
      this.g.a(CBError.CBImpressionError.INTERNAL);
      return;
    } 
    this.h = str;
    b();
  }
  
  public class a extends c.b {
    public WebView c;
    
    public a(w this$0, Context param1Context, String param1String) {
      super(this$0, param1Context);
      setFocusable(false);
      this.c = new w.b(this$0, param1Context);
      this.c.setWebViewClient(new w.c(this$0, this$0));
      addView((View)this.c);
      this.c.loadDataWithBaseURL("file:///android_asset/", param1String, "text/html", "utf-8", null);
    }
    
    protected void a(int param1Int1, int param1Int2) {}
  }
  
  private class b extends WebView {
    public b(w this$0, Context param1Context) {
      super(param1Context);
      setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
      setBackgroundColor(0);
      getSettings().setJavaScriptEnabled(true);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      if ((param1Int == 4 || param1Int == 3) && this.a.a != null)
        this.a.a.a(); 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
  }
  
  private class c extends WebViewClient {
    private w b;
    
    public c(w this$0, w param1w1) {
      this.b = param1w1;
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      if (this.b != null && this.b.c != null)
        this.b.c.a(); 
    }
    
    public void onReceivedError(WebView param1WebView, int param1Int, String param1String1, String param1String2) {
      w.a(this.a).a(CBError.CBImpressionError.INTERNAL);
    }
    
    public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
      Integer integer;
      Exception exception2 = null;
      CBLogging.d("CBWebViewProtocol", "loading url: " + param1String);
      try {
        String str = (new URI(param1String)).getScheme();
        if (str.equals("chartboost")) {
          String[] arrayOfString = param1String.split("/");
          integer = Integer.valueOf(arrayOfString.length);
          if (integer.intValue() < 3) {
            if (this.b.a != null)
              this.b.a.a(); 
            return false;
          } 
          param1String = arrayOfString[2];
          if (param1String.equals("close")) {
            if (this.b.a != null)
              this.b.a.a(); 
            return true;
          } 
        } else {
          return true;
        } 
      } catch (Exception exception1) {
        if (this.b.a != null) {
          this.b.a.a();
          return false;
        } 
        return false;
      } 
      if (param1String.equals("link")) {
        if (integer.intValue() < 4) {
          if (this.b.a != null) {
            this.b.a.a();
            return false;
          } 
          return false;
        } 
        try {
          param1String = URLDecoder.decode((String)exception1[3], "UTF-8");
          try {
            if (integer.intValue() > 4) {
              JSONObject jSONObject = new JSONObject(new JSONTokener(URLDecoder.decode((String)exception1[4], "UTF-8")));
            } else {
              exception1 = null;
            } 
            exception2 = exception1;
            String str = param1String;
            if (this.b.b != null)
              this.b.b.a(w.b(this.a), str, (JSONObject)exception2); 
          } catch (Exception exception4) {
            String str = param1String;
            Exception exception3 = exception4;
          } 
        } catch (Exception exception) {
          exception1 = null;
        } 
      } else {
        return true;
      } 
      if (this.b.b != null)
        this.b.b.a(w.b(this.a), (String)exception1, (JSONObject)exception2); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */