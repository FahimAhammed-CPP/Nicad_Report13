package com.chartboost.sdk.impl;

import java.io.Serializable;
import java.util.Date;

public class ax implements Serializable, Comparable<ax> {
  static final boolean a = Boolean.getBoolean("DEBUG.DBTIMESTAMP");
  
  final int b = 0;
  
  final Date c = null;
  
  public int a() {
    return (this.c == null) ? 0 : (int)(this.c.getTime() / 1000L);
  }
  
  public int a(ax paramax) {
    return (a() != paramax.a()) ? (a() - paramax.a()) : (b() - paramax.b());
  }
  
  public int b() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (paramObject instanceof ax) {
        paramObject = paramObject;
        return !(a() != paramObject.a() || b() != paramObject.b());
      } 
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    return (this.b + 31) * 31 + a();
  }
  
  public String toString() {
    return "TS time:" + this.c + " inc:" + this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\ax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */