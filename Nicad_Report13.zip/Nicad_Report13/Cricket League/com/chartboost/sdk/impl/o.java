package com.chartboost.sdk.impl;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Libraries.CBOrientation;

public final class o {
  public static void a(View paramView) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(0.0F, 1.0F);
    alphaAnimation.setDuration(510L);
    alphaAnimation.setFillAfter(true);
    paramView.startAnimation((Animation)alphaAnimation);
  }
  
  public static void a(b paramb, com.chartboost.sdk.Model.a parama, a parama1) {
    b(paramb, parama, parama1, true);
  }
  
  public static void b(View paramView) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(1.0F, 0.0F);
    alphaAnimation.setDuration(510L);
    alphaAnimation.setFillAfter(true);
    paramView.startAnimation((Animation)alphaAnimation);
  }
  
  public static void b(b paramb, com.chartboost.sdk.Model.a parama, a parama1) {
    c(paramb, parama, parama1, false);
  }
  
  private static void b(b paramb, com.chartboost.sdk.Model.a parama, a parama1, boolean paramBoolean) {
    if (paramb == b.f) {
      if (parama1 != null)
        parama1.a(parama); 
      return;
    } 
    if (parama == null || parama.h == null) {
      CBLogging.a("CBAnimationManager", "Transition of impression canceled due to lack of container");
      return;
    } 
    View view = parama.h.f();
    if (view == null) {
      CBLogging.a("CBAnimationManager", "Transition of impression canceled due to lack of view");
      return;
    } 
    ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
    if (viewTreeObserver.isAlive()) {
      viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(view, paramb, parama, parama1, paramBoolean) {
            public void onGlobalLayout() {
              this.a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
              o.a(this.b, this.c, this.d, this.e);
            }
          });
      return;
    } 
  }
  
  private static void c(b paramb, com.chartboost.sdk.Model.a parama, a parama1, boolean paramBoolean) {
    // Byte code:
    //   0: invokestatic getInstance : ()Lcom/chartboost/sdk/CBPreferences;
    //   3: astore #9
    //   5: new android/view/animation/AnimationSet
    //   8: dup
    //   9: iconst_1
    //   10: invokespecial <init> : (Z)V
    //   13: astore #10
    //   15: aload #10
    //   17: new android/view/animation/AlphaAnimation
    //   20: dup
    //   21: fconst_1
    //   22: fconst_1
    //   23: invokespecial <init> : (FF)V
    //   26: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   29: aload_1
    //   30: ifnull -> 40
    //   33: aload_1
    //   34: getfield h : Lcom/chartboost/sdk/impl/t;
    //   37: ifnonnull -> 48
    //   40: ldc 'CBAnimationManager'
    //   42: ldc 'Transition of impression canceled due to lack of container'
    //   44: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   47: return
    //   48: aload_1
    //   49: getfield h : Lcom/chartboost/sdk/impl/t;
    //   52: invokevirtual f : ()Landroid/view/View;
    //   55: astore #11
    //   57: aload #11
    //   59: ifnonnull -> 70
    //   62: ldc 'CBAnimationManager'
    //   64: ldc 'Transition of impression canceled due to lack of view'
    //   66: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   69: return
    //   70: aload #11
    //   72: invokevirtual getWidth : ()I
    //   75: i2f
    //   76: fstore #4
    //   78: aload #11
    //   80: invokevirtual getHeight : ()I
    //   83: i2f
    //   84: fstore #5
    //   86: fconst_1
    //   87: ldc 0.4
    //   89: fsub
    //   90: fconst_2
    //   91: fdiv
    //   92: fstore #6
    //   94: aload #9
    //   96: invokevirtual getForcedOrientationDifference : ()Lcom/chartboost/sdk/Libraries/CBOrientation$Difference;
    //   99: astore #12
    //   101: getstatic com/chartboost/sdk/impl/o$3.b : [I
    //   104: aload_0
    //   105: invokevirtual ordinal : ()I
    //   108: iaload
    //   109: tableswitch default -> 144, 1 -> 163, 2 -> 746, 3 -> 1326, 4 -> 1589, 5 -> 1867
    //   144: aload_0
    //   145: getstatic com/chartboost/sdk/impl/o$b.f : Lcom/chartboost/sdk/impl/o$b;
    //   148: if_acmpne -> 2113
    //   151: aload_2
    //   152: ifnull -> 47
    //   155: aload_2
    //   156: aload_1
    //   157: invokeinterface a : (Lcom/chartboost/sdk/Model/a;)V
    //   162: return
    //   163: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   166: aload #12
    //   168: invokevirtual ordinal : ()I
    //   171: iaload
    //   172: tableswitch default -> 200, 1 -> 374, 2 -> 427, 3 -> 480
    //   200: iload_3
    //   201: ifeq -> 533
    //   204: new com/chartboost/sdk/impl/q
    //   207: dup
    //   208: ldc 60.0
    //   210: fneg
    //   211: fconst_0
    //   212: fload #4
    //   214: fconst_2
    //   215: fdiv
    //   216: fload #5
    //   218: fconst_2
    //   219: fdiv
    //   220: iconst_0
    //   221: invokespecial <init> : (FFFFZ)V
    //   224: astore #9
    //   226: aload #9
    //   228: ldc2_w 600
    //   231: invokevirtual setDuration : (J)V
    //   234: aload #9
    //   236: iconst_1
    //   237: invokevirtual setFillAfter : (Z)V
    //   240: aload #10
    //   242: aload #9
    //   244: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   247: iload_3
    //   248: ifeq -> 557
    //   251: new android/view/animation/ScaleAnimation
    //   254: dup
    //   255: ldc 0.4
    //   257: fconst_1
    //   258: ldc 0.4
    //   260: fconst_1
    //   261: invokespecial <init> : (FFFF)V
    //   264: astore #9
    //   266: aload #9
    //   268: ldc2_w 600
    //   271: invokevirtual setDuration : (J)V
    //   274: aload #9
    //   276: iconst_1
    //   277: invokevirtual setFillAfter : (Z)V
    //   280: aload #10
    //   282: aload #9
    //   284: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   287: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   290: aload #12
    //   292: invokevirtual ordinal : ()I
    //   295: iaload
    //   296: tableswitch default -> 324, 1 -> 575, 2 -> 625, 3 -> 675
    //   324: iload_3
    //   325: ifeq -> 725
    //   328: new android/view/animation/TranslateAnimation
    //   331: dup
    //   332: fload #4
    //   334: fload #6
    //   336: fmul
    //   337: fconst_0
    //   338: fload #5
    //   340: fneg
    //   341: ldc 0.4
    //   343: fmul
    //   344: fconst_0
    //   345: invokespecial <init> : (FFFF)V
    //   348: astore #9
    //   350: aload #9
    //   352: ldc2_w 600
    //   355: invokevirtual setDuration : (J)V
    //   358: aload #9
    //   360: iconst_1
    //   361: invokevirtual setFillAfter : (Z)V
    //   364: aload #10
    //   366: aload #9
    //   368: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   371: goto -> 144
    //   374: iload_3
    //   375: ifeq -> 403
    //   378: new com/chartboost/sdk/impl/q
    //   381: dup
    //   382: ldc 60.0
    //   384: fneg
    //   385: fconst_0
    //   386: fload #4
    //   388: fconst_2
    //   389: fdiv
    //   390: fload #5
    //   392: fconst_2
    //   393: fdiv
    //   394: iconst_1
    //   395: invokespecial <init> : (FFFFZ)V
    //   398: astore #9
    //   400: goto -> 226
    //   403: new com/chartboost/sdk/impl/q
    //   406: dup
    //   407: fconst_0
    //   408: ldc 60.0
    //   410: fload #4
    //   412: fconst_2
    //   413: fdiv
    //   414: fload #5
    //   416: fconst_2
    //   417: fdiv
    //   418: iconst_1
    //   419: invokespecial <init> : (FFFFZ)V
    //   422: astore #9
    //   424: goto -> 226
    //   427: iload_3
    //   428: ifeq -> 455
    //   431: new com/chartboost/sdk/impl/q
    //   434: dup
    //   435: ldc 60.0
    //   437: fconst_0
    //   438: fload #4
    //   440: fconst_2
    //   441: fdiv
    //   442: fload #5
    //   444: fconst_2
    //   445: fdiv
    //   446: iconst_0
    //   447: invokespecial <init> : (FFFFZ)V
    //   450: astore #9
    //   452: goto -> 226
    //   455: new com/chartboost/sdk/impl/q
    //   458: dup
    //   459: fconst_0
    //   460: ldc 60.0
    //   462: fneg
    //   463: fload #4
    //   465: fconst_2
    //   466: fdiv
    //   467: fload #5
    //   469: fconst_2
    //   470: fdiv
    //   471: iconst_0
    //   472: invokespecial <init> : (FFFFZ)V
    //   475: astore #9
    //   477: goto -> 226
    //   480: iload_3
    //   481: ifeq -> 508
    //   484: new com/chartboost/sdk/impl/q
    //   487: dup
    //   488: ldc 60.0
    //   490: fconst_0
    //   491: fload #4
    //   493: fconst_2
    //   494: fdiv
    //   495: fload #5
    //   497: fconst_2
    //   498: fdiv
    //   499: iconst_1
    //   500: invokespecial <init> : (FFFFZ)V
    //   503: astore #9
    //   505: goto -> 226
    //   508: new com/chartboost/sdk/impl/q
    //   511: dup
    //   512: fconst_0
    //   513: ldc 60.0
    //   515: fneg
    //   516: fload #4
    //   518: fconst_2
    //   519: fdiv
    //   520: fload #5
    //   522: fconst_2
    //   523: fdiv
    //   524: iconst_1
    //   525: invokespecial <init> : (FFFFZ)V
    //   528: astore #9
    //   530: goto -> 226
    //   533: new com/chartboost/sdk/impl/q
    //   536: dup
    //   537: fconst_0
    //   538: ldc 60.0
    //   540: fload #4
    //   542: fconst_2
    //   543: fdiv
    //   544: fload #5
    //   546: fconst_2
    //   547: fdiv
    //   548: iconst_0
    //   549: invokespecial <init> : (FFFFZ)V
    //   552: astore #9
    //   554: goto -> 226
    //   557: new android/view/animation/ScaleAnimation
    //   560: dup
    //   561: fconst_1
    //   562: ldc 0.4
    //   564: fconst_1
    //   565: ldc 0.4
    //   567: invokespecial <init> : (FFFF)V
    //   570: astore #9
    //   572: goto -> 266
    //   575: iload_3
    //   576: ifeq -> 600
    //   579: new android/view/animation/TranslateAnimation
    //   582: dup
    //   583: fload #4
    //   585: fconst_0
    //   586: fload #5
    //   588: fload #6
    //   590: fmul
    //   591: fconst_0
    //   592: invokespecial <init> : (FFFF)V
    //   595: astore #9
    //   597: goto -> 350
    //   600: new android/view/animation/TranslateAnimation
    //   603: dup
    //   604: fconst_0
    //   605: fload #4
    //   607: fneg
    //   608: ldc 0.4
    //   610: fmul
    //   611: fconst_0
    //   612: fload #5
    //   614: fload #6
    //   616: fmul
    //   617: invokespecial <init> : (FFFF)V
    //   620: astore #9
    //   622: goto -> 350
    //   625: iload_3
    //   626: ifeq -> 650
    //   629: new android/view/animation/TranslateAnimation
    //   632: dup
    //   633: fload #4
    //   635: fload #6
    //   637: fmul
    //   638: fconst_0
    //   639: fload #5
    //   641: fconst_0
    //   642: invokespecial <init> : (FFFF)V
    //   645: astore #9
    //   647: goto -> 350
    //   650: new android/view/animation/TranslateAnimation
    //   653: dup
    //   654: fconst_0
    //   655: fload #4
    //   657: fload #6
    //   659: fmul
    //   660: fconst_0
    //   661: fload #5
    //   663: fneg
    //   664: ldc 0.4
    //   666: fmul
    //   667: invokespecial <init> : (FFFF)V
    //   670: astore #9
    //   672: goto -> 350
    //   675: iload_3
    //   676: ifeq -> 704
    //   679: new android/view/animation/TranslateAnimation
    //   682: dup
    //   683: fload #4
    //   685: fneg
    //   686: ldc 0.4
    //   688: fmul
    //   689: fconst_0
    //   690: fload #5
    //   692: fload #6
    //   694: fmul
    //   695: fconst_0
    //   696: invokespecial <init> : (FFFF)V
    //   699: astore #9
    //   701: goto -> 350
    //   704: new android/view/animation/TranslateAnimation
    //   707: dup
    //   708: fconst_0
    //   709: fload #4
    //   711: fconst_0
    //   712: fload #5
    //   714: fload #6
    //   716: fmul
    //   717: invokespecial <init> : (FFFF)V
    //   720: astore #9
    //   722: goto -> 350
    //   725: new android/view/animation/TranslateAnimation
    //   728: dup
    //   729: fconst_0
    //   730: fload #4
    //   732: fload #6
    //   734: fmul
    //   735: fconst_0
    //   736: fload #5
    //   738: invokespecial <init> : (FFFF)V
    //   741: astore #9
    //   743: goto -> 350
    //   746: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   749: aload #12
    //   751: invokevirtual ordinal : ()I
    //   754: iaload
    //   755: tableswitch default -> 780, 1 -> 954, 2 -> 1007, 3 -> 1060
    //   780: iload_3
    //   781: ifeq -> 1113
    //   784: new com/chartboost/sdk/impl/q
    //   787: dup
    //   788: ldc 60.0
    //   790: fneg
    //   791: fconst_0
    //   792: fload #4
    //   794: fconst_2
    //   795: fdiv
    //   796: fload #5
    //   798: fconst_2
    //   799: fdiv
    //   800: iconst_1
    //   801: invokespecial <init> : (FFFFZ)V
    //   804: astore #9
    //   806: aload #9
    //   808: ldc2_w 600
    //   811: invokevirtual setDuration : (J)V
    //   814: aload #9
    //   816: iconst_1
    //   817: invokevirtual setFillAfter : (Z)V
    //   820: aload #10
    //   822: aload #9
    //   824: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   827: iload_3
    //   828: ifeq -> 1137
    //   831: new android/view/animation/ScaleAnimation
    //   834: dup
    //   835: ldc 0.4
    //   837: fconst_1
    //   838: ldc 0.4
    //   840: fconst_1
    //   841: invokespecial <init> : (FFFF)V
    //   844: astore #9
    //   846: aload #9
    //   848: ldc2_w 600
    //   851: invokevirtual setDuration : (J)V
    //   854: aload #9
    //   856: iconst_1
    //   857: invokevirtual setFillAfter : (Z)V
    //   860: aload #10
    //   862: aload #9
    //   864: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   867: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   870: aload #12
    //   872: invokevirtual ordinal : ()I
    //   875: iaload
    //   876: tableswitch default -> 904, 1 -> 1155, 2 -> 1205, 3 -> 1255
    //   904: iload_3
    //   905: ifeq -> 1305
    //   908: new android/view/animation/TranslateAnimation
    //   911: dup
    //   912: fload #4
    //   914: fneg
    //   915: ldc 0.4
    //   917: fmul
    //   918: fconst_0
    //   919: fload #5
    //   921: fload #6
    //   923: fmul
    //   924: fconst_0
    //   925: invokespecial <init> : (FFFF)V
    //   928: astore #9
    //   930: aload #9
    //   932: ldc2_w 600
    //   935: invokevirtual setDuration : (J)V
    //   938: aload #9
    //   940: iconst_1
    //   941: invokevirtual setFillAfter : (Z)V
    //   944: aload #10
    //   946: aload #9
    //   948: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   951: goto -> 144
    //   954: iload_3
    //   955: ifeq -> 982
    //   958: new com/chartboost/sdk/impl/q
    //   961: dup
    //   962: ldc 60.0
    //   964: fconst_0
    //   965: fload #4
    //   967: fconst_2
    //   968: fdiv
    //   969: fload #5
    //   971: fconst_2
    //   972: fdiv
    //   973: iconst_0
    //   974: invokespecial <init> : (FFFFZ)V
    //   977: astore #9
    //   979: goto -> 806
    //   982: new com/chartboost/sdk/impl/q
    //   985: dup
    //   986: fconst_0
    //   987: ldc 60.0
    //   989: fneg
    //   990: fload #4
    //   992: fconst_2
    //   993: fdiv
    //   994: fload #5
    //   996: fconst_2
    //   997: fdiv
    //   998: iconst_0
    //   999: invokespecial <init> : (FFFFZ)V
    //   1002: astore #9
    //   1004: goto -> 806
    //   1007: iload_3
    //   1008: ifeq -> 1035
    //   1011: new com/chartboost/sdk/impl/q
    //   1014: dup
    //   1015: ldc 60.0
    //   1017: fconst_0
    //   1018: fload #4
    //   1020: fconst_2
    //   1021: fdiv
    //   1022: fload #5
    //   1024: fconst_2
    //   1025: fdiv
    //   1026: iconst_1
    //   1027: invokespecial <init> : (FFFFZ)V
    //   1030: astore #9
    //   1032: goto -> 806
    //   1035: new com/chartboost/sdk/impl/q
    //   1038: dup
    //   1039: fconst_0
    //   1040: ldc 60.0
    //   1042: fneg
    //   1043: fload #4
    //   1045: fconst_2
    //   1046: fdiv
    //   1047: fload #5
    //   1049: fconst_2
    //   1050: fdiv
    //   1051: iconst_1
    //   1052: invokespecial <init> : (FFFFZ)V
    //   1055: astore #9
    //   1057: goto -> 806
    //   1060: iload_3
    //   1061: ifeq -> 1089
    //   1064: new com/chartboost/sdk/impl/q
    //   1067: dup
    //   1068: ldc 60.0
    //   1070: fneg
    //   1071: fconst_0
    //   1072: fload #4
    //   1074: fconst_2
    //   1075: fdiv
    //   1076: fload #5
    //   1078: fconst_2
    //   1079: fdiv
    //   1080: iconst_0
    //   1081: invokespecial <init> : (FFFFZ)V
    //   1084: astore #9
    //   1086: goto -> 806
    //   1089: new com/chartboost/sdk/impl/q
    //   1092: dup
    //   1093: fconst_0
    //   1094: ldc 60.0
    //   1096: fload #4
    //   1098: fconst_2
    //   1099: fdiv
    //   1100: fload #5
    //   1102: fconst_2
    //   1103: fdiv
    //   1104: iconst_0
    //   1105: invokespecial <init> : (FFFFZ)V
    //   1108: astore #9
    //   1110: goto -> 806
    //   1113: new com/chartboost/sdk/impl/q
    //   1116: dup
    //   1117: fconst_0
    //   1118: ldc 60.0
    //   1120: fload #4
    //   1122: fconst_2
    //   1123: fdiv
    //   1124: fload #5
    //   1126: fconst_2
    //   1127: fdiv
    //   1128: iconst_1
    //   1129: invokespecial <init> : (FFFFZ)V
    //   1132: astore #9
    //   1134: goto -> 806
    //   1137: new android/view/animation/ScaleAnimation
    //   1140: dup
    //   1141: fconst_1
    //   1142: ldc 0.4
    //   1144: fconst_1
    //   1145: ldc 0.4
    //   1147: invokespecial <init> : (FFFF)V
    //   1150: astore #9
    //   1152: goto -> 846
    //   1155: iload_3
    //   1156: ifeq -> 1184
    //   1159: new android/view/animation/TranslateAnimation
    //   1162: dup
    //   1163: fload #4
    //   1165: fload #6
    //   1167: fmul
    //   1168: fconst_0
    //   1169: fload #5
    //   1171: fneg
    //   1172: ldc 0.4
    //   1174: fmul
    //   1175: fconst_0
    //   1176: invokespecial <init> : (FFFF)V
    //   1179: astore #9
    //   1181: goto -> 930
    //   1184: new android/view/animation/TranslateAnimation
    //   1187: dup
    //   1188: fconst_0
    //   1189: fload #4
    //   1191: fload #6
    //   1193: fmul
    //   1194: fconst_0
    //   1195: fload #5
    //   1197: invokespecial <init> : (FFFF)V
    //   1200: astore #9
    //   1202: goto -> 930
    //   1205: iload_3
    //   1206: ifeq -> 1230
    //   1209: new android/view/animation/TranslateAnimation
    //   1212: dup
    //   1213: fload #4
    //   1215: fconst_0
    //   1216: fload #5
    //   1218: fload #6
    //   1220: fmul
    //   1221: fconst_0
    //   1222: invokespecial <init> : (FFFF)V
    //   1225: astore #9
    //   1227: goto -> 930
    //   1230: new android/view/animation/TranslateAnimation
    //   1233: dup
    //   1234: fconst_0
    //   1235: fload #4
    //   1237: fneg
    //   1238: ldc 0.4
    //   1240: fmul
    //   1241: fconst_0
    //   1242: fload #5
    //   1244: fload #6
    //   1246: fmul
    //   1247: invokespecial <init> : (FFFF)V
    //   1250: astore #9
    //   1252: goto -> 930
    //   1255: iload_3
    //   1256: ifeq -> 1280
    //   1259: new android/view/animation/TranslateAnimation
    //   1262: dup
    //   1263: fload #4
    //   1265: fload #6
    //   1267: fmul
    //   1268: fconst_0
    //   1269: fload #5
    //   1271: fconst_0
    //   1272: invokespecial <init> : (FFFF)V
    //   1275: astore #9
    //   1277: goto -> 930
    //   1280: new android/view/animation/TranslateAnimation
    //   1283: dup
    //   1284: fconst_0
    //   1285: fload #4
    //   1287: fload #6
    //   1289: fmul
    //   1290: fconst_0
    //   1291: fload #5
    //   1293: fneg
    //   1294: ldc 0.4
    //   1296: fmul
    //   1297: invokespecial <init> : (FFFF)V
    //   1300: astore #9
    //   1302: goto -> 930
    //   1305: new android/view/animation/TranslateAnimation
    //   1308: dup
    //   1309: fconst_0
    //   1310: fload #4
    //   1312: fconst_0
    //   1313: fload #5
    //   1315: fload #6
    //   1317: fmul
    //   1318: invokespecial <init> : (FFFF)V
    //   1321: astore #9
    //   1323: goto -> 930
    //   1326: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   1329: aload #12
    //   1331: invokevirtual ordinal : ()I
    //   1334: iaload
    //   1335: tableswitch default -> 1364, 1 -> 1462, 2 -> 1505, 3 -> 1552, 4 -> 1417
    //   1364: fconst_0
    //   1365: fstore #4
    //   1367: fconst_0
    //   1368: fstore #5
    //   1370: fconst_0
    //   1371: fstore #6
    //   1373: fconst_0
    //   1374: fstore #7
    //   1376: new android/view/animation/TranslateAnimation
    //   1379: dup
    //   1380: fload #7
    //   1382: fload #6
    //   1384: fload #5
    //   1386: fload #4
    //   1388: invokespecial <init> : (FFFF)V
    //   1391: astore #9
    //   1393: aload #9
    //   1395: ldc2_w 600
    //   1398: invokevirtual setDuration : (J)V
    //   1401: aload #9
    //   1403: iconst_1
    //   1404: invokevirtual setFillAfter : (Z)V
    //   1407: aload #10
    //   1409: aload #9
    //   1411: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   1414: goto -> 144
    //   1417: iload_3
    //   1418: ifeq -> 1449
    //   1421: fload #5
    //   1423: fstore #6
    //   1425: iload_3
    //   1426: ifeq -> 1455
    //   1429: fconst_0
    //   1430: fstore #4
    //   1432: fconst_0
    //   1433: fstore #8
    //   1435: fconst_0
    //   1436: fstore #7
    //   1438: fload #6
    //   1440: fstore #5
    //   1442: fload #8
    //   1444: fstore #6
    //   1446: goto -> 1376
    //   1449: fconst_0
    //   1450: fstore #6
    //   1452: goto -> 1425
    //   1455: fload #5
    //   1457: fstore #4
    //   1459: goto -> 1432
    //   1462: iload_3
    //   1463: ifeq -> 1491
    //   1466: fload #4
    //   1468: fneg
    //   1469: fstore #7
    //   1471: iload_3
    //   1472: ifeq -> 1497
    //   1475: fconst_0
    //   1476: fstore #4
    //   1478: fconst_0
    //   1479: fstore #5
    //   1481: fload #4
    //   1483: fstore #6
    //   1485: fconst_0
    //   1486: fstore #4
    //   1488: goto -> 1376
    //   1491: fconst_0
    //   1492: fstore #7
    //   1494: goto -> 1471
    //   1497: fload #4
    //   1499: fneg
    //   1500: fstore #4
    //   1502: goto -> 1478
    //   1505: iload_3
    //   1506: ifeq -> 1538
    //   1509: fload #5
    //   1511: fneg
    //   1512: fstore #6
    //   1514: iload_3
    //   1515: ifeq -> 1544
    //   1518: fconst_0
    //   1519: fstore #4
    //   1521: fconst_0
    //   1522: fstore #8
    //   1524: fconst_0
    //   1525: fstore #7
    //   1527: fload #6
    //   1529: fstore #5
    //   1531: fload #8
    //   1533: fstore #6
    //   1535: goto -> 1376
    //   1538: fconst_0
    //   1539: fstore #6
    //   1541: goto -> 1514
    //   1544: fload #5
    //   1546: fneg
    //   1547: fstore #4
    //   1549: goto -> 1521
    //   1552: iload_3
    //   1553: ifeq -> 1580
    //   1556: fload #4
    //   1558: fstore #7
    //   1560: iload_3
    //   1561: ifeq -> 1586
    //   1564: fconst_0
    //   1565: fstore #4
    //   1567: fconst_0
    //   1568: fstore #5
    //   1570: fload #4
    //   1572: fstore #6
    //   1574: fconst_0
    //   1575: fstore #4
    //   1577: goto -> 1376
    //   1580: fconst_0
    //   1581: fstore #7
    //   1583: goto -> 1560
    //   1586: goto -> 1567
    //   1589: getstatic com/chartboost/sdk/impl/o$3.a : [I
    //   1592: aload #12
    //   1594: invokevirtual ordinal : ()I
    //   1597: iaload
    //   1598: tableswitch default -> 1628, 1 -> 1728, 2 -> 1770, 3 -> 1816, 4 -> 1681
    //   1628: fconst_0
    //   1629: fstore #4
    //   1631: fconst_0
    //   1632: fstore #7
    //   1634: fconst_0
    //   1635: fstore #5
    //   1637: fconst_0
    //   1638: fstore #6
    //   1640: new android/view/animation/TranslateAnimation
    //   1643: dup
    //   1644: fload #6
    //   1646: fload #7
    //   1648: fload #5
    //   1650: fload #4
    //   1652: invokespecial <init> : (FFFF)V
    //   1655: astore #9
    //   1657: aload #9
    //   1659: ldc2_w 600
    //   1662: invokevirtual setDuration : (J)V
    //   1665: aload #9
    //   1667: iconst_1
    //   1668: invokevirtual setFillAfter : (Z)V
    //   1671: aload #10
    //   1673: aload #9
    //   1675: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   1678: goto -> 144
    //   1681: iload_3
    //   1682: ifeq -> 1714
    //   1685: fload #5
    //   1687: fneg
    //   1688: fstore #6
    //   1690: iload_3
    //   1691: ifeq -> 1720
    //   1694: fconst_0
    //   1695: fstore #4
    //   1697: fconst_0
    //   1698: fstore #7
    //   1700: fconst_0
    //   1701: fstore #8
    //   1703: fload #6
    //   1705: fstore #5
    //   1707: fload #8
    //   1709: fstore #6
    //   1711: goto -> 1640
    //   1714: fconst_0
    //   1715: fstore #6
    //   1717: goto -> 1690
    //   1720: fload #5
    //   1722: fneg
    //   1723: fstore #4
    //   1725: goto -> 1697
    //   1728: iload_3
    //   1729: ifeq -> 1764
    //   1732: fload #4
    //   1734: fstore #5
    //   1736: fload #4
    //   1738: fstore #7
    //   1740: iload_3
    //   1741: ifeq -> 1747
    //   1744: fconst_0
    //   1745: fstore #7
    //   1747: fconst_0
    //   1748: fstore #8
    //   1750: fload #5
    //   1752: fstore #6
    //   1754: fconst_0
    //   1755: fstore #4
    //   1757: fload #8
    //   1759: fstore #5
    //   1761: goto -> 1640
    //   1764: fconst_0
    //   1765: fstore #5
    //   1767: goto -> 1736
    //   1770: iload_3
    //   1771: ifeq -> 1810
    //   1774: fload #5
    //   1776: fstore #4
    //   1778: iload_3
    //   1779: ifeq -> 1785
    //   1782: fconst_0
    //   1783: fstore #5
    //   1785: fload #4
    //   1787: fstore #6
    //   1789: fconst_0
    //   1790: fstore #7
    //   1792: fconst_0
    //   1793: fstore #8
    //   1795: fload #5
    //   1797: fstore #4
    //   1799: fload #6
    //   1801: fstore #5
    //   1803: fload #8
    //   1805: fstore #6
    //   1807: goto -> 1640
    //   1810: fconst_0
    //   1811: fstore #4
    //   1813: goto -> 1778
    //   1816: iload_3
    //   1817: ifeq -> 1853
    //   1820: fload #4
    //   1822: fneg
    //   1823: fstore #5
    //   1825: iload_3
    //   1826: ifeq -> 1859
    //   1829: fconst_0
    //   1830: fstore #4
    //   1832: fload #4
    //   1834: fstore #7
    //   1836: fconst_0
    //   1837: fstore #4
    //   1839: fconst_0
    //   1840: fstore #8
    //   1842: fload #5
    //   1844: fstore #6
    //   1846: fload #8
    //   1848: fstore #5
    //   1850: goto -> 1640
    //   1853: fconst_0
    //   1854: fstore #5
    //   1856: goto -> 1825
    //   1859: fload #4
    //   1861: fneg
    //   1862: fstore #4
    //   1864: goto -> 1832
    //   1867: iload_3
    //   1868: ifeq -> 2064
    //   1871: new android/view/animation/ScaleAnimation
    //   1874: dup
    //   1875: ldc 0.6
    //   1877: ldc 1.1
    //   1879: ldc 0.6
    //   1881: ldc 1.1
    //   1883: iconst_1
    //   1884: ldc 0.5
    //   1886: iconst_1
    //   1887: ldc 0.5
    //   1889: invokespecial <init> : (FFFFIFIF)V
    //   1892: astore #9
    //   1894: aload #9
    //   1896: ldc2_w 600
    //   1899: l2f
    //   1900: ldc 0.6
    //   1902: fmul
    //   1903: invokestatic round : (F)I
    //   1906: i2l
    //   1907: invokevirtual setDuration : (J)V
    //   1910: aload #9
    //   1912: lconst_0
    //   1913: invokevirtual setStartOffset : (J)V
    //   1916: aload #9
    //   1918: iconst_1
    //   1919: invokevirtual setFillAfter : (Z)V
    //   1922: aload #10
    //   1924: aload #9
    //   1926: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   1929: new android/view/animation/ScaleAnimation
    //   1932: dup
    //   1933: fconst_1
    //   1934: ldc 0.81818175
    //   1936: fconst_1
    //   1937: ldc 0.81818175
    //   1939: iconst_1
    //   1940: ldc 0.5
    //   1942: iconst_1
    //   1943: ldc 0.5
    //   1945: invokespecial <init> : (FFFFIFIF)V
    //   1948: astore #9
    //   1950: aload #9
    //   1952: ldc2_w 600
    //   1955: l2f
    //   1956: ldc 0.19999999
    //   1958: fmul
    //   1959: invokestatic round : (F)I
    //   1962: i2l
    //   1963: invokevirtual setDuration : (J)V
    //   1966: aload #9
    //   1968: ldc2_w 600
    //   1971: l2f
    //   1972: ldc 0.6
    //   1974: fmul
    //   1975: invokestatic round : (F)I
    //   1978: i2l
    //   1979: invokevirtual setStartOffset : (J)V
    //   1982: aload #9
    //   1984: iconst_1
    //   1985: invokevirtual setFillAfter : (Z)V
    //   1988: aload #10
    //   1990: aload #9
    //   1992: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   1995: new android/view/animation/ScaleAnimation
    //   1998: dup
    //   1999: fconst_1
    //   2000: ldc 1.1111112
    //   2002: fconst_1
    //   2003: ldc 1.1111112
    //   2005: iconst_1
    //   2006: ldc 0.5
    //   2008: iconst_1
    //   2009: ldc 0.5
    //   2011: invokespecial <init> : (FFFFIFIF)V
    //   2014: astore #9
    //   2016: aload #9
    //   2018: ldc2_w 600
    //   2021: l2f
    //   2022: ldc 0.099999964
    //   2024: fmul
    //   2025: invokestatic round : (F)I
    //   2028: i2l
    //   2029: invokevirtual setDuration : (J)V
    //   2032: aload #9
    //   2034: ldc2_w 600
    //   2037: l2f
    //   2038: ldc 0.8
    //   2040: fmul
    //   2041: invokestatic round : (F)I
    //   2044: i2l
    //   2045: invokevirtual setStartOffset : (J)V
    //   2048: aload #9
    //   2050: iconst_1
    //   2051: invokevirtual setFillAfter : (Z)V
    //   2054: aload #10
    //   2056: aload #9
    //   2058: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   2061: goto -> 144
    //   2064: new android/view/animation/ScaleAnimation
    //   2067: dup
    //   2068: fconst_1
    //   2069: fconst_0
    //   2070: fconst_1
    //   2071: fconst_0
    //   2072: iconst_1
    //   2073: ldc 0.5
    //   2075: iconst_1
    //   2076: ldc 0.5
    //   2078: invokespecial <init> : (FFFFIFIF)V
    //   2081: astore #9
    //   2083: aload #9
    //   2085: ldc2_w 600
    //   2088: invokevirtual setDuration : (J)V
    //   2091: aload #9
    //   2093: lconst_0
    //   2094: invokevirtual setStartOffset : (J)V
    //   2097: aload #9
    //   2099: iconst_1
    //   2100: invokevirtual setFillAfter : (Z)V
    //   2103: aload #10
    //   2105: aload #9
    //   2107: invokevirtual addAnimation : (Landroid/view/animation/Animation;)V
    //   2110: goto -> 144
    //   2113: aload_2
    //   2114: ifnull -> 2140
    //   2117: new android/os/Handler
    //   2120: dup
    //   2121: invokespecial <init> : ()V
    //   2124: new com/chartboost/sdk/impl/o$2
    //   2127: dup
    //   2128: aload_2
    //   2129: aload_1
    //   2130: invokespecial <init> : (Lcom/chartboost/sdk/impl/o$a;Lcom/chartboost/sdk/Model/a;)V
    //   2133: ldc2_w 600
    //   2136: invokevirtual postDelayed : (Ljava/lang/Runnable;J)Z
    //   2139: pop
    //   2140: aload #11
    //   2142: aload #10
    //   2144: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   2147: return
  }
  
  public static interface a {
    void a(com.chartboost.sdk.Model.a param1a);
  }
  
  public enum b {
    a, b, c, d, e, f;
    
    public static b a(int param1Int) {
      return (param1Int != 0 && param1Int > 0 && param1Int <= (values()).length) ? values()[param1Int - 1] : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\impl\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */