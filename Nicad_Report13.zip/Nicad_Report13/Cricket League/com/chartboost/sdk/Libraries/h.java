package com.chartboost.sdk.Libraries;

import android.app.Activity;
import android.content.Context;
import com.chartboost.sdk.Chartboost;
import java.lang.ref.WeakReference;

public final class h extends WeakReference<Activity> {
  private static h b;
  
  private int a;
  
  private h(Activity paramActivity) {
    super(paramActivity);
    this.a = paramActivity.hashCode();
  }
  
  public static h a(Activity paramActivity) {
    if (b == null || b.a != paramActivity.hashCode())
      b = new h(paramActivity); 
    return b;
  }
  
  public int a() {
    return this.a;
  }
  
  public boolean a(h paramh) {
    return (paramh != null && paramh.a() == this.a);
  }
  
  public Context b() {
    Context context2 = (Context)get();
    Context context1 = context2;
    if (context2 == null)
      context1 = Chartboost.sharedChartboost().getContext(); 
    return context1;
  }
  
  public boolean b(Activity paramActivity) {
    return (paramActivity != null && paramActivity.hashCode() == this.a);
  }
  
  public int hashCode() {
    return a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */