package com.chartboost.sdk.Libraries;

import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import com.chartboost.sdk.Chartboost;
import com.chartboost.sdk.impl.ao;
import com.chartboost.sdk.impl.aq;
import com.chartboost.sdk.impl.ar;
import com.chartboost.sdk.impl.i;
import java.util.UUID;

public final class c {
  private static String a = null;
  
  private static String b = null;
  
  private static a c = a.a;
  
  private static String d = null;
  
  public static void a() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/d
    //   2: monitorenter
    //   3: invokestatic c : ()Lcom/chartboost/sdk/Libraries/c$a;
    //   6: getstatic com/chartboost/sdk/Libraries/c$a.a : Lcom/chartboost/sdk/Libraries/c$a;
    //   9: if_acmpeq -> 16
    //   12: ldc com/chartboost/sdk/Libraries/d
    //   14: monitorexit
    //   15: return
    //   16: getstatic com/chartboost/sdk/Libraries/c$a.b : Lcom/chartboost/sdk/Libraries/c$a;
    //   19: invokestatic a : (Lcom/chartboost/sdk/Libraries/c$a;)V
    //   22: ldc com/chartboost/sdk/Libraries/d
    //   24: monitorexit
    //   25: aconst_null
    //   26: astore_0
    //   27: ldc 'com.google.android.gms.ads.identifier.AdvertisingIdClient'
    //   29: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   32: astore_1
    //   33: aload_1
    //   34: astore_0
    //   35: aload_0
    //   36: ifnonnull -> 49
    //   39: invokestatic f : ()V
    //   42: return
    //   43: astore_0
    //   44: ldc com/chartboost/sdk/Libraries/d
    //   46: monitorexit
    //   47: aload_0
    //   48: athrow
    //   49: invokestatic a : ()Ljava/util/concurrent/ExecutorService;
    //   52: new com/chartboost/sdk/Libraries/c$1
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   64: return
    //   65: astore_1
    //   66: goto -> 35
    // Exception table:
    //   from	to	target	type
    //   3	15	43	finally
    //   16	25	43	finally
    //   27	33	65	java/lang/ClassNotFoundException
    //   44	47	43	finally
  }
  
  protected static void a(a parama) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/c
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/chartboost/sdk/Libraries/c.c : Lcom/chartboost/sdk/Libraries/c$a;
    //   7: ldc com/chartboost/sdk/Libraries/c
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/chartboost/sdk/Libraries/c
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static String b() {
    if (a == null)
      a = b.b(g()); 
    return a;
  }
  
  private static void b(String paramString) {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/c
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/chartboost/sdk/Libraries/c.b : Ljava/lang/String;
    //   7: ldc com/chartboost/sdk/Libraries/c
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/chartboost/sdk/Libraries/c
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static a c() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/c
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/Libraries/c.c : Lcom/chartboost/sdk/Libraries/c$a;
    //   6: astore_0
    //   7: ldc com/chartboost/sdk/Libraries/c
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/chartboost/sdk/Libraries/c
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static String d() {
    // Byte code:
    //   0: ldc com/chartboost/sdk/Libraries/c
    //   2: monitorenter
    //   3: getstatic com/chartboost/sdk/Libraries/c.b : Ljava/lang/String;
    //   6: astore_0
    //   7: ldc com/chartboost/sdk/Libraries/c
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/chartboost/sdk/Libraries/c
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  private static void f() {
    CBLogging.b("CBIdentity", "WARNING: It looks like you've forgotten to include the Google Play Services library in your project. Please review the SDK documentation for more details.");
    a(a.c);
    i.a();
  }
  
  private static byte[] g() {
    String str2 = h();
    if (str2 != null) {
      String str4 = str2;
      if ("9774d56d682e549c".equals(str2)) {
        str4 = i();
        str2 = j();
        String str = d();
        ar ar2 = new ar();
        ar2.a("uuid", str4);
        ar2.a("macid", str2);
        ar2.a("ifa", str);
        return (new aq()).a((ao)ar2);
      } 
      str2 = j();
      String str5 = d();
      ar ar1 = new ar();
      ar1.a("uuid", str4);
      ar1.a("macid", str2);
      ar1.a("ifa", str5);
      return (new aq()).a((ao)ar1);
    } 
    String str1 = i();
    str2 = j();
    String str3 = d();
    ar ar = new ar();
    ar.a("uuid", str1);
    ar.a("macid", str2);
    ar.a("ifa", str3);
    return (new aq()).a((ao)ar);
  }
  
  private static String h() {
    return Settings.Secure.getString(Chartboost.sharedChartboost().getContext().getContentResolver(), "android_id");
  }
  
  private static String i() {
    if (d == null) {
      SharedPreferences sharedPreferences = CBUtility.a();
      d = sharedPreferences.getString("cbUUID", null);
      if (d == null) {
        d = UUID.randomUUID().toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("cbUUID", d);
        editor.commit();
      } 
    } 
    return d;
  }
  
  private static String j() {
    return b.b(b.a(k()));
  }
  
  private static byte[] k() {
    try {
      String str = ((WifiManager)Chartboost.sharedChartboost().getContext().getSystemService("wifi")).getConnectionInfo().getMacAddress();
      if (str == null || str.equals(""))
        return null; 
      String[] arrayOfString = str.split(":");
      byte[] arrayOfByte = new byte[6];
      int i = 0;
      while (true) {
        byte[] arrayOfByte1 = arrayOfByte;
        if (i < arrayOfString.length) {
          arrayOfByte[i] = Integer.valueOf(Integer.parseInt(arrayOfString[i], 16)).byteValue();
          i++;
          continue;
        } 
        break;
      } 
    } catch (Exception exception) {
      return null;
    } 
    return (byte[])exception;
  }
  
  public enum a {
    a(-1),
    b(-1),
    c(-1),
    d(0),
    e(1);
    
    private int f;
    
    a(int param1Int1) {
      this.f = param1Int1;
    }
    
    public int a() {
      return this.f;
    }
    
    public boolean b() {
      return (this.f != -1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */