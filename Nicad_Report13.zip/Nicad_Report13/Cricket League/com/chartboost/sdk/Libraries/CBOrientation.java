package com.chartboost.sdk.Libraries;

public enum CBOrientation {
  UNSPECIFIED, LANDSCAPE, LANDSCAPE_REVERSE, PORTRAIT, PORTRAIT_REVERSE;
  
  public static final CBOrientation LANDSCAPE_LEFT;
  
  public static final CBOrientation LANDSCAPE_RIGHT;
  
  public static final CBOrientation PORTRAIT_LEFT;
  
  public static final CBOrientation PORTRAIT_RIGHT;
  
  static {
    PORTRAIT = new CBOrientation("PORTRAIT", 1);
    LANDSCAPE = new CBOrientation("LANDSCAPE", 2);
    PORTRAIT_REVERSE = new CBOrientation("PORTRAIT_REVERSE", 3);
    LANDSCAPE_REVERSE = new CBOrientation("LANDSCAPE_REVERSE", 4);
    a = new CBOrientation[] { UNSPECIFIED, PORTRAIT, LANDSCAPE, PORTRAIT_REVERSE, LANDSCAPE_REVERSE };
    PORTRAIT_LEFT = PORTRAIT_REVERSE;
    PORTRAIT_RIGHT = PORTRAIT;
    LANDSCAPE_LEFT = LANDSCAPE;
    LANDSCAPE_RIGHT = LANDSCAPE_REVERSE;
  }
  
  public boolean isLandscape() {
    return (this == LANDSCAPE || this == LANDSCAPE_REVERSE);
  }
  
  public boolean isPortrait() {
    return (this == PORTRAIT || this == PORTRAIT_REVERSE);
  }
  
  public CBOrientation rotate180() {
    return rotate90().rotate90();
  }
  
  public CBOrientation rotate270() {
    return rotate90().rotate90().rotate90();
  }
  
  public CBOrientation rotate90() {
    switch (null.a[ordinal()]) {
      default:
        return UNSPECIFIED;
      case 1:
        return PORTRAIT_LEFT;
      case 2:
        return LANDSCAPE_RIGHT;
      case 3:
        return PORTRAIT_RIGHT;
      case 4:
        break;
    } 
    return LANDSCAPE_LEFT;
  }
  
  public enum Difference {
    ANGLE_0, ANGLE_180, ANGLE_270, ANGLE_90;
    
    static {
    
    }
    
    public int getAsInt() {
      switch (CBOrientation.null.b[ordinal()]) {
        default:
          return 0;
        case 1:
          return 90;
        case 2:
          return 180;
        case 3:
          break;
      } 
      return 270;
    }
    
    public boolean isOdd() {
      return (this == ANGLE_90 || this == ANGLE_270);
    }
    
    public boolean isReverse() {
      return (this == ANGLE_180 || this == ANGLE_270);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\CBOrientation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */