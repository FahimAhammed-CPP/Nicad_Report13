package com.chartboost.sdk.Libraries;

import android.content.Context;
import com.chartboost.sdk.Chartboost;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

public final class d {
  protected static String a() {
    Context context = Chartboost.sharedChartboost().getContext();
    try {
      AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(context);
      if (info == null) {
        c.a(c.a.c);
        return null;
      } 
    } catch (IOException null) {
      exception = null;
      if (exception == null) {
        c.a(c.a.c);
        return null;
      } 
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      googlePlayServicesRepairableException = null;
      if (googlePlayServicesRepairableException == null) {
        c.a(c.a.c);
        return null;
      } 
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      googlePlayServicesNotAvailableException = null;
      if (googlePlayServicesNotAvailableException == null) {
        c.a(c.a.c);
        return null;
      } 
    } catch (SecurityException null) {
      CBLogging.a("CBIdentityAdv", "Security Exception when retrieving AD id", exception);
      exception = null;
      if (exception == null) {
        c.a(c.a.c);
        return null;
      } 
    } catch (Exception exception) {
      CBLogging.a("CBIdentityAdv", "General Exception when retrieving AD id", exception);
      exception = null;
      if (exception == null) {
        c.a(c.a.c);
        return null;
      } 
    } 
    if (exception.isLimitAdTrackingEnabled()) {
      c.a(c.a.e);
    } else {
      c.a(c.a.d);
    } 
    try {
      UUID uUID = UUID.fromString(exception.getId());
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[16]);
      byteBuffer.putLong(uUID.getMostSignificantBits());
      byteBuffer.putLong(uUID.getLeastSignificantBits());
      return b.b(byteBuffer.array());
    } catch (IllegalArgumentException illegalArgumentException) {
      CBLogging.b("CBIdentityAdv", "Exception raised retrieveAdvertisingID", illegalArgumentException);
      return exception.getId().replace("-", "");
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\Libraries\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */