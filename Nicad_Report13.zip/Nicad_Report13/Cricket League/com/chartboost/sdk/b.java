package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.chartboost.sdk.Libraries.CBLogging;
import com.chartboost.sdk.Model.CBError;
import com.chartboost.sdk.Model.a;
import com.chartboost.sdk.impl.o;
import com.chartboost.sdk.impl.t;

final class b {
  private static b e;
  
  protected boolean a = false;
  
  private Chartboost b;
  
  private CBPreferences c;
  
  private t d = null;
  
  private b(Chartboost paramChartboost) {
    this.b = paramChartboost;
    this.c = CBPreferences.getInstance();
  }
  
  protected static b a(Chartboost paramChartboost) {
    if (e == null)
      e = new b(paramChartboost); 
    return e;
  }
  
  private void d() {
    Activity activity = this.b.c();
    if (activity != null && activity instanceof CBImpressionActivity) {
      this.b.d();
      activity.finish();
    } 
  }
  
  private void d(a parama) {
    boolean bool;
    CBError.CBImpressionError cBImpressionError1;
    if (this.d != null && this.d.h() != parama) {
      parama.a(CBError.CBImpressionError.IMPRESSION_ALREADY_VISIBLE);
      return;
    } 
    if (parama.c != a.b.c) {
      bool = true;
    } else {
      bool = false;
    } 
    parama.c = a.b.c;
    Activity activity = this.b.c();
    if (activity == null) {
      cBImpressionError1 = CBError.CBImpressionError.NO_HOST_ACTIVITY;
    } else {
      cBImpressionError1 = null;
    } 
    CBError.CBImpressionError cBImpressionError2 = cBImpressionError1;
    if (cBImpressionError1 == null)
      cBImpressionError2 = parama.d(); 
    if (cBImpressionError2 != null) {
      parama.a(cBImpressionError2);
      return;
    } 
    if (this.d == null) {
      this.d = new t((Context)activity, parama);
      activity.addContentView((View)this.d, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    } 
    this.d.a();
    parama.h = this.d;
    if (bool) {
      this.d.e().a();
      o.b b1 = o.b.a;
      if (parama.d == a.c.b)
        b1 = o.b.c; 
      o.b b2 = o.b.a(parama.a.optInt("animation"));
      if (b2 != null)
        b1 = b2; 
      if (this.c.getAnimationsOff())
        b1 = o.b.f; 
      parama.g();
      o.a(b1, parama, new o.a(this) {
            public void a(a param1a) {
              param1a.h();
            }
          });
    } 
    ChartboostDelegate chartboostDelegate = this.c.getDelegate();
    if (chartboostDelegate != null) {
      if (parama.d == a.c.a) {
        chartboostDelegate.didShowInterstitial(parama.e);
        return;
      } 
      if (parama.d == a.c.b) {
        chartboostDelegate.didShowMoreApps();
        return;
      } 
    } 
  }
  
  private void e(a parama) {
    Activity activity = this.b.c();
    if (activity == null) {
      CBLogging.c(this, "No host activity to display loading view");
      return;
    } 
    if (this.d == null) {
      this.d = new t((Context)activity, parama);
      activity.addContentView((View)this.d, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    } 
    this.d.b();
  }
  
  protected void a(a parama) {
    switch (null.a[parama.c.ordinal()]) {
      default:
        d(parama);
        return;
      case 1:
      case 2:
      case 3:
        break;
    } 
    e(parama);
  }
  
  public void a(a parama, boolean paramBoolean) {
    Runnable runnable = new Runnable(this, paramBoolean, parama) {
        public void run() {
          if (!this.a)
            this.c.a = true; 
          this.b.c = a.b.e;
          o.b b1 = o.b.a;
          if (this.b.d == a.c.b)
            b1 = o.b.c; 
          o.b b2 = o.b.a(this.b.a.optInt("animation"));
          if (b2 != null)
            b1 = b2; 
          if (b.a(this.c).getAnimationsOff())
            b1 = o.b.f; 
          o.b(b1, this.b, new o.a(this) {
                public void a(a param2a) {
                  this.a.c.a = false;
                  if (param2a.c != a.b.f)
                    (b.b(this.a.c)).c.post(new Runnable(this, param2a) {
                          public void run() {
                            this.b.a.c.c(this.a);
                          }
                        }); 
                  param2a.f();
                }
              });
        }
      };
    if (parama.k) {
      parama.b(runnable);
      return;
    } 
    runnable.run();
  }
  
  public void a(boolean paramBoolean) {
    if (a()) {
      this.d.c();
      if (paramBoolean && this.d != null && this.d.h() != null)
        c(this.d.h()); 
    } 
  }
  
  public boolean a() {
    return (this.d != null && this.d.g());
  }
  
  public void b(a parama) {
    if (a())
      a(false); 
    parama.c();
    try {
      ((ViewGroup)this.d.getParent()).removeView((View)this.d);
    } catch (Exception exception) {
      CBLogging.b("CBViewController", "Exception removing impression silently", exception);
    } 
    this.d = null;
  }
  
  protected boolean b() {
    return (this.d != null);
  }
  
  public t c() {
    return this.d;
  }
  
  public void c(a parama) {
    parama.c = a.b.g;
    if (this.d == null) {
      if (this.c.getImpressionsUseActivities())
        d(); 
      return;
    } 
    try {
      ((ViewGroup)this.d.getParent()).removeView((View)this.d);
    } catch (Exception exception) {
      CBLogging.b("CBViewController", "Exception removing impression ", exception);
    } 
    parama.b();
    this.d = null;
    this.a = false;
    if (this.c.getImpressionsUseActivities()) {
      d();
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\chartboost\sdk\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */