package com.admob.test;

public final class R {
  public static final class anim {
    public static final int fade_in = 2130968576;
    
    public static final int fade_out = 2130968577;
    
    public static final int slide_in_bottom = 2130968578;
    
    public static final int slide_in_left = 2130968579;
    
    public static final int slide_in_right = 2130968580;
    
    public static final int slide_in_top = 2130968581;
    
    public static final int slide_out_bottom = 2130968582;
    
    public static final int slide_out_left = 2130968583;
    
    public static final int slide_out_right = 2130968584;
    
    public static final int slide_out_top = 2130968585;
  }
  
  public static final class attr {}
  
  public static final class dimen {
    public static final int padding_large = 2131034114;
    
    public static final int padding_medium = 2131034113;
    
    public static final int padding_small = 2131034112;
  }
  
  public static final class drawable {
    public static final int ic_action_search = 2130837504;
    
    public static final int ic_launcher = 2130837505;
  }
  
  public static final class layout {
    public static final int activity_admob = 2130903040;
  }
  
  public static final class string {
    public static final int app_name = 2131099648;
    
    public static final int hello_world = 2131099649;
  }
  
  public static final class style {
    public static final int AppTheme = 2131165184;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\admob\test\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */