package com.example.googleplayplugin;

import android.app.Activity;
import android.content.Context;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.doubleclick.PublisherAdRequest;
import com.google.android.gms.ads.doubleclick.PublisherInterstitialAd;
import com.unity3d.player.UnityPlayer;

public class playads {
  private Activity activity;
  
  private String adUnitIDInt = "ca-app-pub-YOUR-ADMOB-ADUNIT-ID-HERE";
  
  private boolean bIsInterstitialLoaded = false;
  
  private PublisherInterstitialAd interstitial;
  
  private void loadNewInterstitial() {
    PublisherAdRequest publisherAdRequest = (new PublisherAdRequest.Builder()).build();
    this.interstitial.loadAd(publisherAdRequest);
  }
  
  public void displayInterstitial() {
    this.activity.runOnUiThread(new Runnable() {
          public void run() {
            if (playads.this.interstitial.isLoaded())
              playads.this.interstitial.show(); 
          }
        });
  }
  
  public boolean isInterstitialLoaded() {
    return this.bIsInterstitialLoaded;
  }
  
  public void playintads(String paramString) {
    this.adUnitIDInt = paramString;
    this.activity = UnityPlayer.currentActivity;
    this.activity.runOnUiThread(new Runnable() {
          public void run() {
            playads.this.interstitial = new PublisherInterstitialAd((Context)playads.this.activity);
            playads.this.interstitial.setAdUnitId(playads.this.adUnitIDInt);
            playads.this.interstitial.setAdListener(new AdListener() {
                  public void onAdClosed() {
                    PublisherAdRequest publisherAdRequest = (new PublisherAdRequest.Builder()).build();
                    (playads.null.access$0(playads.null.this)).interstitial.loadAd(publisherAdRequest);
                    (playads.null.access$0(playads.null.this)).bIsInterstitialLoaded = false;
                  }
                  
                  public void onAdLoaded() {
                    (playads.null.access$0(playads.null.this)).bIsInterstitialLoaded = true;
                  }
                });
            playads.this.loadNewInterstitial();
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\example\googleplayplugin\playads.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */