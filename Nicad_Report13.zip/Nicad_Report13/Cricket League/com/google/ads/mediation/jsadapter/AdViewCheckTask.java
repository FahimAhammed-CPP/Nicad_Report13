package com.google.ads.mediation.jsadapter;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import com.google.android.gms.internal.ct;

public final class AdViewCheckTask implements Runnable {
  public static final int BACKGROUND_COLOR = 0;
  
  private final JavascriptAdapter r;
  
  private final Handler s;
  
  private final long t;
  
  private long u;
  
  public AdViewCheckTask(JavascriptAdapter paramJavascriptAdapter, long paramLong1, long paramLong2) {
    this.r = paramJavascriptAdapter;
    this.t = paramLong1;
    this.u = paramLong2;
    this.s = new Handler(Looper.getMainLooper());
  }
  
  public void run() {
    if (this.r == null || this.r.shouldStopAdCheck())
      return; 
    (new a(this, this.r.getWebViewWidth(), this.r.getWebViewHeight(), this.r.getWebView())).execute((Object[])new Void[0]);
  }
  
  public void start() {
    this.s.postDelayed(this, this.t);
  }
  
  private final class a extends AsyncTask<Void, Void, Boolean> {
    private final int v;
    
    private final int w;
    
    private final WebView x;
    
    private Bitmap y;
    
    public a(AdViewCheckTask this$0, int param1Int1, int param1Int2, WebView param1WebView) {
      this.v = param1Int2;
      this.w = param1Int1;
      this.x = param1WebView;
    }
    
    protected Boolean a(Void... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield y : Landroid/graphics/Bitmap;
      //   6: invokevirtual getWidth : ()I
      //   9: istore #6
      //   11: aload_0
      //   12: getfield y : Landroid/graphics/Bitmap;
      //   15: invokevirtual getHeight : ()I
      //   18: istore #7
      //   20: iload #6
      //   22: ifeq -> 30
      //   25: iload #7
      //   27: ifne -> 39
      //   30: iconst_0
      //   31: invokestatic valueOf : (Z)Ljava/lang/Boolean;
      //   34: astore_1
      //   35: aload_0
      //   36: monitorexit
      //   37: aload_1
      //   38: areturn
      //   39: iconst_0
      //   40: istore_2
      //   41: iconst_0
      //   42: istore_3
      //   43: iload_2
      //   44: iload #6
      //   46: if_icmpge -> 83
      //   49: iconst_0
      //   50: istore #4
      //   52: iload #4
      //   54: iload #7
      //   56: if_icmpge -> 139
      //   59: iload_3
      //   60: istore #5
      //   62: aload_0
      //   63: getfield y : Landroid/graphics/Bitmap;
      //   66: iload_2
      //   67: iload #4
      //   69: invokevirtual getPixel : (II)I
      //   72: ifeq -> 126
      //   75: iload_3
      //   76: iconst_1
      //   77: iadd
      //   78: istore #5
      //   80: goto -> 126
      //   83: iload_3
      //   84: i2d
      //   85: iload #6
      //   87: iload #7
      //   89: imul
      //   90: i2d
      //   91: ldc2_w 100.0
      //   94: ddiv
      //   95: ddiv
      //   96: ldc2_w 0.1
      //   99: dcmpl
      //   100: ifle -> 115
      //   103: iconst_1
      //   104: istore #8
      //   106: iload #8
      //   108: invokestatic valueOf : (Z)Ljava/lang/Boolean;
      //   111: astore_1
      //   112: goto -> 35
      //   115: iconst_0
      //   116: istore #8
      //   118: goto -> 106
      //   121: astore_1
      //   122: aload_0
      //   123: monitorexit
      //   124: aload_1
      //   125: athrow
      //   126: iload #4
      //   128: bipush #10
      //   130: iadd
      //   131: istore #4
      //   133: iload #5
      //   135: istore_3
      //   136: goto -> 52
      //   139: iload_2
      //   140: bipush #10
      //   142: iadd
      //   143: istore_2
      //   144: goto -> 43
      // Exception table:
      //   from	to	target	type
      //   2	20	121	finally
      //   62	75	121	finally
      //   83	103	121	finally
    }
    
    protected void a(Boolean param1Boolean) {
      AdViewCheckTask.a(this.z);
      if (param1Boolean.booleanValue()) {
        AdViewCheckTask.b(this.z).sendAdReceivedUpdate();
        return;
      } 
      if (AdViewCheckTask.c(this.z) > 0L) {
        if (ct.n(2))
          ct.r("Ad not detected, scheduling another run."); 
        AdViewCheckTask.e(this.z).postDelayed(this.z, AdViewCheckTask.d(this.z));
        return;
      } 
      ct.r("Ad not detected, Not scheduling anymore runs.");
      AdViewCheckTask.b(this.z).sendAdNotReceivedUpdate();
    }
    
    protected void onPreExecute() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aload_0
      //   4: getfield w : I
      //   7: aload_0
      //   8: getfield v : I
      //   11: getstatic android/graphics/Bitmap$Config.ARGB_8888 : Landroid/graphics/Bitmap$Config;
      //   14: invokestatic createBitmap : (IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
      //   17: putfield y : Landroid/graphics/Bitmap;
      //   20: aload_0
      //   21: getfield x : Landroid/webkit/WebView;
      //   24: iconst_0
      //   25: invokevirtual setVisibility : (I)V
      //   28: aload_0
      //   29: getfield x : Landroid/webkit/WebView;
      //   32: aload_0
      //   33: getfield w : I
      //   36: iconst_0
      //   37: invokestatic makeMeasureSpec : (II)I
      //   40: aload_0
      //   41: getfield v : I
      //   44: iconst_0
      //   45: invokestatic makeMeasureSpec : (II)I
      //   48: invokevirtual measure : (II)V
      //   51: aload_0
      //   52: getfield x : Landroid/webkit/WebView;
      //   55: iconst_0
      //   56: iconst_0
      //   57: aload_0
      //   58: getfield w : I
      //   61: aload_0
      //   62: getfield v : I
      //   65: invokevirtual layout : (IIII)V
      //   68: new android/graphics/Canvas
      //   71: dup
      //   72: aload_0
      //   73: getfield y : Landroid/graphics/Bitmap;
      //   76: invokespecial <init> : (Landroid/graphics/Bitmap;)V
      //   79: astore_1
      //   80: aload_0
      //   81: getfield x : Landroid/webkit/WebView;
      //   84: aload_1
      //   85: invokevirtual draw : (Landroid/graphics/Canvas;)V
      //   88: aload_0
      //   89: getfield x : Landroid/webkit/WebView;
      //   92: invokevirtual invalidate : ()V
      //   95: aload_0
      //   96: monitorexit
      //   97: return
      //   98: astore_1
      //   99: aload_0
      //   100: monitorexit
      //   101: aload_1
      //   102: athrow
      // Exception table:
      //   from	to	target	type
      //   2	95	98	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\jsadapter\AdViewCheckTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */