package com.google.ads.mediation.jsadapter;

import android.text.TextUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.internal.ct;
import java.net.URI;
import java.net.URISyntaxException;

public final class BannerWebViewClient extends WebViewClient {
  private final String A;
  
  private boolean B;
  
  private final JavascriptAdapter r;
  
  public BannerWebViewClient(JavascriptAdapter paramJavascriptAdapter, String paramString) {
    this.A = c(paramString);
    this.r = paramJavascriptAdapter;
    this.B = false;
  }
  
  private boolean b(String paramString) {
    paramString = c(paramString);
    if (!TextUtils.isEmpty(paramString))
      try {
        URI uRI = new URI(paramString);
        if ("passback".equals(uRI.getScheme())) {
          ct.r("Passback received");
          this.r.sendAdNotReceivedUpdate();
          return true;
        } 
        if (!TextUtils.isEmpty(this.A)) {
          URI uRI1 = new URI(this.A);
          paramString = uRI1.getHost();
          String str1 = uRI.getHost();
          String str3 = uRI1.getPath();
          String str2 = uRI.getPath();
          if (equals(paramString, str1) && equals(str3, str2)) {
            ct.r("Passback received");
            this.r.sendAdNotReceivedUpdate();
            return true;
          } 
        } 
        return false;
      } catch (URISyntaxException uRISyntaxException) {
        ct.s(uRISyntaxException.getMessage());
        return false;
      }  
    return false;
  }
  
  private String c(String paramString) {
    if (!TextUtils.isEmpty(paramString))
      try {
        return paramString.endsWith("/") ? paramString.substring(0, paramString.length() - 1) : paramString;
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        ct.s(indexOutOfBoundsException.getMessage());
        return paramString;
      }  
    return paramString;
  }
  
  private static boolean equals(Object paramObject1, Object paramObject2) {
    return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2)));
  }
  
  public void onLoadResource(WebView paramWebView, String paramString) {
    ct.u("onLoadResource: " + paramString);
    if (!b(paramString))
      super.onLoadResource(paramWebView, paramString); 
  }
  
  public void onPageFinished(WebView paramWebView, String paramString) {
    ct.u("onPageFinished: " + paramString);
    super.onPageFinished(paramWebView, paramString);
    if (!this.B) {
      this.r.startCheckingForAd();
      this.B = true;
    } 
  }
  
  public boolean shouldOverrideUrlLoading(WebView paramWebView, String paramString) {
    ct.u("shouldOverrideUrlLoading: " + paramString);
    if (b(paramString)) {
      ct.r("shouldOverrideUrlLoading: received passback url");
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\jsadapter\BannerWebViewClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */