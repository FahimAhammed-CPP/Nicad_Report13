package com.google.ads.mediation;

import com.google.ads.AdRequest;

@Deprecated
public interface MediationBannerListener {
  void onClick(MediationBannerAdapter<?, ?> paramMediationBannerAdapter);
  
  void onDismissScreen(MediationBannerAdapter<?, ?> paramMediationBannerAdapter);
  
  void onFailedToReceiveAd(MediationBannerAdapter<?, ?> paramMediationBannerAdapter, AdRequest.ErrorCode paramErrorCode);
  
  void onLeaveApplication(MediationBannerAdapter<?, ?> paramMediationBannerAdapter);
  
  void onPresentScreen(MediationBannerAdapter<?, ?> paramMediationBannerAdapter);
  
  void onReceivedAd(MediationBannerAdapter<?, ?> paramMediationBannerAdapter);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\ads\mediation\MediationBannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */