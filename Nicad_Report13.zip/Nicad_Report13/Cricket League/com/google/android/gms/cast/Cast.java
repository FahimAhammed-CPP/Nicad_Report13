package com.google.android.gms.cast;

import android.content.Context;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.dt;
import com.google.android.gms.internal.eg;
import java.io.IOException;

public final class Cast {
  public static final Api API;
  
  public static final CastApi CastApi;
  
  public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
  
  public static final int MAX_MESSAGE_LENGTH = 65536;
  
  public static final int MAX_NAMESPACE_LENGTH = 128;
  
  static final Api.b<dg> jO = new Api.b<dg>() {
      public dg c(Context param1Context, dt param1dt, GoogleApiClient.ApiOptions param1ApiOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        eg.b(param1ApiOptions, "Setting the API options is required.");
        eg.b(param1ApiOptions instanceof Cast.CastOptions, "Must provide valid CastOptions!");
        Cast.CastOptions castOptions = (Cast.CastOptions)param1ApiOptions;
        return new dg(param1Context, castOptions.ks, Cast.CastOptions.a(castOptions), castOptions.kt, param1ConnectionCallbacks, param1OnConnectionFailedListener);
      }
      
      public int getPriority() {
        return Integer.MAX_VALUE;
      }
    };
  
  static {
    API = new Api(jO, new com.google.android.gms.common.api.Scope[0]);
    CastApi = new CastApi.a();
  }
  
  public static interface ApplicationConnectionResult extends Result {
    ApplicationMetadata getApplicationMetadata();
    
    String getApplicationStatus();
    
    String getSessionId();
    
    boolean getWasLaunched();
  }
  
  public static interface CastApi {
    ApplicationMetadata getApplicationMetadata(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    String getApplicationStatus(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    double getVolume(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    boolean isMute(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient);
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2);
    
    PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, boolean param1Boolean);
    
    PendingResult<Status> leaveApplication(GoogleApiClient param1GoogleApiClient);
    
    void removeMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String) throws IOException, IllegalStateException;
    
    void requestStatus(GoogleApiClient param1GoogleApiClient) throws IOException, IllegalStateException;
    
    PendingResult<Status> sendMessage(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2);
    
    void setMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String, Cast.MessageReceivedCallback param1MessageReceivedCallback) throws IOException, IllegalStateException;
    
    void setMute(GoogleApiClient param1GoogleApiClient, boolean param1Boolean) throws IOException, IllegalStateException;
    
    void setVolume(GoogleApiClient param1GoogleApiClient, double param1Double) throws IOException, IllegalArgumentException, IllegalStateException;
    
    PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient);
    
    PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    public static final class a implements CastApi {
      public ApplicationMetadata getApplicationMetadata(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((dg)param2GoogleApiClient.a(Cast.jO)).getApplicationMetadata();
      }
      
      public String getApplicationStatus(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((dg)param2GoogleApiClient.a(Cast.jO)).getApplicationStatus();
      }
      
      public double getVolume(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((dg)param2GoogleApiClient.a(Cast.jO)).aW();
      }
      
      public boolean isMute(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((dg)param2GoogleApiClient.a(Cast.jO)).isMute();
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this) {
              protected void a(dg param3dg) {
                try {
                  param3dg.b(null, null, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2String) {
              protected void a(dg param3dg) {
                try {
                  param3dg.b(this.kp, null, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2String1, param2String2) {
              protected void a(dg param3dg) {
                try {
                  param3dg.b(this.kp, this.kr, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2String) {
              protected void a(dg param3dg) {
                try {
                  param3dg.a(this.kp, false, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param2GoogleApiClient, String param2String, boolean param2Boolean) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2String, param2Boolean) {
              protected void a(dg param3dg) {
                try {
                  param3dg.a(this.kp, this.kq, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Status> leaveApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this) {
              protected void a(dg param3dg) {
                try {
                  param3dg.e((com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public void removeMessageReceivedCallbacks(GoogleApiClient param2GoogleApiClient, String param2String) throws IOException, IllegalStateException {
        try {
          ((dg)param2GoogleApiClient.a(Cast.jO)).C(param2String);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void requestStatus(GoogleApiClient param2GoogleApiClient) throws IOException, IllegalStateException {
        try {
          ((dg)param2GoogleApiClient.a(Cast.jO)).aV();
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public PendingResult<Status> sendMessage(GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2String1, param2String2) {
              protected void a(dg param3dg) {
                try {
                  param3dg.a(this.km, this.kn, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalArgumentException illegalArgumentException) {
                  r(2001);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public void setMessageReceivedCallbacks(GoogleApiClient param2GoogleApiClient, String param2String, Cast.MessageReceivedCallback param2MessageReceivedCallback) throws IOException, IllegalStateException {
        try {
          ((dg)param2GoogleApiClient.a(Cast.jO)).a(param2String, param2MessageReceivedCallback);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void setMute(GoogleApiClient param2GoogleApiClient, boolean param2Boolean) throws IOException, IllegalStateException {
        try {
          ((dg)param2GoogleApiClient.a(Cast.jO)).n(param2Boolean);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void setVolume(GoogleApiClient param2GoogleApiClient, double param2Double) throws IOException, IllegalArgumentException, IllegalStateException {
        try {
          ((dg)param2GoogleApiClient.a(Cast.jO)).a(param2Double);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public PendingResult<Status> stopApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this) {
              protected void a(dg param3dg) {
                try {
                  param3dg.a("", (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Status> stopApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2String) {
              protected void a(dg param3dg) {
                if (TextUtils.isEmpty(this.kr)) {
                  c(2001, "IllegalArgument: sessionId cannot be null or empty");
                  return;
                } 
                try {
                  param3dg.a(this.kr, (com.google.android.gms.common.api.a.c)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  r(2001);
                  return;
                } catch (RemoteException remoteException) {
                  r(8);
                  return;
                } 
              }
            });
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, String param2String1, String param2String2) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.a(this.km, this.kn, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalArgumentException illegalArgumentException) {
          r(2001);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, String param2String) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.a(this.kp, false, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, String param2String, boolean param2Boolean) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.a(this.kp, this.kq, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, String param2String1, String param2String2) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.b(this.kp, this.kr, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, String param2String) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.b(this.kp, null, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.b(null, null, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.e((com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0) {}
      
      protected void a(dg param2dg) {
        try {
          param2dg.a("", (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, String param2String) {}
      
      protected void a(dg param2dg) {
        if (TextUtils.isEmpty(this.kr)) {
          c(2001, "IllegalArgument: sessionId cannot be null or empty");
          return;
        } 
        try {
          param2dg.a(this.kr, (com.google.android.gms.common.api.a.c)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          r(2001);
          return;
        } catch (RemoteException remoteException) {
          r(8);
          return;
        } 
      }
    }
  }
  
  public static final class a implements CastApi {
    public ApplicationMetadata getApplicationMetadata(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((dg)param1GoogleApiClient.a(Cast.jO)).getApplicationMetadata();
    }
    
    public String getApplicationStatus(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((dg)param1GoogleApiClient.a(Cast.jO)).getApplicationStatus();
    }
    
    public double getVolume(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((dg)param1GoogleApiClient.a(Cast.jO)).aW();
    }
    
    public boolean isMute(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((dg)param1GoogleApiClient.a(Cast.jO)).isMute();
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this) {
            protected void a(dg param3dg) {
              try {
                param3dg.b(null, null, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1String) {
            protected void a(dg param3dg) {
              try {
                param3dg.b(this.kp, null, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1String1, param1String2) {
            protected void a(dg param3dg) {
              try {
                param3dg.b(this.kp, this.kr, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1String) {
            protected void a(dg param3dg) {
              try {
                param3dg.a(this.kp, false, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, boolean param1Boolean) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1String, param1Boolean) {
            protected void a(dg param3dg) {
              try {
                param3dg.a(this.kp, this.kq, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Status> leaveApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this) {
            protected void a(dg param3dg) {
              try {
                param3dg.e((com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public void removeMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String) throws IOException, IllegalStateException {
      try {
        ((dg)param1GoogleApiClient.a(Cast.jO)).C(param1String);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void requestStatus(GoogleApiClient param1GoogleApiClient) throws IOException, IllegalStateException {
      try {
        ((dg)param1GoogleApiClient.a(Cast.jO)).aV();
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public PendingResult<Status> sendMessage(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1String1, param1String2) {
            protected void a(dg param3dg) {
              try {
                param3dg.a(this.km, this.kn, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalArgumentException illegalArgumentException) {
                r(2001);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public void setMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String, Cast.MessageReceivedCallback param1MessageReceivedCallback) throws IOException, IllegalStateException {
      try {
        ((dg)param1GoogleApiClient.a(Cast.jO)).a(param1String, param1MessageReceivedCallback);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void setMute(GoogleApiClient param1GoogleApiClient, boolean param1Boolean) throws IOException, IllegalStateException {
      try {
        ((dg)param1GoogleApiClient.a(Cast.jO)).n(param1Boolean);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void setVolume(GoogleApiClient param1GoogleApiClient, double param1Double) throws IOException, IllegalArgumentException, IllegalStateException {
      try {
        ((dg)param1GoogleApiClient.a(Cast.jO)).a(param1Double);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this) {
            protected void a(dg param3dg) {
              try {
                param3dg.a("", (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1String) {
            protected void a(dg param3dg) {
              if (TextUtils.isEmpty(this.kr)) {
                c(2001, "IllegalArgument: sessionId cannot be null or empty");
                return;
              } 
              try {
                param3dg.a(this.kr, (com.google.android.gms.common.api.a.c)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                r(2001);
                return;
              } catch (RemoteException remoteException) {
                r(8);
                return;
              } 
            }
          });
    }
  }
  
  class null extends b {
    null(Cast this$0, String param1String1, String param1String2) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.a(this.km, this.kn, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        r(2001);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, String param1String) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.a(this.kp, false, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, String param1String, boolean param1Boolean) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.a(this.kp, this.kq, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, String param1String1, String param1String2) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.b(this.kp, this.kr, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, String param1String) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.b(this.kp, null, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.b(null, null, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.e((com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0) {}
    
    protected void a(dg param1dg) {
      try {
        param1dg.a("", (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0, String param1String) {}
    
    protected void a(dg param1dg) {
      if (TextUtils.isEmpty(this.kr)) {
        c(2001, "IllegalArgument: sessionId cannot be null or empty");
        return;
      } 
      try {
        param1dg.a(this.kr, (com.google.android.gms.common.api.a.c)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        r(2001);
        return;
      } catch (RemoteException remoteException) {
        r(8);
        return;
      } 
    }
  }
  
  public static final class CastOptions implements GoogleApiClient.ApiOptions {
    final CastDevice ks;
    
    final Cast.Listener kt;
    
    private final int ku;
    
    private CastOptions(Builder param1Builder) {
      this.ks = param1Builder.kv;
      this.kt = param1Builder.kw;
      this.ku = Builder.a(param1Builder);
    }
    
    public static Builder builder(CastDevice param1CastDevice, Cast.Listener param1Listener) {
      return new Builder(param1CastDevice, param1Listener);
    }
    
    public static final class Builder {
      CastDevice kv;
      
      Cast.Listener kw;
      
      private int kx;
      
      private Builder(CastDevice param2CastDevice, Cast.Listener param2Listener) {
        this.kv = param2CastDevice;
        this.kw = param2Listener;
        this.kx = 0;
      }
      
      public Cast.CastOptions build() {
        return new Cast.CastOptions(this);
      }
      
      public Builder setDebuggingEnabled() {
        this.kx |= 0x1;
        return this;
      }
    }
  }
  
  public static final class Builder {
    CastDevice kv;
    
    Cast.Listener kw;
    
    private int kx;
    
    private Builder(CastDevice param1CastDevice, Cast.Listener param1Listener) {
      this.kv = param1CastDevice;
      this.kw = param1Listener;
      this.kx = 0;
    }
    
    public Cast.CastOptions build() {
      return new Cast.CastOptions(this);
    }
    
    public Builder setDebuggingEnabled() {
      this.kx |= 0x1;
      return this;
    }
  }
  
  public static abstract class Listener {
    public void onApplicationDisconnected(int param1Int) {}
    
    public void onApplicationStatusChanged() {}
    
    public void onVolumeChanged() {}
  }
  
  public static interface MessageReceivedCallback {
    void onMessageReceived(CastDevice param1CastDevice, String param1String1, String param1String2);
  }
  
  protected static abstract class a<R extends Result> extends com.google.android.gms.common.api.a.a<R, dg> implements PendingResult<R> {
    public a() {
      super(Cast.jO);
    }
    
    public void c(int param1Int, String param1String) {
      a(e(new Status(param1Int, param1String, null)));
    }
    
    public void r(int param1Int) {
      a(e(new Status(param1Int)));
    }
  }
  
  private static abstract class b extends a<Status> {
    private b() {}
    
    public Status g(Status param1Status) {
      return param1Status;
    }
  }
  
  private static abstract class c extends a<ApplicationConnectionResult> {
    private c() {}
    
    public Cast.ApplicationConnectionResult i(Status param1Status) {
      return new Cast.ApplicationConnectionResult(this, param1Status) {
          public ApplicationMetadata getApplicationMetadata() {
            return null;
          }
          
          public String getApplicationStatus() {
            return null;
          }
          
          public String getSessionId() {
            return null;
          }
          
          public Status getStatus() {
            return this.jP;
          }
          
          public boolean getWasLaunched() {
            return false;
          }
        };
    }
  }
  
  class null implements ApplicationConnectionResult {
    null(Cast this$0, Status param1Status) {}
    
    public ApplicationMetadata getApplicationMetadata() {
      return null;
    }
    
    public String getApplicationStatus() {
      return null;
    }
    
    public String getSessionId() {
      return null;
    }
    
    public Status getStatus() {
      return this.jP;
    }
    
    public boolean getWasLaunched() {
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\cast\Cast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */