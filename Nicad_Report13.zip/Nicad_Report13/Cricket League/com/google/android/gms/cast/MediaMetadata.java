package com.google.android.gms.cast;

import android.os.Bundle;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.internal.dp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaMetadata {
  public static final String KEY_ALBUM_ARTIST = "com.google.android.gms.cast.metadata.ALBUM_ARTIST";
  
  public static final String KEY_ALBUM_TITLE = "com.google.android.gms.cast.metadata.ALBUM_TITLE";
  
  public static final String KEY_ARTIST = "com.google.android.gms.cast.metadata.ARTIST";
  
  public static final String KEY_BROADCAST_DATE = "com.google.android.gms.cast.metadata.BROADCAST_DATE";
  
  public static final String KEY_COMPOSER = "com.google.android.gms.cast.metadata.COMPOSER";
  
  public static final String KEY_CREATION_DATE = "com.google.android.gms.cast.metadata.CREATION_DATE";
  
  public static final String KEY_DISC_NUMBER = "com.google.android.gms.cast.metadata.DISC_NUMBER";
  
  public static final String KEY_EPISODE_NUMBER = "com.google.android.gms.cast.metadata.EPISODE_NUMBER";
  
  public static final String KEY_HEIGHT = "com.google.android.gms.cast.metadata.HEIGHT";
  
  public static final String KEY_LOCATION_LATITUDE = "com.google.android.gms.cast.metadata.LOCATION_LATITUDE";
  
  public static final String KEY_LOCATION_LONGITUDE = "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE";
  
  public static final String KEY_LOCATION_NAME = "com.google.android.gms.cast.metadata.LOCATION_NAME";
  
  public static final String KEY_RELEASE_DATE = "com.google.android.gms.cast.metadata.RELEASE_DATE";
  
  public static final String KEY_SEASON_NUMBER = "com.google.android.gms.cast.metadata.SEASON_NUMBER";
  
  public static final String KEY_SERIES_TITLE = "com.google.android.gms.cast.metadata.SERIES_TITLE";
  
  public static final String KEY_STUDIO = "com.google.android.gms.cast.metadata.STUDIO";
  
  public static final String KEY_SUBTITLE = "com.google.android.gms.cast.metadata.SUBTITLE";
  
  public static final String KEY_TITLE = "com.google.android.gms.cast.metadata.TITLE";
  
  public static final String KEY_TRACK_NUMBER = "com.google.android.gms.cast.metadata.TRACK_NUMBER";
  
  public static final String KEY_WIDTH = "com.google.android.gms.cast.metadata.WIDTH";
  
  public static final int MEDIA_TYPE_GENERIC = 0;
  
  public static final int MEDIA_TYPE_MOVIE = 1;
  
  public static final int MEDIA_TYPE_MUSIC_TRACK = 3;
  
  public static final int MEDIA_TYPE_PHOTO = 4;
  
  public static final int MEDIA_TYPE_TV_SHOW = 2;
  
  public static final int MEDIA_TYPE_USER = 100;
  
  private static final String[] kO = new String[] { null, "String", "int", "double", "ISO-8601 date String" };
  
  private static final a kP = (new a()).a("com.google.android.gms.cast.metadata.CREATION_DATE", "creationDateTime", 4).a("com.google.android.gms.cast.metadata.RELEASE_DATE", "releaseDate", 4).a("com.google.android.gms.cast.metadata.BROADCAST_DATE", "originalAirdate", 4).a("com.google.android.gms.cast.metadata.TITLE", "title", 1).a("com.google.android.gms.cast.metadata.SUBTITLE", "subtitle", 1).a("com.google.android.gms.cast.metadata.ARTIST", "artist", 1).a("com.google.android.gms.cast.metadata.ALBUM_ARTIST", "albumArtist", 1).a("com.google.android.gms.cast.metadata.ALBUM_TITLE", "albumName", 1).a("com.google.android.gms.cast.metadata.COMPOSER", "composer", 1).a("com.google.android.gms.cast.metadata.DISC_NUMBER", "discNumber", 2).a("com.google.android.gms.cast.metadata.TRACK_NUMBER", "trackNumber", 2).a("com.google.android.gms.cast.metadata.SEASON_NUMBER", "season", 2).a("com.google.android.gms.cast.metadata.EPISODE_NUMBER", "episode", 2).a("com.google.android.gms.cast.metadata.SERIES_TITLE", "seriesTitle", 1).a("com.google.android.gms.cast.metadata.STUDIO", "studio", 1).a("com.google.android.gms.cast.metadata.WIDTH", "width", 2).a("com.google.android.gms.cast.metadata.HEIGHT", "height", 2).a("com.google.android.gms.cast.metadata.LOCATION_NAME", "location", 1).a("com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "latitude", 3).a("com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "longitude", 3);
  
  private final Bundle kQ = new Bundle();
  
  private int kR;
  
  private final List<WebImage> ki = new ArrayList<WebImage>();
  
  public MediaMetadata() {
    this(0);
  }
  
  public MediaMetadata(int paramInt) {
    this.kR = paramInt;
  }
  
  private void a(String paramString, int paramInt) throws IllegalArgumentException {
    int i = kP.A(paramString);
    if (i != paramInt && i != 0)
      throw new IllegalArgumentException("Value for " + paramString + " must be a " + kO[paramInt]); 
  }
  
  private void a(JSONObject paramJSONObject, String... paramVarArgs) {
    try {
      int j = paramVarArgs.length;
      for (int i = 0;; i++) {
        if (i < j) {
          String str = paramVarArgs[i];
          if (this.kQ.containsKey(str))
            switch (kP.A(str)) {
              case 1:
              case 4:
                paramJSONObject.put(kP.y(str), this.kQ.getString(str));
                break;
              case 2:
                paramJSONObject.put(kP.y(str), this.kQ.getInt(str));
                break;
              case 3:
                paramJSONObject.put(kP.y(str), this.kQ.getDouble(str));
                break;
            }  
        } else {
          for (String str : this.kQ.keySet()) {
            if (!str.startsWith("com.google.")) {
              Object object = this.kQ.get(str);
              if (object instanceof String) {
                paramJSONObject.put(str, object);
                continue;
              } 
              if (object instanceof Integer) {
                paramJSONObject.put(str, object);
                continue;
              } 
              if (object instanceof Double)
                paramJSONObject.put(str, object); 
            } 
          } 
          break;
        } 
      } 
    } catch (JSONException jSONException) {}
  }
  
  private boolean a(Bundle paramBundle1, Bundle paramBundle2) {
    if (paramBundle1.size() != paramBundle2.size())
      return false; 
    for (String str : paramBundle1.keySet()) {
      Object object1 = paramBundle1.get(str);
      Object object2 = paramBundle2.get(str);
      if (object1 instanceof Bundle && object2 instanceof Bundle && !a((Bundle)object1, (Bundle)object2))
        return false; 
      if (object1 == null) {
        if (object2 != null || !paramBundle2.containsKey(str))
          return false; 
        continue;
      } 
      if (!object1.equals(object2))
        return false; 
    } 
    return true;
  }
  
  private void b(JSONObject paramJSONObject, String... paramVarArgs) {
    HashSet hashSet = new HashSet(Arrays.asList((Object[])paramVarArgs));
    try {
      Iterator<String> iterator = paramJSONObject.keys();
      while (iterator.hasNext()) {
        Object object = iterator.next();
        String str = kP.z((String)object);
        if (str != null) {
          boolean bool = hashSet.contains(str);
          if (bool)
            try {
              object = paramJSONObject.get((String)object);
              if (object != null)
                switch (kP.A(str)) {
                  case 1:
                    if (object instanceof String)
                      this.kQ.putString(str, (String)object); 
                    continue;
                  case 4:
                    if (object instanceof String && dp.G((String)object) != null)
                      this.kQ.putString(str, (String)object); 
                    continue;
                  case 2:
                    if (object instanceof Integer)
                      this.kQ.putInt(str, ((Integer)object).intValue()); 
                    continue;
                  case 3:
                    if (object instanceof Double)
                      this.kQ.putDouble(str, ((Double)object).doubleValue()); 
                    continue;
                }  
            } catch (JSONException jSONException) {} 
          continue;
        } 
        object = paramJSONObject.get((String)object);
        if (object instanceof String) {
          this.kQ.putString((String)jSONException, (String)object);
          continue;
        } 
        if (object instanceof Integer) {
          this.kQ.putInt((String)jSONException, ((Integer)object).intValue());
          continue;
        } 
        if (object instanceof Double)
          this.kQ.putDouble((String)jSONException, ((Double)object).doubleValue()); 
      } 
    } catch (JSONException jSONException) {}
  }
  
  public JSONObject aP() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("metadataType", this.kR);
    } catch (JSONException jSONException) {}
    dp.a(jSONObject, this.ki);
    switch (this.kR) {
      default:
        a(jSONObject, new String[0]);
        return jSONObject;
      case 0:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 1:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 2:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE" });
        return jSONObject;
      case 3:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 4:
        break;
    } 
    a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE" });
  }
  
  public void addImage(WebImage paramWebImage) {
    this.ki.add(paramWebImage);
  }
  
  public void b(JSONObject paramJSONObject) {
    clear();
    this.kR = 0;
    try {
      this.kR = paramJSONObject.getInt("metadataType");
    } catch (JSONException jSONException) {}
    dp.a(this.ki, paramJSONObject);
    switch (this.kR) {
      default:
        b(paramJSONObject, new String[0]);
        return;
      case 0:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 1:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 2:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE" });
        return;
      case 3:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 4:
        break;
    } 
    b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE" });
  }
  
  public void clear() {
    this.kQ.clear();
    this.ki.clear();
  }
  
  public void clearImages() {
    this.ki.clear();
  }
  
  public boolean containsKey(String paramString) {
    return this.kQ.containsKey(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (!(paramObject instanceof MediaMetadata))
        return false; 
      paramObject = paramObject;
      if (!a(this.kQ, ((MediaMetadata)paramObject).kQ) || !this.ki.equals(((MediaMetadata)paramObject).ki))
        return false; 
    } 
    return true;
  }
  
  public Calendar getDate(String paramString) {
    a(paramString, 4);
    paramString = this.kQ.getString(paramString);
    return (paramString != null) ? dp.G(paramString) : null;
  }
  
  public String getDateAsString(String paramString) {
    a(paramString, 4);
    return this.kQ.getString(paramString);
  }
  
  public double getDouble(String paramString) {
    a(paramString, 3);
    return this.kQ.getDouble(paramString);
  }
  
  public List<WebImage> getImages() {
    return this.ki;
  }
  
  public int getInt(String paramString) {
    a(paramString, 2);
    return this.kQ.getInt(paramString);
  }
  
  public int getMediaType() {
    return this.kR;
  }
  
  public String getString(String paramString) {
    a(paramString, 1);
    return this.kQ.getString(paramString);
  }
  
  public boolean hasImages() {
    return (this.ki != null && !this.ki.isEmpty());
  }
  
  public int hashCode() {
    Iterator<String> iterator = this.kQ.keySet().iterator();
    int i;
    for (i = 17; iterator.hasNext(); i = this.kQ.get(str).hashCode() + i * 31)
      String str = iterator.next(); 
    return i * 31 + this.ki.hashCode();
  }
  
  public Set<String> keySet() {
    return this.kQ.keySet();
  }
  
  public void putDate(String paramString, Calendar paramCalendar) {
    a(paramString, 4);
    this.kQ.putString(paramString, dp.a(paramCalendar));
  }
  
  public void putDouble(String paramString, double paramDouble) {
    a(paramString, 3);
    this.kQ.putDouble(paramString, paramDouble);
  }
  
  public void putInt(String paramString, int paramInt) {
    a(paramString, 2);
    this.kQ.putInt(paramString, paramInt);
  }
  
  public void putString(String paramString1, String paramString2) {
    a(paramString1, 1);
    this.kQ.putString(paramString1, paramString2);
  }
  
  private static class a {
    private final Map<String, String> kS = new HashMap<String, String>();
    
    private final Map<String, String> kT = new HashMap<String, String>();
    
    private final Map<String, Integer> kU = new HashMap<String, Integer>();
    
    public int A(String param1String) {
      Integer integer = this.kU.get(param1String);
      return (integer != null) ? integer.intValue() : 0;
    }
    
    public a a(String param1String1, String param1String2, int param1Int) {
      this.kS.put(param1String1, param1String2);
      this.kT.put(param1String2, param1String1);
      this.kU.put(param1String1, Integer.valueOf(param1Int));
      return this;
    }
    
    public String y(String param1String) {
      return this.kS.get(param1String);
    }
    
    public String z(String param1String) {
      return this.kT.get(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\cast\MediaMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */