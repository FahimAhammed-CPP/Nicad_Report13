package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.internal.dh;
import com.google.android.gms.internal.ee;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaInfo {
  public static final int STREAM_TYPE_BUFFERED = 1;
  
  public static final int STREAM_TYPE_INVALID = -1;
  
  public static final int STREAM_TYPE_LIVE = 2;
  
  public static final int STREAM_TYPE_NONE = 0;
  
  private final String kH;
  
  private int kI;
  
  private String kJ;
  
  private MediaMetadata kK;
  
  private long kL;
  
  private JSONObject kM;
  
  MediaInfo(String paramString) throws IllegalArgumentException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("content ID cannot be null or empty"); 
    this.kH = paramString;
    this.kI = -1;
  }
  
  MediaInfo(JSONObject paramJSONObject) throws JSONException {
    this.kH = paramJSONObject.getString("contentId");
    String str = paramJSONObject.getString("streamType");
    if ("NONE".equals(str)) {
      this.kI = 0;
    } else if ("BUFFERED".equals(str)) {
      this.kI = 1;
    } else if ("LIVE".equals(str)) {
      this.kI = 2;
    } else {
      this.kI = -1;
    } 
    this.kJ = paramJSONObject.getString("contentType");
    if (paramJSONObject.has("metadata")) {
      JSONObject jSONObject = paramJSONObject.getJSONObject("metadata");
      this.kK = new MediaMetadata(jSONObject.getInt("metadataType"));
      this.kK.b(jSONObject);
    } 
    this.kL = dh.b(paramJSONObject.optDouble("duration", 0.0D));
    this.kM = paramJSONObject.optJSONObject("customData");
  }
  
  void a(MediaMetadata paramMediaMetadata) {
    this.kK = paramMediaMetadata;
  }
  
  void a(JSONObject paramJSONObject) {
    this.kM = paramJSONObject;
  }
  
  void aO() throws IllegalArgumentException {
    if (TextUtils.isEmpty(this.kH))
      throw new IllegalArgumentException("content ID cannot be null or empty"); 
    if (TextUtils.isEmpty(this.kJ))
      throw new IllegalArgumentException("content type cannot be null or empty"); 
    if (this.kI == -1)
      throw new IllegalArgumentException("a valid stream type must be specified"); 
  }
  
  public JSONObject aP() {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc 'contentId'
    //   11: aload_0
    //   12: getfield kH : Ljava/lang/String;
    //   15: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   18: pop
    //   19: aload_0
    //   20: getfield kI : I
    //   23: tableswitch default -> 134, 1 -> 142, 2 -> 125
    //   44: aload_2
    //   45: ldc 'streamType'
    //   47: aload_1
    //   48: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   51: pop
    //   52: aload_0
    //   53: getfield kJ : Ljava/lang/String;
    //   56: ifnull -> 70
    //   59: aload_2
    //   60: ldc 'contentType'
    //   62: aload_0
    //   63: getfield kJ : Ljava/lang/String;
    //   66: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   69: pop
    //   70: aload_0
    //   71: getfield kK : Lcom/google/android/gms/cast/MediaMetadata;
    //   74: ifnull -> 91
    //   77: aload_2
    //   78: ldc 'metadata'
    //   80: aload_0
    //   81: getfield kK : Lcom/google/android/gms/cast/MediaMetadata;
    //   84: invokevirtual aP : ()Lorg/json/JSONObject;
    //   87: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   90: pop
    //   91: aload_2
    //   92: ldc 'duration'
    //   94: aload_0
    //   95: getfield kL : J
    //   98: invokestatic h : (J)D
    //   101: invokevirtual put : (Ljava/lang/String;D)Lorg/json/JSONObject;
    //   104: pop
    //   105: aload_0
    //   106: getfield kM : Lorg/json/JSONObject;
    //   109: ifnull -> 140
    //   112: aload_2
    //   113: ldc 'customData'
    //   115: aload_0
    //   116: getfield kM : Lorg/json/JSONObject;
    //   119: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   122: pop
    //   123: aload_2
    //   124: areturn
    //   125: ldc 'LIVE'
    //   127: astore_1
    //   128: goto -> 44
    //   131: astore_1
    //   132: aload_2
    //   133: areturn
    //   134: ldc 'NONE'
    //   136: astore_1
    //   137: goto -> 44
    //   140: aload_2
    //   141: areturn
    //   142: ldc 'BUFFERED'
    //   144: astore_1
    //   145: goto -> 44
    // Exception table:
    //   from	to	target	type
    //   8	44	131	org/json/JSONException
    //   44	70	131	org/json/JSONException
    //   70	91	131	org/json/JSONException
    //   91	123	131	org/json/JSONException
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: aload_0
    //   7: aload_1
    //   8: if_acmpne -> 17
    //   11: iconst_1
    //   12: istore #4
    //   14: iload #4
    //   16: ireturn
    //   17: iload #6
    //   19: istore #4
    //   21: aload_1
    //   22: instanceof com/google/android/gms/cast/MediaInfo
    //   25: ifeq -> 14
    //   28: aload_1
    //   29: checkcast com/google/android/gms/cast/MediaInfo
    //   32: astore_1
    //   33: aload_0
    //   34: getfield kM : Lorg/json/JSONObject;
    //   37: ifnonnull -> 164
    //   40: iconst_1
    //   41: istore_2
    //   42: aload_1
    //   43: getfield kM : Lorg/json/JSONObject;
    //   46: ifnonnull -> 169
    //   49: iconst_1
    //   50: istore_3
    //   51: iload #6
    //   53: istore #4
    //   55: iload_2
    //   56: iload_3
    //   57: if_icmpne -> 14
    //   60: aload_0
    //   61: getfield kM : Lorg/json/JSONObject;
    //   64: ifnull -> 92
    //   67: aload_1
    //   68: getfield kM : Lorg/json/JSONObject;
    //   71: ifnull -> 92
    //   74: iload #6
    //   76: istore #4
    //   78: aload_0
    //   79: getfield kM : Lorg/json/JSONObject;
    //   82: aload_1
    //   83: getfield kM : Lorg/json/JSONObject;
    //   86: invokestatic d : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   89: ifeq -> 14
    //   92: aload_0
    //   93: getfield kH : Ljava/lang/String;
    //   96: aload_1
    //   97: getfield kH : Ljava/lang/String;
    //   100: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   103: ifeq -> 174
    //   106: aload_0
    //   107: getfield kI : I
    //   110: aload_1
    //   111: getfield kI : I
    //   114: if_icmpne -> 174
    //   117: aload_0
    //   118: getfield kJ : Ljava/lang/String;
    //   121: aload_1
    //   122: getfield kJ : Ljava/lang/String;
    //   125: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   128: ifeq -> 174
    //   131: aload_0
    //   132: getfield kK : Lcom/google/android/gms/cast/MediaMetadata;
    //   135: aload_1
    //   136: getfield kK : Lcom/google/android/gms/cast/MediaMetadata;
    //   139: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   142: ifeq -> 174
    //   145: aload_0
    //   146: getfield kL : J
    //   149: aload_1
    //   150: getfield kL : J
    //   153: lcmp
    //   154: ifne -> 174
    //   157: iload #5
    //   159: istore #4
    //   161: iload #4
    //   163: ireturn
    //   164: iconst_0
    //   165: istore_2
    //   166: goto -> 42
    //   169: iconst_0
    //   170: istore_3
    //   171: goto -> 51
    //   174: iconst_0
    //   175: istore #4
    //   177: goto -> 161
  }
  
  void f(long paramLong) throws IllegalArgumentException {
    if (paramLong < 0L)
      throw new IllegalArgumentException("Stream duration cannot be negative"); 
    this.kL = paramLong;
  }
  
  public String getContentId() {
    return this.kH;
  }
  
  public String getContentType() {
    return this.kJ;
  }
  
  public JSONObject getCustomData() {
    return this.kM;
  }
  
  public MediaMetadata getMetadata() {
    return this.kK;
  }
  
  public long getStreamDuration() {
    return this.kL;
  }
  
  public int getStreamType() {
    return this.kI;
  }
  
  public int hashCode() {
    return ee.hashCode(new Object[] { this.kH, Integer.valueOf(this.kI), this.kJ, this.kK, Long.valueOf(this.kL), String.valueOf(this.kM) });
  }
  
  void setContentType(String paramString) throws IllegalArgumentException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("content type cannot be null or empty"); 
    this.kJ = paramString;
  }
  
  void setStreamType(int paramInt) throws IllegalArgumentException {
    if (paramInt < -1 || paramInt > 2)
      throw new IllegalArgumentException("invalid stream type"); 
    this.kI = paramInt;
  }
  
  public static class Builder {
    private final MediaInfo kN;
    
    public Builder(String param1String) throws IllegalArgumentException {
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("Content ID cannot be empty"); 
      this.kN = new MediaInfo(param1String);
    }
    
    public MediaInfo build() throws IllegalArgumentException {
      this.kN.aO();
      return this.kN;
    }
    
    public Builder setContentType(String param1String) throws IllegalArgumentException {
      this.kN.setContentType(param1String);
      return this;
    }
    
    public Builder setCustomData(JSONObject param1JSONObject) {
      this.kN.a(param1JSONObject);
      return this;
    }
    
    public Builder setMetadata(MediaMetadata param1MediaMetadata) {
      this.kN.a(param1MediaMetadata);
      return this;
    }
    
    public Builder setStreamDuration(long param1Long) throws IllegalArgumentException {
      this.kN.f(param1Long);
      return this;
    }
    
    public Builder setStreamType(int param1Int) throws IllegalArgumentException {
      this.kN.setStreamType(param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\cast\MediaInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */