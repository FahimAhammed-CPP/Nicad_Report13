package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.dh;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CastDevice implements SafeParcelable {
  public static final Parcelable.Creator<CastDevice> CREATOR = new b();
  
  String kA;
  
  private Inet4Address kB;
  
  private String kC;
  
  private String kD;
  
  private String kE;
  
  private int kF;
  
  private List<WebImage> kG;
  
  private final int kg;
  
  private String kz;
  
  private CastDevice() {
    this(1, null, null, null, null, null, -1, new ArrayList<WebImage>());
  }
  
  CastDevice(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt2, List<WebImage> paramList) {
    this.kg = paramInt1;
    this.kz = paramString1;
    this.kA = paramString2;
    if (this.kA != null)
      try {
        InetAddress inetAddress = InetAddress.getByName(this.kA);
        if (inetAddress instanceof Inet4Address)
          this.kB = (Inet4Address)inetAddress; 
      } catch (UnknownHostException unknownHostException) {
        this.kB = null;
      }  
    this.kC = paramString3;
    this.kD = paramString4;
    this.kE = paramString5;
    this.kF = paramInt2;
    this.kG = paramList;
  }
  
  public static CastDevice getFromBundle(Bundle paramBundle) {
    if (paramBundle == null)
      return null; 
    paramBundle.setClassLoader(CastDevice.class.getClassLoader());
    return (CastDevice)paramBundle.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (!(paramObject instanceof CastDevice))
        return false; 
      paramObject = paramObject;
      if (getDeviceId() == null)
        return !(paramObject.getDeviceId() != null); 
      if (!dh.a(this.kz, ((CastDevice)paramObject).kz) || !dh.a(this.kB, ((CastDevice)paramObject).kB) || !dh.a(this.kD, ((CastDevice)paramObject).kD) || !dh.a(this.kC, ((CastDevice)paramObject).kC) || !dh.a(this.kE, ((CastDevice)paramObject).kE) || this.kF != ((CastDevice)paramObject).kF || !dh.a(this.kG, ((CastDevice)paramObject).kG))
        return false; 
    } 
    return true;
  }
  
  public String getDeviceId() {
    return this.kz;
  }
  
  public String getDeviceVersion() {
    return this.kE;
  }
  
  public String getFriendlyName() {
    return this.kC;
  }
  
  public WebImage getIcon(int paramInt1, int paramInt2) {
    WebImage webImage1 = null;
    if (this.kG.isEmpty())
      return null; 
    if (paramInt1 <= 0 || paramInt2 <= 0)
      return this.kG.get(0); 
    Iterator<WebImage> iterator = this.kG.iterator();
    WebImage webImage2 = null;
    while (iterator.hasNext()) {
      WebImage webImage = iterator.next();
      int i = webImage.getWidth();
      int j = webImage.getHeight();
      if (i >= paramInt1 && j >= paramInt2) {
        if (webImage2 == null || (webImage2.getWidth() > i && webImage2.getHeight() > j))
          webImage2 = webImage; 
        continue;
      } 
      if (i < paramInt1 && j < paramInt2 && (webImage1 == null || (webImage1.getWidth() < i && webImage1.getHeight() < j)))
        webImage1 = webImage; 
    } 
    if (webImage2 == null) {
      if (webImage1 != null)
        return webImage1; 
      webImage2 = this.kG.get(0);
    } 
    return webImage2;
  }
  
  public List<WebImage> getIcons() {
    return Collections.unmodifiableList(this.kG);
  }
  
  public Inet4Address getIpAddress() {
    return this.kB;
  }
  
  public String getModelName() {
    return this.kD;
  }
  
  public int getServicePort() {
    return this.kF;
  }
  
  int getVersionCode() {
    return this.kg;
  }
  
  public boolean hasIcons() {
    return !this.kG.isEmpty();
  }
  
  public int hashCode() {
    return (this.kz == null) ? 0 : this.kz.hashCode();
  }
  
  public boolean isSameDevice(CastDevice paramCastDevice) {
    return (paramCastDevice != null) ? ((getDeviceId() == null) ? ((paramCastDevice.getDeviceId() == null)) : dh.a(getDeviceId(), paramCastDevice.getDeviceId())) : false;
  }
  
  public void putInBundle(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    paramBundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", (Parcelable)this);
  }
  
  public String toString() {
    return String.format("\"%s\" (%s)", new Object[] { this.kC, this.kz });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\cast\CastDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */