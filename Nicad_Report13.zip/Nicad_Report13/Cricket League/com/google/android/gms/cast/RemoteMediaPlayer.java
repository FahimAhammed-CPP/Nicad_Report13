package com.google.android.gms.cast;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dg;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.dm;
import com.google.android.gms.internal.dn;
import java.io.IOException;
import org.json.JSONObject;

public class RemoteMediaPlayer implements Cast.MessageReceivedCallback {
  public static final int RESUME_STATE_PAUSE = 2;
  
  public static final int RESUME_STATE_PLAY = 1;
  
  public static final int RESUME_STATE_UNCHANGED = 0;
  
  public static final int STATUS_CANCELED = 2;
  
  public static final int STATUS_FAILED = 1;
  
  public static final int STATUS_REPLACED = 4;
  
  public static final int STATUS_SUCCEEDED = 0;
  
  public static final int STATUS_TIMED_OUT = 3;
  
  private final Object fx = new Object();
  
  private final dl ld = new dl(this) {
      protected void onMetadataUpdated() {
        RemoteMediaPlayer.b(this.lh);
      }
      
      protected void onStatusUpdated() {
        RemoteMediaPlayer.a(this.lh);
      }
    };
  
  private final a le = new a(this);
  
  private OnMetadataUpdatedListener lf;
  
  private OnStatusUpdatedListener lg;
  
  public RemoteMediaPlayer() {
    this.ld.a(this.le);
  }
  
  private void onMetadataUpdated() {
    if (this.lf != null)
      this.lf.onMetadataUpdated(); 
  }
  
  private void onStatusUpdated() {
    if (this.lg != null)
      this.lg.onStatusUpdated(); 
  }
  
  public long getApproximateStreamPosition() {
    synchronized (this.fx) {
      return this.ld.getApproximateStreamPosition();
    } 
  }
  
  public MediaInfo getMediaInfo() {
    synchronized (this.fx) {
      return this.ld.getMediaInfo();
    } 
  }
  
  public MediaStatus getMediaStatus() {
    synchronized (this.fx) {
      return this.ld.getMediaStatus();
    } 
  }
  
  public String getNamespace() {
    return this.ld.getNamespace();
  }
  
  public long getStreamDuration() {
    synchronized (this.fx) {
      return this.ld.getStreamDuration();
    } 
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo) {
    return load(paramGoogleApiClient, paramMediaInfo, true, 0L, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean) {
    return load(paramGoogleApiClient, paramMediaInfo, paramBoolean, 0L, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong) {
    return load(paramGoogleApiClient, paramMediaInfo, paramBoolean, paramLong, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramMediaInfo, paramBoolean, paramLong, paramJSONObject) {
          protected void a(dg param1dg) {
            synchronized (RemoteMediaPlayer.c(this.lh)) {
              RemoteMediaPlayer.d(this.lh).b(this.li);
              try {
                RemoteMediaPlayer.e(this.lh).a(this.lv, this.lj, this.lk, this.ll, this.lm);
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IOException iOException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.lh).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public void onMessageReceived(CastDevice paramCastDevice, String paramString1, String paramString2) {
    this.ld.B(paramString2);
  }
  
  public void pause(GoogleApiClient paramGoogleApiClient) throws IOException {
    pause(paramGoogleApiClient, null);
  }
  
  public void pause(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) throws IOException {
    synchronized (this.fx) {
      this.le.b(paramGoogleApiClient);
      try {
        this.ld.c(paramJSONObject);
        return;
      } finally {
        this.le.b(null);
      } 
    } 
  }
  
  public void play(GoogleApiClient paramGoogleApiClient) throws IOException, IllegalStateException {
    play(paramGoogleApiClient, null);
  }
  
  public void play(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) throws IOException, IllegalStateException {
    synchronized (this.fx) {
      this.le.b(paramGoogleApiClient);
      try {
        this.ld.e(paramJSONObject);
        return;
      } finally {
        this.le.b(null);
      } 
    } 
  }
  
  public PendingResult<MediaChannelResult> requestStatus(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient) {
          protected void a(dg param1dg) {
            synchronized (RemoteMediaPlayer.c(this.lh)) {
              RemoteMediaPlayer.d(this.lh).b(this.li);
              try {
                RemoteMediaPlayer.e(this.lh).a(this.lv);
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IOException iOException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.lh).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong) {
    return seek(paramGoogleApiClient, paramLong, 0, null);
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong, int paramInt) {
    return seek(paramGoogleApiClient, paramLong, paramInt, null);
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong, int paramInt, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramLong, paramInt, paramJSONObject) {
          protected void a(dg param1dg) {
            synchronized (RemoteMediaPlayer.c(this.lh)) {
              RemoteMediaPlayer.d(this.lh).b(this.li);
              try {
                RemoteMediaPlayer.e(this.lh).a(this.lv, this.ln, this.lo, this.lm);
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IOException iOException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.lh).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public void setOnMetadataUpdatedListener(OnMetadataUpdatedListener paramOnMetadataUpdatedListener) {
    this.lf = paramOnMetadataUpdatedListener;
  }
  
  public void setOnStatusUpdatedListener(OnStatusUpdatedListener paramOnStatusUpdatedListener) {
    this.lg = paramOnStatusUpdatedListener;
  }
  
  public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean) {
    return setStreamMute(paramGoogleApiClient, paramBoolean, null);
  }
  
  public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramBoolean, paramJSONObject) {
          protected void a(dg param1dg) {
            synchronized (RemoteMediaPlayer.c(this.lh)) {
              RemoteMediaPlayer.d(this.lh).b(this.li);
              try {
                RemoteMediaPlayer.e(this.lh).a(this.lv, this.lq, this.lm);
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IllegalStateException illegalStateException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IOException iOException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.lh).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient paramGoogleApiClient, double paramDouble) throws IllegalArgumentException {
    return setStreamVolume(paramGoogleApiClient, paramDouble, null);
  }
  
  public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient paramGoogleApiClient, double paramDouble, JSONObject paramJSONObject) throws IllegalArgumentException {
    if (Double.isInfinite(paramDouble) || Double.isNaN(paramDouble))
      throw new IllegalArgumentException("Volume cannot be " + paramDouble); 
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramDouble, paramJSONObject) {
          protected void a(dg param1dg) {
            synchronized (RemoteMediaPlayer.c(this.lh)) {
              RemoteMediaPlayer.d(this.lh).b(this.li);
              try {
                RemoteMediaPlayer.e(this.lh).a(this.lv, this.lp, this.lm);
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IllegalStateException illegalStateException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IllegalArgumentException illegalArgumentException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } catch (IOException iOException) {
                a(k(new Status(1)));
                RemoteMediaPlayer.d(this.lh).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.lh).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public void stop(GoogleApiClient paramGoogleApiClient) throws IOException {
    stop(paramGoogleApiClient, null);
  }
  
  public void stop(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) throws IOException {
    synchronized (this.fx) {
      this.le.b(paramGoogleApiClient);
      try {
        this.ld.d(paramJSONObject);
        return;
      } finally {
        this.le.b(null);
      } 
    } 
  }
  
  public static interface MediaChannelResult extends Result {}
  
  public static interface OnMetadataUpdatedListener {
    void onMetadataUpdated();
  }
  
  public static interface OnStatusUpdatedListener {
    void onStatusUpdated();
  }
  
  private class a implements dm {
    private GoogleApiClient lr;
    
    private long ls = 0L;
    
    public a(RemoteMediaPlayer this$0) {}
    
    public void a(String param1String1, String param1String2, long param1Long, String param1String3) throws IOException {
      if (this.lr == null)
        throw new IOException("No GoogleApiClient available"); 
      Cast.CastApi.sendMessage(this.lr, param1String1, param1String2).setResultCallback(new a(this, param1Long));
    }
    
    public long aR() {
      long l = this.ls + 1L;
      this.ls = l;
      return l;
    }
    
    public void b(GoogleApiClient param1GoogleApiClient) {
      this.lr = param1GoogleApiClient;
    }
    
    private final class a implements ResultCallback<Status> {
      private final long lt;
      
      a(RemoteMediaPlayer.a this$0, long param2Long) {
        this.lt = param2Long;
      }
      
      public void j(Status param2Status) {
        if (!param2Status.isSuccess())
          RemoteMediaPlayer.e(this.lu.lh).a(this.lt, param2Status.getStatusCode()); 
      }
    }
  }
  
  private final class a implements ResultCallback<Status> {
    private final long lt;
    
    a(RemoteMediaPlayer this$0, long param1Long) {
      this.lt = param1Long;
    }
    
    public void j(Status param1Status) {
      if (!param1Status.isSuccess())
        RemoteMediaPlayer.e(this.lu.lh).a(this.lt, param1Status.getStatusCode()); 
    }
  }
  
  private static abstract class b extends Cast.a<MediaChannelResult> {
    dn lv = new dn(this) {
        public void a(long param2Long, int param2Int, JSONObject param2JSONObject) {
          this.lw.a(new RemoteMediaPlayer.c(new Status(param2Int), param2JSONObject));
        }
        
        public void g(long param2Long) {
          this.lw.a(this.lw.k(new Status(4)));
        }
      };
    
    public RemoteMediaPlayer.MediaChannelResult k(Status param1Status) {
      return new RemoteMediaPlayer.MediaChannelResult(this, param1Status) {
          public Status getStatus() {
            return this.jP;
          }
        };
    }
  }
  
  class null implements dn {
    null(RemoteMediaPlayer this$0) {}
    
    public void a(long param1Long, int param1Int, JSONObject param1JSONObject) {
      this.lw.a(new RemoteMediaPlayer.c(new Status(param1Int), param1JSONObject));
    }
    
    public void g(long param1Long) {
      this.lw.a(this.lw.k(new Status(4)));
    }
  }
  
  class null implements MediaChannelResult {
    null(RemoteMediaPlayer this$0, Status param1Status) {}
    
    public Status getStatus() {
      return this.jP;
    }
  }
  
  private static final class c implements MediaChannelResult {
    private final Status jY;
    
    private final JSONObject kM;
    
    c(Status param1Status, JSONObject param1JSONObject) {
      this.jY = param1Status;
      this.kM = param1JSONObject;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\cast\RemoteMediaPlayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */