package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.internal.c;
import java.util.ArrayList;
import java.util.Iterator;

public final class MetadataBuffer extends DataBuffer<Metadata> {
  private static final String[] qS;
  
  private final String qT;
  
  static {
    ArrayList arrayList = new ArrayList();
    Iterator<MetadataField> iterator = c.cW().iterator();
    while (iterator.hasNext())
      arrayList.addAll(((MetadataField)iterator.next()).cV()); 
    qS = (String[])arrayList.toArray((Object[])new String[0]);
  }
  
  public MetadataBuffer(DataHolder paramDataHolder, String paramString) {
    super(paramDataHolder);
    this.qT = paramString;
  }
  
  public Metadata get(int paramInt) {
    return new a(this.nE, paramInt);
  }
  
  public String getNextPageToken() {
    return this.qT;
  }
  
  private static class a extends Metadata {
    private final DataHolder nE;
    
    private final int nH;
    
    private final int qU;
    
    public a(DataHolder param1DataHolder, int param1Int) {
      this.nE = param1DataHolder;
      this.qU = param1Int;
      this.nH = param1DataHolder.C(param1Int);
    }
    
    protected <T> T a(MetadataField<T> param1MetadataField) {
      return (T)param1MetadataField.c(this.nE, this.qU, this.nH);
    }
    
    public Metadata cK() {
      MetadataBundle metadataBundle = MetadataBundle.cX();
      Iterator<MetadataField> iterator = c.cW().iterator();
      while (iterator.hasNext())
        ((MetadataField)iterator.next()).a(this.nE, metadataBundle, this.qU, this.nH); 
      return new b(metadataBundle);
    }
    
    public boolean isDataValid() {
      return !this.nE.isClosed();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\MetadataBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */