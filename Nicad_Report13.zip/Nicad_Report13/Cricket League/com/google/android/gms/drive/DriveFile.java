package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface DriveFile extends DriveResource {
  public static final int MODE_READ_ONLY = 268435456;
  
  public static final int MODE_READ_WRITE = 805306368;
  
  public static final int MODE_WRITE_ONLY = 536870912;
  
  PendingResult<Status> commitAndCloseContents(GoogleApiClient paramGoogleApiClient, Contents paramContents);
  
  PendingResult<Status> discardContents(GoogleApiClient paramGoogleApiClient, Contents paramContents);
  
  PendingResult<DriveApi.ContentsResult> openContents(GoogleApiClient paramGoogleApiClient, int paramInt, DownloadProgressListener paramDownloadProgressListener);
  
  public static interface DownloadProgressListener {
    void onProgress(long param1Long1, long param1Long2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\DriveFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */