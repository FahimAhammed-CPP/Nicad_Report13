package com.google.android.gms.drive.metadata;

import java.util.Collection;

public abstract class OrderedMetadataField<T extends Comparable<T>> extends MetadataField<T> {
  protected OrderedMetadataField(String paramString) {
    super(paramString);
  }
  
  protected OrderedMetadataField(String paramString, Collection<String> paramCollection) {
    super(paramString, paramCollection);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\metadata\OrderedMetadataField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */