package com.google.android.gms.drive.query.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Set;

class d {
  static MetadataField<?> b(MetadataBundle paramMetadataBundle) {
    Set<MetadataField> set = paramMetadataBundle.cY();
    if (set.size() != 1)
      throw new IllegalArgumentException("bundle should have exactly 1 populated field"); 
    return set.iterator().next();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */