package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class u implements Parcelable.Creator<OnListEntriesResponse> {
  static void a(OnListEntriesResponse paramOnListEntriesResponse, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramOnListEntriesResponse.kg);
    b.a(paramParcel, 2, (Parcelable)paramOnListEntriesResponse.rz, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public OnListEntriesResponse J(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    DataHolder dataHolder = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          dataHolder = (DataHolder)a.a(paramParcel, k, (Parcelable.Creator)DataHolder.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnListEntriesResponse(i, dataHolder);
  }
  
  public OnListEntriesResponse[] aj(int paramInt) {
    return new OnListEntriesResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\interna\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */