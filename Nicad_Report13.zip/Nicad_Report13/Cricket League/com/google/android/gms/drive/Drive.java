package com.google.android.gms.drive;

import android.content.Context;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.internal.h;
import com.google.android.gms.drive.internal.j;
import com.google.android.gms.internal.dt;
import java.util.List;

public final class Drive {
  public static final Api API;
  
  public static final DriveApi DriveApi;
  
  public static final Scope SCOPE_FILE;
  
  public static final Api.b<j> jO = new Api.b<j>() {
      public j d(Context param1Context, dt param1dt, GoogleApiClient.ApiOptions param1ApiOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        List list = param1dt.bH();
        return new j(param1Context, param1dt, param1ConnectionCallbacks, param1OnConnectionFailedListener, (String[])list.toArray((Object[])new String[list.size()]));
      }
      
      public int getPriority() {
        return Integer.MAX_VALUE;
      }
    };
  
  static {
    SCOPE_FILE = new Scope("https://www.googleapis.com/auth/drive.file");
    API = new Api(jO, new Scope[0]);
    DriveApi = (DriveApi)new h();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\Drive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */