package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class d implements Parcelable.Creator<MetadataBundle> {
  static void a(MetadataBundle paramMetadataBundle, Parcel paramParcel, int paramInt) {
    paramInt = b.o(paramParcel);
    b.c(paramParcel, 1, paramMetadataBundle.kg);
    b.a(paramParcel, 2, paramMetadataBundle.rF, false);
    b.D(paramParcel, paramInt);
  }
  
  public MetadataBundle P(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    Bundle bundle = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          bundle = a.o(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new MetadataBundle(i, bundle);
  }
  
  public MetadataBundle[] ap(int paramInt) {
    return new MetadataBundle[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\metadata\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */