package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;

public class CloseContentsRequest implements SafeParcelable {
  public static final Parcelable.Creator<CloseContentsRequest> CREATOR = new b();
  
  final int kg;
  
  final Contents qX;
  
  final Boolean qY;
  
  CloseContentsRequest(int paramInt, Contents paramContents, Boolean paramBoolean) {
    this.kg = paramInt;
    this.qX = paramContents;
    this.qY = paramBoolean;
  }
  
  public CloseContentsRequest(Contents paramContents, boolean paramBoolean) {
    this(1, paramContents, Boolean.valueOf(paramBoolean));
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\CloseContentsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */