package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.a;
import com.google.android.gms.drive.Drive;

abstract class i<R extends Result> extends a.a<R, j> {
  public i() {
    super(Drive.jO);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */