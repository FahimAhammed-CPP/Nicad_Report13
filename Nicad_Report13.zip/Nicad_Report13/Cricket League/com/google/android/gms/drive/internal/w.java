package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;

public class w implements Parcelable.Creator<OpenContentsRequest> {
  static void a(OpenContentsRequest paramOpenContentsRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramOpenContentsRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramOpenContentsRequest.rr, paramInt, false);
    b.c(paramParcel, 3, paramOpenContentsRequest.qF);
    b.D(paramParcel, i);
  }
  
  public OpenContentsRequest L(Parcel paramParcel) {
    int i = 0;
    int k = a.n(paramParcel);
    DriveId driveId = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.m(paramParcel);
      switch (a.M(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, m, DriveId.CREATOR);
          break;
        case 3:
          i = a.g(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new OpenContentsRequest(j, driveId, i);
  }
  
  public OpenContentsRequest[] al(int paramInt) {
    return new OpenContentsRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */