package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class e implements Parcelable.Creator<CreateFileRequest> {
  static void a(CreateFileRequest paramCreateFileRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramCreateFileRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramCreateFileRequest.ra, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramCreateFileRequest.qZ, paramInt, false);
    b.a(paramParcel, 4, (Parcelable)paramCreateFileRequest.qX, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public CreateFileRequest D(Parcel paramParcel) {
    MetadataBundle metadataBundle;
    Contents contents = null;
    int j = a.n(paramParcel);
    int i = 0;
    DriveId driveId2 = null;
    DriveId driveId1 = null;
    while (paramParcel.dataPosition() < j) {
      MetadataBundle metadataBundle2;
      DriveId driveId3;
      MetadataBundle metadataBundle1;
      MetadataBundle metadataBundle3;
      DriveId driveId4;
      DriveId driveId6;
      MetadataBundle metadataBundle4;
      DriveId driveId5;
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          driveId6 = driveId1;
          driveId1 = driveId2;
          driveId2 = driveId6;
          driveId6 = driveId2;
          driveId2 = driveId1;
          driveId1 = driveId6;
          break;
        case 2:
          driveId6 = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          driveId1 = driveId2;
          driveId2 = driveId6;
          driveId6 = driveId2;
          driveId2 = driveId1;
          driveId1 = driveId6;
          break;
        case 3:
          metadataBundle4 = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR);
          driveId2 = driveId1;
          metadataBundle2 = metadataBundle4;
          driveId5 = driveId2;
          metadataBundle3 = metadataBundle2;
          driveId3 = driveId5;
          break;
        case 4:
          contents = (Contents)a.a(paramParcel, k, Contents.CREATOR);
          driveId5 = driveId3;
          metadataBundle1 = metadataBundle3;
          driveId4 = driveId5;
          driveId5 = driveId4;
          metadataBundle = metadataBundle1;
          driveId1 = driveId5;
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new CreateFileRequest(i, driveId1, metadataBundle, contents);
  }
  
  public CreateFileRequest[] ad(int paramInt) {
    return new CreateFileRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */