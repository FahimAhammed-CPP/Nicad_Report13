package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.fh;
import com.google.android.gms.internal.fi;
import java.util.Date;

public abstract class Metadata implements Freezable<Metadata> {
  protected abstract <T> T a(MetadataField<T> paramMetadataField);
  
  public Date getCreatedDate() {
    return a((MetadataField<Date>)fi.rL);
  }
  
  public DriveId getDriveId() {
    return a(fh.rG);
  }
  
  public String getMimeType() {
    return a(fh.MIME_TYPE);
  }
  
  public Date getModifiedByMeDate() {
    return a((MetadataField<Date>)fi.rK);
  }
  
  public Date getModifiedDate() {
    return a((MetadataField<Date>)fi.rJ);
  }
  
  public Date getSharedWithMeDate() {
    return a((MetadataField<Date>)fi.rM);
  }
  
  public String getTitle() {
    return a(fh.TITLE);
  }
  
  public boolean isEditable() {
    Boolean bool = a(fh.rH);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public boolean isFolder() {
    return "application/vnd.google-apps.folder".equals(getMimeType());
  }
  
  public boolean isStarred() {
    Boolean bool = a(fh.STARRED);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public boolean isTrashed() {
    Boolean bool = a(fh.TRASHED);
    return (bool == null) ? false : bool.booleanValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\Metadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */