package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;

public class FilterHolder implements SafeParcelable {
  public static final Parcelable.Creator<FilterHolder> CREATOR = new c();
  
  final int kg;
  
  final ComparisonFilter<?> rU;
  
  final FieldOnlyFilter rV;
  
  final LogicalFilter rW;
  
  final NotFilter rX;
  
  final InFilter<?> rY;
  
  private final Filter rZ;
  
  FilterHolder(int paramInt, ComparisonFilter<?> paramComparisonFilter, FieldOnlyFilter paramFieldOnlyFilter, LogicalFilter paramLogicalFilter, NotFilter paramNotFilter, InFilter<?> paramInFilter) {
    this.kg = paramInt;
    this.rU = paramComparisonFilter;
    this.rV = paramFieldOnlyFilter;
    this.rW = paramLogicalFilter;
    this.rX = paramNotFilter;
    this.rY = paramInFilter;
    if (this.rU != null) {
      this.rZ = this.rU;
      return;
    } 
    if (this.rV != null) {
      this.rZ = this.rV;
      return;
    } 
    if (this.rW != null) {
      this.rZ = this.rW;
      return;
    } 
    if (this.rX != null) {
      this.rZ = this.rX;
      return;
    } 
    if (this.rY != null) {
      this.rZ = this.rY;
      return;
    } 
    throw new IllegalArgumentException("At least one filter must be set.");
  }
  
  public FilterHolder(Filter paramFilter) {
    ComparisonFilter comparisonFilter;
    this.kg = 1;
    if (paramFilter instanceof ComparisonFilter) {
      comparisonFilter = (ComparisonFilter)paramFilter;
    } else {
      comparisonFilter = null;
    } 
    this.rU = comparisonFilter;
    if (paramFilter instanceof FieldOnlyFilter) {
      FieldOnlyFilter fieldOnlyFilter = (FieldOnlyFilter)paramFilter;
    } else {
      comparisonFilter = null;
    } 
    this.rV = (FieldOnlyFilter)comparisonFilter;
    if (paramFilter instanceof LogicalFilter) {
      LogicalFilter logicalFilter = (LogicalFilter)paramFilter;
    } else {
      comparisonFilter = null;
    } 
    this.rW = (LogicalFilter)comparisonFilter;
    if (paramFilter instanceof NotFilter) {
      NotFilter notFilter = (NotFilter)paramFilter;
    } else {
      comparisonFilter = null;
    } 
    this.rX = (NotFilter)comparisonFilter;
    if (paramFilter instanceof InFilter) {
      InFilter inFilter = (InFilter)paramFilter;
    } else {
      comparisonFilter = null;
    } 
    this.rY = (InFilter<?>)comparisonFilter;
    if (this.rU == null && this.rV == null && this.rW == null && this.rX == null && this.rY == null)
      throw new IllegalArgumentException("Invalid filter type or null filter."); 
    this.rZ = paramFilter;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\FilterHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */