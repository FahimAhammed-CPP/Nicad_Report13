package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.q;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.iy;
import com.google.android.gms.internal.iz;

public class DriveId implements SafeParcelable {
  public static final Parcelable.Creator<DriveId> CREATOR = new c();
  
  final int kg;
  
  final String qO;
  
  final long qP;
  
  final long qQ;
  
  private volatile String qR;
  
  DriveId(int paramInt, String paramString, long paramLong1, long paramLong2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #8
    //   3: aload_0
    //   4: invokespecial <init> : ()V
    //   7: aload_0
    //   8: aconst_null
    //   9: putfield qR : Ljava/lang/String;
    //   12: aload_0
    //   13: iload_1
    //   14: putfield kg : I
    //   17: aload_0
    //   18: aload_2
    //   19: putfield qO : Ljava/lang/String;
    //   22: ldc ''
    //   24: aload_2
    //   25: invokevirtual equals : (Ljava/lang/Object;)Z
    //   28: ifne -> 75
    //   31: iconst_1
    //   32: istore #7
    //   34: iload #7
    //   36: invokestatic r : (Z)V
    //   39: aload_2
    //   40: ifnonnull -> 55
    //   43: iload #8
    //   45: istore #7
    //   47: lload_3
    //   48: ldc2_w -1
    //   51: lcmp
    //   52: ifeq -> 58
    //   55: iconst_1
    //   56: istore #7
    //   58: iload #7
    //   60: invokestatic r : (Z)V
    //   63: aload_0
    //   64: lload_3
    //   65: putfield qP : J
    //   68: aload_0
    //   69: lload #5
    //   71: putfield qQ : J
    //   74: return
    //   75: iconst_0
    //   76: istore #7
    //   78: goto -> 34
  }
  
  public DriveId(String paramString, long paramLong1, long paramLong2) {
    this(1, paramString, paramLong1, paramLong2);
  }
  
  public static DriveId ab(String paramString) {
    eg.f(paramString);
    return new DriveId(paramString, -1L, -1L);
  }
  
  static DriveId d(byte[] paramArrayOfbyte) {
    q q;
    try {
      q = q.e(paramArrayOfbyte);
      if ("".equals(q.rt)) {
        paramArrayOfbyte = null;
        return new DriveId(q.versionCode, (String)paramArrayOfbyte, q.ru, q.rv);
      } 
    } catch (iy iy) {
      throw new IllegalArgumentException();
    } 
    String str = q.rt;
    return new DriveId(q.versionCode, str, q.ru, q.rv);
  }
  
  public static DriveId decodeFromString(String paramString) {
    eg.b(paramString.startsWith("DriveId:"), "Invalid DriveId: " + paramString);
    return d(Base64.decode(paramString.substring("DriveId:".length()), 10));
  }
  
  final byte[] cL() {
    q q = new q();
    q.versionCode = this.kg;
    if (this.qO == null) {
      String str1 = "";
      q.rt = str1;
      q.ru = this.qP;
      q.rv = this.qQ;
      return iz.a((iz)q);
    } 
    String str = this.qO;
    q.rt = str;
    q.ru = this.qP;
    q.rv = this.qQ;
    return iz.a((iz)q);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final String encodeToString() {
    if (this.qR == null) {
      String str = Base64.encodeToString(cL(), 10);
      this.qR = "DriveId:" + str;
    } 
    return this.qR;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof DriveId) {
      paramObject = paramObject;
      if (((DriveId)paramObject).qQ != this.qQ) {
        Log.w("DriveId", "Attempt to compare invalid DriveId detected. Has local storage been cleared?");
        return false;
      } 
      if (((DriveId)paramObject).qP == -1L && this.qP == -1L)
        return ((DriveId)paramObject).qO.equals(this.qO); 
      if (((DriveId)paramObject).qP == this.qP)
        return true; 
    } 
    return false;
  }
  
  public String getResourceId() {
    return this.qO;
  }
  
  public int hashCode() {
    return (this.qP == -1L) ? this.qO.hashCode() : (String.valueOf(this.qQ) + String.valueOf(this.qP)).hashCode();
  }
  
  public String toString() {
    return encodeToString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\DriveId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */