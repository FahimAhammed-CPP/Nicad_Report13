package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.SearchableField;

public class l extends m implements DriveFolder {
  public l(DriveId paramDriveId) {
    super(paramDriveId);
  }
  
  public PendingResult<DriveFolder.DriveFileResult> createFile(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet, Contents paramContents) {
    if (paramMetadataChangeSet == null)
      throw new IllegalArgumentException("MetatadataChangeSet must be provided."); 
    if (paramContents == null)
      throw new IllegalArgumentException("Contents must be provided."); 
    if ("application/vnd.google-apps.folder".equals(paramMetadataChangeSet.getMimeType()))
      throw new IllegalArgumentException("May not create folders (mimetype: application/vnd.google-apps.folder) using this method. Use DriveFolder.createFolder() instead."); 
    return (PendingResult<DriveFolder.DriveFileResult>)paramGoogleApiClient.b(new i<DriveFolder.DriveFileResult>(this, paramContents, paramMetadataChangeSet) {
          protected void a(j param1j) {
            try {
              this.rd.close();
              param1j.cN().a(new CreateFileRequest(this.rm.getDriveId(), this.rl.cM(), this.rd), new l.a((com.google.android.gms.common.api.a.c<DriveFolder.DriveFileResult>)this));
              return;
            } catch (RemoteException remoteException) {
              a((Result)new l.d(new Status(8, remoteException.getLocalizedMessage(), null), null));
              return;
            } 
          }
          
          public DriveFolder.DriveFileResult q(Status param1Status) {
            return new l.d(param1Status, null);
          }
        });
  }
  
  public PendingResult<DriveFolder.DriveFolderResult> createFolder(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet) {
    if (paramMetadataChangeSet == null)
      throw new IllegalArgumentException("MetatadataChangeSet must be provided."); 
    if (paramMetadataChangeSet.getMimeType() != null && !paramMetadataChangeSet.getMimeType().equals("application/vnd.google-apps.folder"))
      throw new IllegalArgumentException("The mimetype must be of type application/vnd.google-apps.folder"); 
    return (PendingResult<DriveFolder.DriveFolderResult>)paramGoogleApiClient.b(new c(this, paramMetadataChangeSet) {
          protected void a(j param1j) {
            try {
              param1j.cN().a(new CreateFolderRequest(this.rm.getDriveId(), this.rl.cM()), new l.b((com.google.android.gms.common.api.a.c<DriveFolder.DriveFolderResult>)this));
              return;
            } catch (RemoteException remoteException) {
              a((Result)new l.e(new Status(8, remoteException.getLocalizedMessage(), null), null));
              return;
            } 
          }
        });
  }
  
  public PendingResult<DriveApi.MetadataBufferResult> listChildren(GoogleApiClient paramGoogleApiClient) {
    return queryChildren(paramGoogleApiClient, null);
  }
  
  public PendingResult<DriveApi.MetadataBufferResult> queryChildren(GoogleApiClient paramGoogleApiClient, Query paramQuery) {
    Query.Builder builder = (new Query.Builder()).addFilter(Filters.in(SearchableField.PARENTS, getDriveId()));
    if (paramQuery != null) {
      if (paramQuery.getFilter() != null)
        builder.addFilter(paramQuery.getFilter()); 
      builder.setPageToken(paramQuery.getPageToken());
    } 
    return (new h()).query(paramGoogleApiClient, builder.build());
  }
  
  private static class a extends a {
    private final com.google.android.gms.common.api.a.c<DriveFolder.DriveFileResult> jW;
    
    public a(com.google.android.gms.common.api.a.c<DriveFolder.DriveFileResult> param1c) {
      this.jW = param1c;
    }
    
    public void a(OnDriveIdResponse param1OnDriveIdResponse) throws RemoteException {
      this.jW.a(new l.d(Status.nA, new k(param1OnDriveIdResponse.getDriveId())));
    }
    
    public void m(Status param1Status) throws RemoteException {
      this.jW.a(new l.d(param1Status, null));
    }
  }
  
  private static class b extends a {
    private final com.google.android.gms.common.api.a.c<DriveFolder.DriveFolderResult> jW;
    
    public b(com.google.android.gms.common.api.a.c<DriveFolder.DriveFolderResult> param1c) {
      this.jW = param1c;
    }
    
    public void a(OnDriveIdResponse param1OnDriveIdResponse) throws RemoteException {
      this.jW.a(new l.e(Status.nA, new l(param1OnDriveIdResponse.getDriveId())));
    }
    
    public void m(Status param1Status) throws RemoteException {
      this.jW.a(new l.e(param1Status, null));
    }
  }
  
  private abstract class c extends i<DriveFolder.DriveFolderResult> {
    private c(l this$0) {}
    
    public DriveFolder.DriveFolderResult r(Status param1Status) {
      return new l.e(param1Status, null);
    }
  }
  
  private static class d implements DriveFolder.DriveFileResult {
    private final Status jY;
    
    private final DriveFile rn;
    
    public d(Status param1Status, DriveFile param1DriveFile) {
      this.jY = param1Status;
      this.rn = param1DriveFile;
    }
    
    public DriveFile getDriveFile() {
      return this.rn;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
  
  private static class e implements DriveFolder.DriveFolderResult {
    private final Status jY;
    
    private final DriveFolder ro;
    
    public e(Status param1Status, DriveFolder param1DriveFolder) {
      this.jY = param1Status;
      this.ro = param1DriveFolder;
    }
    
    public DriveFolder getDriveFolder() {
      return this.ro;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */