package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class a implements Parcelable.Creator<ComparisonFilter> {
  static void a(ComparisonFilter paramComparisonFilter, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1000, paramComparisonFilter.kg);
    b.a(paramParcel, 1, (Parcelable)paramComparisonFilter.rR, paramInt, false);
    b.a(paramParcel, 2, (Parcelable)paramComparisonFilter.rS, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public ComparisonFilter R(Parcel paramParcel) {
    MetadataBundle metadataBundle = null;
    int j = com.google.android.gms.common.internal.safeparcel.a.n(paramParcel);
    int i = 0;
    Operator operator = null;
    while (paramParcel.dataPosition() < j) {
      int k = com.google.android.gms.common.internal.safeparcel.a.m(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.M(k)) {
        default:
          com.google.android.gms.common.internal.safeparcel.a.b(paramParcel, k);
          continue;
        case 1000:
          i = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, k);
          continue;
        case 1:
          operator = (Operator)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, Operator.CREATOR);
          continue;
        case 2:
          break;
      } 
      metadataBundle = (MetadataBundle)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, k, MetadataBundle.CREATOR);
    } 
    if (paramParcel.dataPosition() != j)
      throw new com.google.android.gms.common.internal.safeparcel.a.a("Overread allowed size end=" + j, paramParcel); 
    return new ComparisonFilter(i, operator, metadataBundle);
  }
  
  public ComparisonFilter[] ar(int paramInt) {
    return new ComparisonFilter[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */