package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface o extends IInterface {
  IntentSender a(CreateFileIntentSenderRequest paramCreateFileIntentSenderRequest) throws RemoteException;
  
  IntentSender a(OpenFileIntentSenderRequest paramOpenFileIntentSenderRequest) throws RemoteException;
  
  void a(CloseContentsRequest paramCloseContentsRequest, p paramp) throws RemoteException;
  
  void a(CreateContentsRequest paramCreateContentsRequest, p paramp) throws RemoteException;
  
  void a(CreateFileRequest paramCreateFileRequest, p paramp) throws RemoteException;
  
  void a(CreateFolderRequest paramCreateFolderRequest, p paramp) throws RemoteException;
  
  void a(GetMetadataRequest paramGetMetadataRequest, p paramp) throws RemoteException;
  
  void a(OpenContentsRequest paramOpenContentsRequest, p paramp) throws RemoteException;
  
  void a(QueryRequest paramQueryRequest, p paramp) throws RemoteException;
  
  void a(UpdateMetadataRequest paramUpdateMetadataRequest, p paramp) throws RemoteException;
  
  void a(p paramp) throws RemoteException;
  
  public static abstract class a extends Binder implements o {
    public static o C(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IDriveService");
      return (iInterface != null && iInterface instanceof o) ? (o)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      QueryRequest queryRequest1;
      UpdateMetadataRequest updateMetadataRequest1;
      CreateContentsRequest createContentsRequest1;
      CreateFileRequest createFileRequest1;
      CreateFolderRequest createFolderRequest1;
      OpenContentsRequest openContentsRequest1;
      CloseContentsRequest closeContentsRequest1;
      CreateFileIntentSenderRequest createFileIntentSenderRequest;
      GetMetadataRequest getMetadataRequest2 = null;
      QueryRequest queryRequest2 = null;
      UpdateMetadataRequest updateMetadataRequest2 = null;
      CreateContentsRequest createContentsRequest2 = null;
      CreateFileRequest createFileRequest2 = null;
      CreateFolderRequest createFolderRequest2 = null;
      OpenContentsRequest openContentsRequest2 = null;
      CloseContentsRequest closeContentsRequest2 = null;
      OpenFileIntentSenderRequest openFileIntentSenderRequest2 = null;
      GetMetadataRequest getMetadataRequest1 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IDriveService");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          if (param1Parcel1.readInt() != 0)
            getMetadataRequest1 = (GetMetadataRequest)GetMetadataRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(getMetadataRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          getMetadataRequest1 = getMetadataRequest2;
          if (param1Parcel1.readInt() != 0)
            queryRequest1 = (QueryRequest)QueryRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(queryRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          queryRequest1 = queryRequest2;
          if (param1Parcel1.readInt() != 0)
            updateMetadataRequest1 = (UpdateMetadataRequest)UpdateMetadataRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(updateMetadataRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          updateMetadataRequest1 = updateMetadataRequest2;
          if (param1Parcel1.readInt() != 0)
            createContentsRequest1 = (CreateContentsRequest)CreateContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createContentsRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createContentsRequest1 = createContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            createFileRequest1 = (CreateFileRequest)CreateFileRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createFileRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createFileRequest1 = createFileRequest2;
          if (param1Parcel1.readInt() != 0)
            createFolderRequest1 = (CreateFolderRequest)CreateFolderRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createFolderRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 7:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createFolderRequest1 = createFolderRequest2;
          if (param1Parcel1.readInt() != 0)
            openContentsRequest1 = (OpenContentsRequest)OpenContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(openContentsRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 8:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          openContentsRequest1 = openContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            closeContentsRequest1 = (CloseContentsRequest)CloseContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(closeContentsRequest1, p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 9:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          a(p.a.D(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 10:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          closeContentsRequest1 = closeContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            openFileIntentSenderRequest1 = (OpenFileIntentSenderRequest)OpenFileIntentSenderRequest.CREATOR.createFromParcel(param1Parcel1); 
          intentSender = a(openFileIntentSenderRequest1);
          param1Parcel2.writeNoException();
          if (intentSender != null) {
            param1Parcel2.writeInt(1);
            intentSender.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        case 11:
          break;
      } 
      intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
      OpenFileIntentSenderRequest openFileIntentSenderRequest1 = openFileIntentSenderRequest2;
      if (intentSender.readInt() != 0)
        createFileIntentSenderRequest = (CreateFileIntentSenderRequest)CreateFileIntentSenderRequest.CREATOR.createFromParcel((Parcel)intentSender); 
      IntentSender intentSender = a(createFileIntentSenderRequest);
      param1Parcel2.writeNoException();
      if (intentSender != null) {
        param1Parcel2.writeInt(1);
        intentSender.writeToParcel(param1Parcel2, 1);
        return true;
      } 
      param1Parcel2.writeInt(0);
      return true;
    }
    
    private static class a implements o {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public IntentSender a(CreateFileIntentSenderRequest param2CreateFileIntentSenderRequest) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFileIntentSenderRequest != null) {
            parcel1.writeInt(1);
            param2CreateFileIntentSenderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(11, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2CreateFileIntentSenderRequest = null;
        parcel2.recycle();
        parcel1.recycle();
        return (IntentSender)param2CreateFileIntentSenderRequest;
      }
      
      public IntentSender a(OpenFileIntentSenderRequest param2OpenFileIntentSenderRequest) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2OpenFileIntentSenderRequest != null) {
            parcel1.writeInt(1);
            param2OpenFileIntentSenderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(10, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2OpenFileIntentSenderRequest = null;
        parcel2.recycle();
        parcel1.recycle();
        return (IntentSender)param2OpenFileIntentSenderRequest;
      }
      
      public void a(CloseContentsRequest param2CloseContentsRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CloseContentsRequest != null) {
            parcel1.writeInt(1);
            param2CloseContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2CloseContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CloseContentsRequest);
          this.dU.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateContentsRequest param2CreateContentsRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateContentsRequest != null) {
            parcel1.writeInt(1);
            param2CreateContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2CreateContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateContentsRequest);
          this.dU.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateFileRequest param2CreateFileRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFileRequest != null) {
            parcel1.writeInt(1);
            param2CreateFileRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2CreateFileRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateFileRequest);
          this.dU.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateFolderRequest param2CreateFolderRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFolderRequest != null) {
            parcel1.writeInt(1);
            param2CreateFolderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2CreateFolderRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateFolderRequest);
          this.dU.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(GetMetadataRequest param2GetMetadataRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2GetMetadataRequest != null) {
            parcel1.writeInt(1);
            param2GetMetadataRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2GetMetadataRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2GetMetadataRequest);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OpenContentsRequest param2OpenContentsRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2OpenContentsRequest != null) {
            parcel1.writeInt(1);
            param2OpenContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2OpenContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2OpenContentsRequest);
          this.dU.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(QueryRequest param2QueryRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2QueryRequest != null) {
            parcel1.writeInt(1);
            param2QueryRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2QueryRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2QueryRequest);
          this.dU.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(UpdateMetadataRequest param2UpdateMetadataRequest, p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2UpdateMetadataRequest != null) {
            parcel1.writeInt(1);
            param2UpdateMetadataRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2UpdateMetadataRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2UpdateMetadataRequest);
          this.dU.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(p param2p) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2p != null) {
            IBinder iBinder = param2p.asBinder();
          } else {
            param2p = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2p);
          this.dU.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
    }
  }
  
  private static class a implements o {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public IntentSender a(CreateFileIntentSenderRequest param1CreateFileIntentSenderRequest) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFileIntentSenderRequest != null) {
          parcel1.writeInt(1);
          param1CreateFileIntentSenderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(11, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1CreateFileIntentSenderRequest = null;
      parcel2.recycle();
      parcel1.recycle();
      return (IntentSender)param1CreateFileIntentSenderRequest;
    }
    
    public IntentSender a(OpenFileIntentSenderRequest param1OpenFileIntentSenderRequest) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1OpenFileIntentSenderRequest != null) {
          parcel1.writeInt(1);
          param1OpenFileIntentSenderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(10, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1OpenFileIntentSenderRequest = null;
      parcel2.recycle();
      parcel1.recycle();
      return (IntentSender)param1OpenFileIntentSenderRequest;
    }
    
    public void a(CloseContentsRequest param1CloseContentsRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CloseContentsRequest != null) {
          parcel1.writeInt(1);
          param1CloseContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1CloseContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CloseContentsRequest);
        this.dU.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateContentsRequest param1CreateContentsRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateContentsRequest != null) {
          parcel1.writeInt(1);
          param1CreateContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1CreateContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateContentsRequest);
        this.dU.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateFileRequest param1CreateFileRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFileRequest != null) {
          parcel1.writeInt(1);
          param1CreateFileRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1CreateFileRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateFileRequest);
        this.dU.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateFolderRequest param1CreateFolderRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFolderRequest != null) {
          parcel1.writeInt(1);
          param1CreateFolderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1CreateFolderRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateFolderRequest);
        this.dU.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(GetMetadataRequest param1GetMetadataRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1GetMetadataRequest != null) {
          parcel1.writeInt(1);
          param1GetMetadataRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1GetMetadataRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1GetMetadataRequest);
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OpenContentsRequest param1OpenContentsRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1OpenContentsRequest != null) {
          parcel1.writeInt(1);
          param1OpenContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1OpenContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1OpenContentsRequest);
        this.dU.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(QueryRequest param1QueryRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1QueryRequest != null) {
          parcel1.writeInt(1);
          param1QueryRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1QueryRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1QueryRequest);
        this.dU.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(UpdateMetadataRequest param1UpdateMetadataRequest, p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1UpdateMetadataRequest != null) {
          parcel1.writeInt(1);
          param1UpdateMetadataRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1UpdateMetadataRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1UpdateMetadataRequest);
        this.dU.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(p param1p) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1p != null) {
          IBinder iBinder = param1p.asBinder();
        } else {
          param1p = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1p);
        this.dU.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */