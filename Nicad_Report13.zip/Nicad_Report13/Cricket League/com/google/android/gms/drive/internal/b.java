package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.drive.Contents;

public class b implements Parcelable.Creator<CloseContentsRequest> {
  static void a(CloseContentsRequest paramCloseContentsRequest, Parcel paramParcel, int paramInt) {
    int i = com.google.android.gms.common.internal.safeparcel.b.o(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramCloseContentsRequest.kg);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, (Parcelable)paramCloseContentsRequest.qX, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramCloseContentsRequest.qY, false);
    com.google.android.gms.common.internal.safeparcel.b.D(paramParcel, i);
  }
  
  public CloseContentsRequest A(Parcel paramParcel) {
    Boolean bool = null;
    int j = a.n(paramParcel);
    int i = 0;
    Contents contents = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          contents = (Contents)a.a(paramParcel, k, Contents.CREATOR);
          break;
        case 3:
          bool = a.d(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new CloseContentsRequest(i, contents, bool);
  }
  
  public CloseContentsRequest[] aa(int paramInt) {
    return new CloseContentsRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */