package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class c implements Parcelable.Creator<FilterHolder> {
  static void a(FilterHolder paramFilterHolder, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.a(paramParcel, 1, (Parcelable)paramFilterHolder.rU, paramInt, false);
    b.c(paramParcel, 1000, paramFilterHolder.kg);
    b.a(paramParcel, 2, (Parcelable)paramFilterHolder.rV, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramFilterHolder.rW, paramInt, false);
    b.a(paramParcel, 4, (Parcelable)paramFilterHolder.rX, paramInt, false);
    b.a(paramParcel, 5, (Parcelable)paramFilterHolder.rY, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public FilterHolder T(Parcel paramParcel) {
    InFilter<?> inFilter = null;
    int j = a.n(paramParcel);
    int i = 0;
    NotFilter notFilter = null;
    LogicalFilter logicalFilter = null;
    FieldOnlyFilter fieldOnlyFilter = null;
    ComparisonFilter<?> comparisonFilter = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        default:
          a.b(paramParcel, k);
          continue;
        case 1:
          comparisonFilter = (ComparisonFilter)a.a(paramParcel, k, ComparisonFilter.CREATOR);
          continue;
        case 1000:
          i = a.g(paramParcel, k);
          continue;
        case 2:
          fieldOnlyFilter = (FieldOnlyFilter)a.a(paramParcel, k, FieldOnlyFilter.CREATOR);
          continue;
        case 3:
          logicalFilter = (LogicalFilter)a.a(paramParcel, k, LogicalFilter.CREATOR);
          continue;
        case 4:
          notFilter = (NotFilter)a.a(paramParcel, k, NotFilter.CREATOR);
          continue;
        case 5:
          break;
      } 
      inFilter = (InFilter)a.a(paramParcel, k, InFilter.CREATOR);
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new FilterHolder(i, comparisonFilter, fieldOnlyFilter, logicalFilter, notFilter, inFilter);
  }
  
  public FilterHolder[] at(int paramInt) {
    return new FilterHolder[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\query\internal\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */