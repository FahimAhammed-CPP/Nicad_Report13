package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class CreateContentsRequest implements SafeParcelable {
  public static final Parcelable.Creator<CreateContentsRequest> CREATOR = new c();
  
  final int kg;
  
  public CreateContentsRequest() {
    this(1);
  }
  
  CreateContentsRequest(int paramInt) {
    this.kg = paramInt;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\CreateContentsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */