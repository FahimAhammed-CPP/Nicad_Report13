package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResource;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataChangeSet;

public class m implements DriveResource {
  private final DriveId qG;
  
  public m(DriveId paramDriveId) {
    this.qG = paramDriveId;
  }
  
  public DriveId getDriveId() {
    return this.qG;
  }
  
  public PendingResult<DriveResource.MetadataResult> getMetadata(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<DriveResource.MetadataResult>)paramGoogleApiClient.a(new a(this) {
          protected void a(j param1j) {
            try {
              param1j.cN().a(new GetMetadataRequest(m.a(this.rp)), new m.b((com.google.android.gms.common.api.a.c<DriveResource.MetadataResult>)this));
              return;
            } catch (RemoteException remoteException) {
              a((Result)new m.c(new Status(8, remoteException.getLocalizedMessage(), null), null));
              return;
            } 
          }
        });
  }
  
  public PendingResult<DriveResource.MetadataResult> updateMetadata(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet) {
    if (paramMetadataChangeSet == null)
      throw new IllegalArgumentException("ChangeSet must be provided."); 
    return (PendingResult<DriveResource.MetadataResult>)paramGoogleApiClient.b(new d(this, paramMetadataChangeSet) {
          protected void a(j param1j) {
            try {
              param1j.cN().a(new UpdateMetadataRequest(m.a(this.rp), this.rl.cM()), new m.b((com.google.android.gms.common.api.a.c<DriveResource.MetadataResult>)this));
              return;
            } catch (RemoteException remoteException) {
              a((Result)new m.c(new Status(8, remoteException.getLocalizedMessage(), null), null));
              return;
            } 
          }
        });
  }
  
  private abstract class a extends i<DriveResource.MetadataResult> {
    private a(m this$0) {}
    
    public DriveResource.MetadataResult s(Status param1Status) {
      return new m.c(param1Status, null);
    }
  }
  
  private static class b extends a {
    private final com.google.android.gms.common.api.a.c<DriveResource.MetadataResult> jW;
    
    public b(com.google.android.gms.common.api.a.c<DriveResource.MetadataResult> param1c) {
      this.jW = param1c;
    }
    
    public void a(OnMetadataResponse param1OnMetadataResponse) throws RemoteException {
      this.jW.a(new m.c(Status.nA, new g(param1OnMetadataResponse.cU())));
    }
    
    public void m(Status param1Status) throws RemoteException {
      this.jW.a(new m.c(param1Status, null));
    }
  }
  
  private static class c implements DriveResource.MetadataResult {
    private final Status jY;
    
    private final Metadata rq;
    
    public c(Status param1Status, Metadata param1Metadata) {
      this.jY = param1Status;
      this.rq = param1Metadata;
    }
    
    public Metadata getMetadata() {
      return this.rq;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
  
  private abstract class d extends i<DriveResource.MetadataResult> {
    private d(m this$0) {}
    
    public DriveResource.MetadataResult s(Status param1Status) {
      return new m.c(param1Status, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */