package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class s implements Parcelable.Creator<OnDownloadProgressResponse> {
  static void a(OnDownloadProgressResponse paramOnDownloadProgressResponse, Parcel paramParcel, int paramInt) {
    paramInt = b.o(paramParcel);
    b.c(paramParcel, 1, paramOnDownloadProgressResponse.kg);
    b.a(paramParcel, 2, paramOnDownloadProgressResponse.rx);
    b.a(paramParcel, 3, paramOnDownloadProgressResponse.ry);
    b.D(paramParcel, paramInt);
  }
  
  public OnDownloadProgressResponse H(Parcel paramParcel) {
    long l1 = 0L;
    int j = a.n(paramParcel);
    int i = 0;
    long l2 = 0L;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          l2 = a.h(paramParcel, k);
          break;
        case 3:
          l1 = a.h(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnDownloadProgressResponse(i, l2, l1);
  }
  
  public OnDownloadProgressResponse[] ah(int paramInt) {
    return new OnDownloadProgressResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */