package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;

public class n implements Parcelable.Creator<GetMetadataRequest> {
  static void a(GetMetadataRequest paramGetMetadataRequest, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, paramGetMetadataRequest.kg);
    b.a(paramParcel, 2, (Parcelable)paramGetMetadataRequest.rr, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public GetMetadataRequest F(Parcel paramParcel) {
    int j = a.n(paramParcel);
    int i = 0;
    DriveId driveId = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.m(paramParcel);
      switch (a.M(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new GetMetadataRequest(i, driveId);
  }
  
  public GetMetadataRequest[] af(int paramInt) {
    return new GetMetadataRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\drive\internal\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */