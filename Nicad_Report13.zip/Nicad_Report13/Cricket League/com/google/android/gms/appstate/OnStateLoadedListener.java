package com.google.android.gms.appstate;

@Deprecated
public interface OnStateLoadedListener {
  void onStateConflict(int paramInt, String paramString, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  void onStateLoaded(int paramInt1, int paramInt2, byte[] paramArrayOfbyte);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\appstate\OnStateLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */