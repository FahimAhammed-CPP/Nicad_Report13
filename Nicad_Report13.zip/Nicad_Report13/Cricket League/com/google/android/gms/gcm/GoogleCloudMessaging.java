package com.google.android.gms.gcm;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class GoogleCloudMessaging {
  public static final String ERROR_MAIN_THREAD = "MAIN_THREAD";
  
  public static final String ERROR_SERVICE_NOT_AVAILABLE = "SERVICE_NOT_AVAILABLE";
  
  public static final String MESSAGE_TYPE_DELETED = "deleted_messages";
  
  public static final String MESSAGE_TYPE_MESSAGE = "gcm";
  
  public static final String MESSAGE_TYPE_SEND_ERROR = "send_error";
  
  static GoogleCloudMessaging xf;
  
  private Context eh;
  
  private PendingIntent xg;
  
  final BlockingQueue<Intent> xh = new LinkedBlockingQueue<Intent>();
  
  private Handler xi = new Handler(this, Looper.getMainLooper()) {
      public void handleMessage(Message param1Message) {
        Intent intent = (Intent)param1Message.obj;
        this.xk.xh.add(intent);
      }
    };
  
  private Messenger xj = new Messenger(this.xi);
  
  private void b(String... paramVarArgs) {
    String str = c(paramVarArgs);
    Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
    intent.setPackage("com.google.android.gms");
    intent.putExtra("google.messenger", (Parcelable)this.xj);
    c(intent);
    intent.putExtra("sender", str);
    this.eh.startService(intent);
  }
  
  private void dz() {
    Intent intent = new Intent("com.google.android.c2dm.intent.UNREGISTER");
    intent.setPackage("com.google.android.gms");
    this.xh.clear();
    intent.putExtra("google.messenger", (Parcelable)this.xj);
    c(intent);
    this.eh.startService(intent);
  }
  
  public static GoogleCloudMessaging getInstance(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/android/gms/gcm/GoogleCloudMessaging
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/gcm/GoogleCloudMessaging.xf : Lcom/google/android/gms/gcm/GoogleCloudMessaging;
    //   6: ifnonnull -> 26
    //   9: new com/google/android/gms/gcm/GoogleCloudMessaging
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putstatic com/google/android/gms/gcm/GoogleCloudMessaging.xf : Lcom/google/android/gms/gcm/GoogleCloudMessaging;
    //   19: getstatic com/google/android/gms/gcm/GoogleCloudMessaging.xf : Lcom/google/android/gms/gcm/GoogleCloudMessaging;
    //   22: aload_0
    //   23: putfield eh : Landroid/content/Context;
    //   26: getstatic com/google/android/gms/gcm/GoogleCloudMessaging.xf : Lcom/google/android/gms/gcm/GoogleCloudMessaging;
    //   29: astore_0
    //   30: ldc com/google/android/gms/gcm/GoogleCloudMessaging
    //   32: monitorexit
    //   33: aload_0
    //   34: areturn
    //   35: astore_0
    //   36: ldc com/google/android/gms/gcm/GoogleCloudMessaging
    //   38: monitorexit
    //   39: aload_0
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   3	26	35	finally
    //   26	30	35	finally
  }
  
  String c(String... paramVarArgs) {
    if (paramVarArgs == null || paramVarArgs.length == 0)
      throw new IllegalArgumentException("No senderIds"); 
    StringBuilder stringBuilder = new StringBuilder(paramVarArgs[0]);
    for (int i = 1; i < paramVarArgs.length; i++)
      stringBuilder.append(',').append(paramVarArgs[i]); 
    return stringBuilder.toString();
  }
  
  void c(Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield xg : Landroid/app/PendingIntent;
    //   6: ifnonnull -> 29
    //   9: aload_0
    //   10: aload_0
    //   11: getfield eh : Landroid/content/Context;
    //   14: iconst_0
    //   15: new android/content/Intent
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: iconst_0
    //   23: invokestatic getBroadcast : (Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   26: putfield xg : Landroid/app/PendingIntent;
    //   29: aload_1
    //   30: ldc 'app'
    //   32: aload_0
    //   33: getfield xg : Landroid/app/PendingIntent;
    //   36: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   39: pop
    //   40: aload_0
    //   41: monitorexit
    //   42: return
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	29	43	finally
    //   29	40	43	finally
  }
  
  public void close() {
    dA();
  }
  
  void dA() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield xg : Landroid/app/PendingIntent;
    //   6: ifnull -> 21
    //   9: aload_0
    //   10: getfield xg : Landroid/app/PendingIntent;
    //   13: invokevirtual cancel : ()V
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield xg : Landroid/app/PendingIntent;
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	24	finally
  }
  
  public String getMessageType(Intent paramIntent) {
    if (!"com.google.android.c2dm.intent.RECEIVE".equals(paramIntent.getAction()))
      return null; 
    String str2 = paramIntent.getStringExtra("message_type");
    String str1 = str2;
    return (str2 == null) ? "gcm" : str1;
  }
  
  public String register(String... paramVarArgs) throws IOException {
    if (Looper.getMainLooper() == Looper.myLooper())
      throw new IOException("MAIN_THREAD"); 
    this.xh.clear();
    b(paramVarArgs);
    try {
      Intent intent = this.xh.poll(5000L, TimeUnit.MILLISECONDS);
      if (intent == null)
        throw new IOException("SERVICE_NOT_AVAILABLE"); 
    } catch (InterruptedException interruptedException) {
      throw new IOException(interruptedException.getMessage());
    } 
    String str2 = interruptedException.getStringExtra("registration_id");
    if (str2 != null)
      return str2; 
    interruptedException.getStringExtra("error");
    String str1 = interruptedException.getStringExtra("error");
    if (str1 != null)
      throw new IOException(str1); 
    throw new IOException("SERVICE_NOT_AVAILABLE");
  }
  
  public void send(String paramString1, String paramString2, long paramLong, Bundle paramBundle) throws IOException {
    if (Looper.getMainLooper() == Looper.myLooper())
      throw new IOException("MAIN_THREAD"); 
    if (paramString1 == null)
      throw new IllegalArgumentException("Missing 'to'"); 
    Intent intent = new Intent("com.google.android.gcm.intent.SEND");
    intent.putExtras(paramBundle);
    c(intent);
    intent.putExtra("google.to", paramString1);
    intent.putExtra("google.message_id", paramString2);
    intent.putExtra("google.ttl", Long.toString(paramLong));
    this.eh.sendOrderedBroadcast(intent, null);
  }
  
  public void send(String paramString1, String paramString2, Bundle paramBundle) throws IOException {
    send(paramString1, paramString2, -1L, paramBundle);
  }
  
  public void unregister() throws IOException {
    if (Looper.getMainLooper() == Looper.myLooper())
      throw new IOException("MAIN_THREAD"); 
    dz();
    try {
      Intent intent = this.xh.poll(5000L, TimeUnit.MILLISECONDS);
      if (intent == null)
        throw new IOException("SERVICE_NOT_AVAILABLE"); 
    } catch (InterruptedException interruptedException) {
      throw new IOException(interruptedException.getMessage());
    } 
    if (interruptedException.getStringExtra("unregistered") != null)
      return; 
    String str = interruptedException.getStringExtra("error");
    if (str != null)
      throw new IOException(str); 
    throw new IOException("SERVICE_NOT_AVAILABLE");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\gcm\GoogleCloudMessaging.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */