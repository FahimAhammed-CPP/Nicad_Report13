package com.google.android.gms.common.images;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.internal.dq;
import com.google.android.gms.internal.dr;
import com.google.android.gms.internal.ds;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.fg;
import java.lang.ref.WeakReference;

public final class a {
  final a op = new a(null);
  
  private int oq = 0;
  
  private int or = 0;
  
  int os;
  
  private int ot;
  
  private WeakReference<ImageManager.OnImageLoadedListener> ou;
  
  private WeakReference<ImageView> ov;
  
  private WeakReference<TextView> ow;
  
  private int ox = -1;
  
  private boolean oy = true;
  
  private boolean oz = false;
  
  public a(int paramInt) {
    this.or = paramInt;
  }
  
  public a(Uri paramUri) {
    this.or = 0;
  }
  
  private dq a(Drawable paramDrawable1, Drawable paramDrawable2) {
    if (paramDrawable1 != null) {
      Drawable drawable1 = paramDrawable1;
      if (paramDrawable1 instanceof dq)
        drawable1 = ((dq)paramDrawable1).bC(); 
      return new dq(drawable1, paramDrawable2);
    } 
    Drawable drawable = null;
    return new dq(drawable, paramDrawable2);
  }
  
  private void a(Drawable paramDrawable, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    ImageView imageView;
    switch (this.os) {
      default:
        return;
      case 1:
        if (!paramBoolean2) {
          ImageManager.OnImageLoadedListener onImageLoadedListener = this.ou.get();
          if (onImageLoadedListener != null) {
            onImageLoadedListener.onImageLoaded(this.op.uri, paramDrawable, paramBoolean3);
            return;
          } 
        } 
      case 2:
        imageView = this.ov.get();
        if (imageView != null) {
          a(imageView, paramDrawable, paramBoolean1, paramBoolean2, paramBoolean3);
          return;
        } 
      case 3:
        break;
    } 
    TextView textView = this.ow.get();
    if (textView != null) {
      a(textView, this.ox, paramDrawable, paramBoolean1, paramBoolean2);
      return;
    } 
  }
  
  private void a(ImageView paramImageView, Drawable paramDrawable, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    dq dq;
    int i;
    if (!paramBoolean2 && !paramBoolean3) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && paramImageView instanceof dr) {
      int j = ((dr)paramImageView).bE();
      if (this.or != 0 && j == this.or)
        return; 
    } 
    paramBoolean1 = a(paramBoolean1, paramBoolean2);
    if (paramBoolean1)
      dq = a(paramImageView.getDrawable(), paramDrawable); 
    paramImageView.setImageDrawable((Drawable)dq);
    if (paramImageView instanceof dr) {
      dr dr = (dr)paramImageView;
      if (paramBoolean3) {
        Uri uri = this.op.uri;
      } else {
        paramImageView = null;
      } 
      dr.d((Uri)paramImageView);
      if (i) {
        i = this.or;
      } else {
        i = 0;
      } 
      dr.H(i);
    } 
    if (paramBoolean1) {
      dq.startTransition(250);
      return;
    } 
  }
  
  private void a(TextView paramTextView, int paramInt, Drawable paramDrawable, boolean paramBoolean1, boolean paramBoolean2) {
    dq dq1;
    Drawable[] arrayOfDrawable;
    dq dq2;
    Drawable drawable2;
    Drawable drawable3;
    paramBoolean1 = a(paramBoolean1, paramBoolean2);
    if (fg.cI()) {
      arrayOfDrawable = paramTextView.getCompoundDrawablesRelative();
    } else {
      arrayOfDrawable = paramTextView.getCompoundDrawables();
    } 
    Drawable drawable1 = arrayOfDrawable[paramInt];
    if (paramBoolean1)
      dq1 = a(drawable1, paramDrawable); 
    if (paramInt == 0) {
      dq dq = dq1;
    } else {
      drawable1 = arrayOfDrawable[0];
    } 
    if (paramInt == 1) {
      dq dq = dq1;
    } else {
      drawable2 = arrayOfDrawable[1];
    } 
    if (paramInt == 2) {
      dq dq = dq1;
    } else {
      drawable3 = arrayOfDrawable[2];
    } 
    if (paramInt == 3) {
      dq2 = dq1;
    } else {
      dq2 = dq2[3];
    } 
    if (fg.cI()) {
      paramTextView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, (Drawable)dq2);
    } else {
      paramTextView.setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, (Drawable)dq2);
    } 
    if (paramBoolean1)
      dq1.startTransition(250); 
  }
  
  private boolean a(boolean paramBoolean1, boolean paramBoolean2) {
    return (this.oy && !paramBoolean2 && (!paramBoolean1 || this.oz));
  }
  
  public void F(int paramInt) {
    this.or = paramInt;
  }
  
  void a(Context paramContext, Bitmap paramBitmap, boolean paramBoolean) {
    ds.d(paramBitmap);
    a((Drawable)new BitmapDrawable(paramContext.getResources(), paramBitmap), paramBoolean, false, true);
  }
  
  public void a(ImageView paramImageView) {
    ds.d(paramImageView);
    this.ou = null;
    this.ov = new WeakReference<ImageView>(paramImageView);
    this.ow = null;
    this.ox = -1;
    this.os = 2;
    this.ot = paramImageView.hashCode();
  }
  
  public void a(ImageManager.OnImageLoadedListener paramOnImageLoadedListener) {
    ds.d(paramOnImageLoadedListener);
    this.ou = new WeakReference<ImageManager.OnImageLoadedListener>(paramOnImageLoadedListener);
    this.ov = null;
    this.ow = null;
    this.ox = -1;
    this.os = 1;
    this.ot = ee.hashCode(new Object[] { paramOnImageLoadedListener, this.op });
  }
  
  void b(Context paramContext, boolean paramBoolean) {
    Drawable drawable = null;
    if (this.or != 0)
      drawable = paramContext.getResources().getDrawable(this.or); 
    a(drawable, paramBoolean, false, false);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof a))
      return false; 
    boolean bool1 = bool2;
    if (this != paramObject) {
      bool1 = bool2;
      if (((a)paramObject).hashCode() != hashCode())
        return false; 
    } 
    return bool1;
  }
  
  public int hashCode() {
    return this.ot;
  }
  
  void r(Context paramContext) {
    Drawable drawable = null;
    if (this.oq != 0)
      drawable = paramContext.getResources().getDrawable(this.oq); 
    a(drawable, false, true, false);
  }
  
  public static final class a {
    public final Uri uri;
    
    public a(Uri param1Uri) {
      this.uri = param1Uri;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool2 = true;
      if (!(param1Object instanceof a))
        return false; 
      boolean bool1 = bool2;
      if (this != param1Object) {
        bool1 = bool2;
        if (((a)param1Object).hashCode() != hashCode())
          return false; 
      } 
      return bool1;
    }
    
    public int hashCode() {
      return ee.hashCode(new Object[] { this.uri });
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\images\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */