package com.google.android.gms.common.api;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class a {
  public static abstract class a<R extends Result, A extends Api.a> implements GoogleApiClient.b<A>, PendingResult<R>, c<R> {
    private final Api.b<A> mU;
    
    private final Object mV = new Object();
    
    private final a.b<R> mW;
    
    private final CountDownLatch mX = new CountDownLatch(1);
    
    private final ArrayList<PendingResult.a> mY = new ArrayList<PendingResult.a>();
    
    private ResultCallback<R> mZ;
    
    private R na;
    
    private boolean nb;
    
    private GoogleApiClient.a nc;
    
    public a(Api.b<A> param1b) {
      this.mU = param1b;
      this.mW = new a.b<R>(this) {
          protected void a(ResultCallback<R> param2ResultCallback, R param2R) {
            param2ResultCallback.onResult(param2R);
          }
        };
    }
    
    private R bl() {
      synchronized (this.mV) {
        if (!this.nb) {
          boolean bool1 = true;
          eg.a(bool1, "Result has already been consumed.");
          eg.a(isReady(), "Result is not ready.");
          R r1 = this.na;
          bm();
          return r1;
        } 
      } 
      boolean bool = false;
      eg.a(bool, "Result has already been consumed.");
      eg.a(isReady(), "Result is not ready.");
      R r = this.na;
      bm();
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
      return r;
    }
    
    protected abstract void a(A param1A);
    
    public void a(GoogleApiClient.a param1a) {
      this.nc = param1a;
    }
    
    public final void a(R param1R) {
      boolean bool1;
      boolean bool2 = true;
      if (!isReady()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      eg.a(bool1, "Results have already been set");
      if (!this.nb) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      eg.a(bool1, "Result has already been consumed");
      synchronized (this.mV) {
        this.na = param1R;
        this.mX.countDown();
        Status status = this.na.getStatus();
        if (this.mZ != null)
          this.mW.b(this.mZ, bl()); 
        Iterator<PendingResult.a> iterator = this.mY.iterator();
        while (iterator.hasNext())
          ((PendingResult.a)iterator.next()).l(status); 
      } 
      this.mY.clear();
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_4} */
    }
    
    public final R await() {
      boolean bool;
      if (!this.nb) {
        bool = true;
      } else {
        bool = false;
      } 
      eg.a(bool, "Results has already been consumed");
      try {
        this.mX.await();
      } catch (InterruptedException interruptedException) {
        a(e(Status.nB));
      } 
      eg.a(isReady(), "Result is not ready.");
      return bl();
    }
    
    public final R await(long param1Long, TimeUnit param1TimeUnit) {
      boolean bool;
      if (!this.nb) {
        bool = true;
      } else {
        bool = false;
      } 
      eg.a(bool, "Result has already been consumed.");
      try {
        if (!this.mX.await(param1Long, param1TimeUnit))
          a(e(Status.nC)); 
      } catch (InterruptedException interruptedException) {
        a(e(Status.nB));
      } 
      eg.a(isReady(), "Result is not ready.");
      return bl();
    }
    
    public final void b(A param1A) {
      a(param1A);
    }
    
    public final Api.b<A> bj() {
      return this.mU;
    }
    
    void bm() {
      this.nb = true;
      this.na = null;
      if (this.nc != null)
        this.nc.b(this); 
    }
    
    public final boolean isReady() {
      return (this.mX.getCount() == 0L);
    }
    
    public final void setResultCallback(ResultCallback<R> param1ResultCallback) {
      boolean bool;
      if (!this.nb) {
        bool = true;
      } else {
        bool = false;
      } 
      eg.a(bool, "Result has already been consumed.");
      synchronized (this.mV) {
        if (isReady()) {
          this.mW.b(param1ResultCallback, bl());
        } else {
          this.mZ = param1ResultCallback;
        } 
        return;
      } 
    }
  }
  
  class null extends b<R> {
    null(a this$0) {}
    
    protected void a(ResultCallback<R> param1ResultCallback, R param1R) {
      param1ResultCallback.onResult(param1R);
    }
  }
  
  static abstract class b<R extends Result> extends Handler {
    public b() {
      this(Looper.getMainLooper());
    }
    
    public b(Looper param1Looper) {
      super(param1Looper);
    }
    
    protected abstract void a(ResultCallback<R> param1ResultCallback, R param1R);
    
    public void b(ResultCallback<R> param1ResultCallback, R param1R) {
      sendMessage(obtainMessage(1, new Pair(param1ResultCallback, param1R)));
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          Log.wtf("GoogleApi", "Don't know how to handle this message.");
          return;
        case 1:
          break;
      } 
      Pair pair = (Pair)param1Message.obj;
      a((ResultCallback<R>)pair.first, (R)pair.second);
    }
  }
  
  public static interface c<R> {
    void a(R param1R);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */