package com.google.android.gms.common.api;

public final class Scope {
  private final String nz;
  
  public Scope(String paramString) {
    this.nz = paramString;
  }
  
  public String br() {
    return this.nz;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\Scope.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */