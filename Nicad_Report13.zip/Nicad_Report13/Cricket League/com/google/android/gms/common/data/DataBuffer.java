package com.google.android.gms.common.data;

import android.os.Bundle;
import java.util.Iterator;

public abstract class DataBuffer<T> implements Iterable<T> {
  protected final DataHolder nE;
  
  protected DataBuffer(DataHolder paramDataHolder) {
    this.nE = paramDataHolder;
    if (this.nE != null)
      this.nE.c(this); 
  }
  
  public void close() {
    if (this.nE != null)
      this.nE.close(); 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public abstract T get(int paramInt);
  
  public int getCount() {
    return (this.nE == null) ? 0 : this.nE.getCount();
  }
  
  public Bundle getMetadata() {
    return this.nE.getMetadata();
  }
  
  public boolean isClosed() {
    return (this.nE == null) ? true : this.nE.isClosed();
  }
  
  public Iterator<T> iterator() {
    return new a<T>(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\data\DataBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */