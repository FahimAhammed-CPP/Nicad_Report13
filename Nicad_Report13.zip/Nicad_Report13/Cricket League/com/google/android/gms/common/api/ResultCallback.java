package com.google.android.gms.common.api;

public interface ResultCallback<R extends Result> {
  void onResult(R paramR);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\ResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */