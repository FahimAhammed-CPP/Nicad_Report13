package com.google.android.gms.common.data;

import java.util.ArrayList;

public abstract class d<T> extends DataBuffer<T> {
  private boolean nZ = false;
  
  private ArrayList<Integer> oa;
  
  protected d(DataHolder paramDataHolder) {
    super(paramDataHolder);
  }
  
  private int E(int paramInt) {
    return (paramInt < 0 || paramInt == this.oa.size()) ? 0 : ((paramInt == this.oa.size() - 1) ? (this.nE.getCount() - ((Integer)this.oa.get(paramInt)).intValue()) : (((Integer)this.oa.get(paramInt + 1)).intValue() - ((Integer)this.oa.get(paramInt)).intValue()));
  }
  
  private void by() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield nZ : Z
    //   6: ifne -> 135
    //   9: aload_0
    //   10: getfield nE : Lcom/google/android/gms/common/data/DataHolder;
    //   13: invokevirtual getCount : ()I
    //   16: istore_2
    //   17: aload_0
    //   18: new java/util/ArrayList
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: putfield oa : Ljava/util/ArrayList;
    //   28: iload_2
    //   29: ifle -> 130
    //   32: aload_0
    //   33: getfield oa : Ljava/util/ArrayList;
    //   36: iconst_0
    //   37: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   40: invokevirtual add : (Ljava/lang/Object;)Z
    //   43: pop
    //   44: aload_0
    //   45: invokevirtual getPrimaryDataMarkerColumn : ()Ljava/lang/String;
    //   48: astore #6
    //   50: aload_0
    //   51: getfield nE : Lcom/google/android/gms/common/data/DataHolder;
    //   54: iconst_0
    //   55: invokevirtual C : (I)I
    //   58: istore_1
    //   59: aload_0
    //   60: getfield nE : Lcom/google/android/gms/common/data/DataHolder;
    //   63: aload #6
    //   65: iconst_0
    //   66: iload_1
    //   67: invokevirtual getString : (Ljava/lang/String;II)Ljava/lang/String;
    //   70: astore #4
    //   72: iconst_1
    //   73: istore_1
    //   74: iload_1
    //   75: iload_2
    //   76: if_icmpge -> 130
    //   79: aload_0
    //   80: getfield nE : Lcom/google/android/gms/common/data/DataHolder;
    //   83: iload_1
    //   84: invokevirtual C : (I)I
    //   87: istore_3
    //   88: aload_0
    //   89: getfield nE : Lcom/google/android/gms/common/data/DataHolder;
    //   92: aload #6
    //   94: iload_1
    //   95: iload_3
    //   96: invokevirtual getString : (Ljava/lang/String;II)Ljava/lang/String;
    //   99: astore #5
    //   101: aload #5
    //   103: aload #4
    //   105: invokevirtual equals : (Ljava/lang/Object;)Z
    //   108: ifne -> 145
    //   111: aload_0
    //   112: getfield oa : Ljava/util/ArrayList;
    //   115: iload_1
    //   116: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   119: invokevirtual add : (Ljava/lang/Object;)Z
    //   122: pop
    //   123: aload #5
    //   125: astore #4
    //   127: goto -> 145
    //   130: aload_0
    //   131: iconst_1
    //   132: putfield nZ : Z
    //   135: aload_0
    //   136: monitorexit
    //   137: return
    //   138: astore #4
    //   140: aload_0
    //   141: monitorexit
    //   142: aload #4
    //   144: athrow
    //   145: iload_1
    //   146: iconst_1
    //   147: iadd
    //   148: istore_1
    //   149: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   2	28	138	finally
    //   32	72	138	finally
    //   79	123	138	finally
    //   130	135	138	finally
    //   135	137	138	finally
    //   140	142	138	finally
  }
  
  int D(int paramInt) {
    if (paramInt < 0 || paramInt >= this.oa.size())
      throw new IllegalArgumentException("Position " + paramInt + " is out of bounds for this buffer"); 
    return ((Integer)this.oa.get(paramInt)).intValue();
  }
  
  protected abstract T a(int paramInt1, int paramInt2);
  
  public final T get(int paramInt) {
    by();
    return a(D(paramInt), E(paramInt));
  }
  
  public int getCount() {
    by();
    return this.oa.size();
  }
  
  protected abstract String getPrimaryDataMarkerColumn();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\data\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */