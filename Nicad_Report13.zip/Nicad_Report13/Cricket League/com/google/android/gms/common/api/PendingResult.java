package com.google.android.gms.common.api;

import java.util.concurrent.TimeUnit;

public interface PendingResult<R extends Result> {
  R await();
  
  R await(long paramLong, TimeUnit paramTimeUnit);
  
  R e(Status paramStatus);
  
  void setResultCallback(ResultCallback<R> paramResultCallback);
  
  public static interface a {
    void l(Status param1Status);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\api\PendingResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */