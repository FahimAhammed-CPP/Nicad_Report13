package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class c<T extends SafeParcelable> extends DataBuffer<T> {
  private static final String[] nI = new String[] { "data" };
  
  private final Parcelable.Creator<T> nJ;
  
  public c(DataHolder paramDataHolder, Parcelable.Creator<T> paramCreator) {
    super(paramDataHolder);
    this.nJ = paramCreator;
  }
  
  public T B(int paramInt) {
    byte[] arrayOfByte = this.nE.getByteArray("data", paramInt, 0);
    Parcel parcel = Parcel.obtain();
    parcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
    parcel.setDataPosition(0);
    SafeParcelable safeParcelable = (SafeParcelable)this.nJ.createFromParcel(parcel);
    parcel.recycle();
    return (T)safeParcelable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\common\data\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */