package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.a;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.p;
import java.io.IOException;

public final class AdvertisingIdClient {
  private static a g(Context paramContext) throws IOException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    try {
      paramContext.getPackageManager().getPackageInfo("com.android.vending", 0);
      try {
        GooglePlayServicesUtil.m(paramContext);
        a a = new a();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (paramContext.bindService(intent, (ServiceConnection)a, 1))
          return a; 
      } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
        throw new IOException(googlePlayServicesNotAvailableException);
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new GooglePlayServicesNotAvailableException(9);
    } 
  }
  
  public static Info getAdvertisingIdInfo(Context paramContext) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    eg.O("Calling this from your main thread can lead to deadlock");
    a a = g(paramContext);
    try {
      p p = p.a.b(a.bg());
      return new Info(p.getId(), p.a(true));
    } catch (RemoteException remoteException) {
      Log.i("AdvertisingIdClient", "GMS remote exception ", (Throwable)remoteException);
      throw new IOException("Remote exception");
    } catch (InterruptedException interruptedException) {
      throw new IOException("Interrupted exception");
    } finally {
      paramContext.unbindService((ServiceConnection)a);
    } 
  }
  
  public static final class Info {
    private final String eb;
    
    private final boolean ec;
    
    Info(String param1String, boolean param1Boolean) {
      this.eb = param1String;
      this.ec = param1Boolean;
    }
    
    public String getId() {
      return this.eb;
    }
    
    public boolean isLimitAdTrackingEnabled() {
      return this.ec;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\identifier\AdvertisingIdClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */