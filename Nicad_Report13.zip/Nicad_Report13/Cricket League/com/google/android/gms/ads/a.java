package com.google.android.gms.ads;

public final class a {
  public static AdSize a(int paramInt1, int paramInt2, String paramString) {
    return new AdSize(paramInt1, paramInt2, paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */