package com.google.android.gms.ads;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.internal.ag;

public final class AdView extends ViewGroup {
  private final ag dZ = new ag(this);
  
  public AdView(Context paramContext) {
    super(paramContext);
  }
  
  public AdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public AdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void destroy() {
    this.dZ.destroy();
  }
  
  public AdListener getAdListener() {
    return this.dZ.getAdListener();
  }
  
  public AdSize getAdSize() {
    return this.dZ.getAdSize();
  }
  
  public String getAdUnitId() {
    return this.dZ.getAdUnitId();
  }
  
  public void loadAd(AdRequest paramAdRequest) {
    this.dZ.a(paramAdRequest.v());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    AdSize adSize = getAdSize();
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      j = view.getMeasuredWidth();
      i = view.getMeasuredHeight();
    } else if (adSize != null) {
      Context context = getContext();
      j = adSize.getWidthInPixels(context);
      i = adSize.getHeightInPixels(context);
    } else {
      j = 0;
    } 
    int j = Math.max(j, getSuggestedMinimumWidth());
    i = Math.max(i, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(j, paramInt1), View.resolveSize(i, paramInt2));
  }
  
  public void pause() {
    this.dZ.pause();
  }
  
  public void resume() {
    this.dZ.resume();
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.dZ.setAdListener(paramAdListener);
  }
  
  public void setAdSize(AdSize paramAdSize) {
    this.dZ.setAdSizes(new AdSize[] { paramAdSize });
  }
  
  public void setAdUnitId(String paramString) {
    this.dZ.setAdUnitId(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\ads\AdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */