package com.google.android.gms.auth;

import android.accounts.AccountManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.R;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.a;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.o;
import java.io.IOException;
import java.net.URISyntaxException;

public final class GoogleAuthUtil {
  public static final String GOOGLE_ACCOUNT_TYPE = "com.google";
  
  public static final String KEY_ANDROID_PACKAGE_NAME;
  
  public static final String KEY_CALLER_UID = "callerUid";
  
  public static final String KEY_CLIENT_PACKAGE_NAME = "clientPackageName";
  
  public static final String KEY_REQUEST_ACTIONS = "request_visible_actions";
  
  @Deprecated
  public static final String KEY_REQUEST_VISIBLE_ACTIVITIES = "request_visible_actions";
  
  public static final String KEY_SUPPRESS_PROGRESS_SCREEN = "suppressProgressScreen";
  
  public static final String OEM_ONLY_KEY_TARGET_ANDROID_ID = "oauth2_target_device_id";
  
  public static final String OEM_ONLY_KEY_VERIFIER = "oauth2_authcode_verifier";
  
  public static final String OEM_ONLY_SCOPE_ACCOUNT_BOOTSTRAP = "_account_setup";
  
  private static final ComponentName kb;
  
  private static final ComponentName kc;
  
  private static final Intent kd;
  
  private static final Intent ke;
  
  static {
    if (Build.VERSION.SDK_INT >= 14);
    KEY_ANDROID_PACKAGE_NAME = "androidPackageName";
    kb = new ComponentName("com.google.android.gms", "com.google.android.gms.auth.GetToken");
    kc = new ComponentName("com.google.android.gms", "com.google.android.gms.recovery.RecoveryService");
    kd = (new Intent()).setPackage("com.google.android.gms").setComponent(kb);
    ke = (new Intent()).setPackage("com.google.android.gms").setComponent(kc);
  }
  
  private static String a(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    try {
      return getToken(paramContext, paramString1, paramString2, bundle);
    } catch (GooglePlayServicesAvailabilityException googlePlayServicesAvailabilityException) {
      int i;
      PendingIntent pendingIntent = GooglePlayServicesUtil.getErrorPendingIntent(googlePlayServicesAvailabilityException.getConnectionStatusCode(), paramContext, 0);
      Resources resources = paramContext.getResources();
      Notification notification = new Notification(17301642, resources.getString(R.string.auth_client_play_services_err_notification_msg), System.currentTimeMillis());
      notification.flags |= 0x10;
      paramString2 = (paramContext.getApplicationInfo()).name;
      paramString1 = paramString2;
      if (TextUtils.isEmpty(paramString2)) {
        paramString1 = paramContext.getPackageName();
        PackageManager packageManager = paramContext.getApplicationContext().getPackageManager();
        try {
          int k;
          ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramContext.getPackageName(), 0);
          if (applicationInfo != null)
            paramString1 = packageManager.getApplicationLabel(applicationInfo).toString(); 
          paramString1 = resources.getString(R.string.auth_client_requested_by_msg, new Object[] { paramString1 });
          switch (googlePlayServicesAvailabilityException.getConnectionStatusCode()) {
            default:
              k = R.string.auth_client_using_bad_version_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 1:
              k = R.string.auth_client_needs_installation_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 2:
              k = R.string.auth_client_needs_update_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 3:
              break;
          } 
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          int k;
          nameNotFoundException = null;
          if (nameNotFoundException != null)
            paramString1 = packageManager.getApplicationLabel((ApplicationInfo)nameNotFoundException).toString(); 
          paramString1 = resources.getString(R.string.auth_client_requested_by_msg, new Object[] { paramString1 });
          switch (googlePlayServicesAvailabilityException.getConnectionStatusCode()) {
            default:
              k = R.string.auth_client_using_bad_version_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 1:
              k = R.string.auth_client_needs_installation_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 2:
              k = R.string.auth_client_needs_update_title;
              notification.setLatestEventInfo(paramContext, resources.getString(k), paramString1, pendingIntent);
              ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
              throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
            case 3:
              break;
          } 
        } 
        int j = R.string.auth_client_needs_enabling_title;
        notification.setLatestEventInfo(paramContext, resources.getString(j), paramString1, pendingIntent);
        ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
        throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
      } 
      paramString1 = resources.getString(R.string.auth_client_requested_by_msg, new Object[] { paramString1 });
      switch (googlePlayServicesAvailabilityException.getConnectionStatusCode()) {
        default:
          i = R.string.auth_client_using_bad_version_title;
          notification.setLatestEventInfo(paramContext, resources.getString(i), paramString1, pendingIntent);
          ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
          throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
        case 1:
          i = R.string.auth_client_needs_installation_title;
          notification.setLatestEventInfo(paramContext, resources.getString(i), paramString1, pendingIntent);
          ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
          throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
        case 2:
          i = R.string.auth_client_needs_update_title;
          notification.setLatestEventInfo(paramContext, resources.getString(i), paramString1, pendingIntent);
          ((NotificationManager)paramContext.getSystemService("notification")).notify(39789, notification);
          throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
        case 3:
          break;
      } 
    } catch (UserRecoverableAuthException userRecoverableAuthException) {
      throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
    } 
  }
  
  private static void b(Intent paramIntent) {
    if (paramIntent == null)
      throw new IllegalArgumentException("Callack cannot be null."); 
    String str = paramIntent.toUri(1);
    try {
      Intent.parseUri(str, 1);
      return;
    } catch (URISyntaxException uRISyntaxException) {
      throw new IllegalArgumentException("Parameter callback contains invalid data. It must be serializable using toUri() and parseUri().");
    } 
  }
  
  public static String getToken(Context paramContext, String paramString1, String paramString2) throws IOException, UserRecoverableAuthException, GoogleAuthException {
    return getToken(paramContext, paramString1, paramString2, new Bundle());
  }
  
  public static String getToken(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, UserRecoverableAuthException, GoogleAuthException {
    Context context = paramContext.getApplicationContext();
    eg.O("Calling this from your main thread can lead to deadlock");
    m(context);
    if (paramBundle == null) {
      paramBundle = new Bundle();
    } else {
      paramBundle = new Bundle(paramBundle);
    } 
    String str = (paramContext.getApplicationInfo()).packageName;
    paramBundle.putString("clientPackageName", str);
    if (!paramBundle.containsKey(KEY_ANDROID_PACKAGE_NAME))
      paramBundle.putString(KEY_ANDROID_PACKAGE_NAME, str); 
    a a = new a();
    if (context.bindService(kd, (ServiceConnection)a, 1)) {
      try {
        Bundle bundle = o.a.a(a.bg()).a(paramString1, paramString2, paramBundle);
        paramString2 = bundle.getString("authtoken");
        boolean bool = TextUtils.isEmpty(paramString2);
        if (!bool)
          return paramString2; 
        paramString2 = bundle.getString("Error");
        Intent intent = (Intent)bundle.getParcelable("userRecoveryIntent");
        if (x(paramString2))
          throw new UserRecoverableAuthException(paramString2, intent); 
      } catch (RemoteException remoteException) {
        Log.i("GoogleAuthUtil", "GMS remote exception ", (Throwable)remoteException);
        throw new IOException("remote exception");
      } catch (InterruptedException interruptedException) {
        throw new GoogleAuthException("Interrupted");
      } finally {
        context.unbindService((ServiceConnection)a);
      } 
      throw new GoogleAuthException(paramString2);
    } 
    throw new IOException("Could not bind to service with the given context.");
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle, Intent paramIntent) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    b(paramIntent);
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    bundle.putParcelable("callback_intent", (Parcelable)paramIntent);
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle1, String paramString3, Bundle paramBundle2) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    if (TextUtils.isEmpty(paramString3))
      throw new IllegalArgumentException("Authority cannot be empty or null."); 
    Bundle bundle = paramBundle1;
    if (paramBundle1 == null)
      bundle = new Bundle(); 
    paramBundle1 = paramBundle2;
    if (paramBundle2 == null)
      paramBundle1 = new Bundle(); 
    ContentResolver.validateSyncExtrasBundle(paramBundle1);
    bundle.putString("authority", paramString3);
    bundle.putBundle("sync_extras", paramBundle1);
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  public static void invalidateToken(Context paramContext, String paramString) {
    AccountManager.get(paramContext).invalidateAuthToken("com.google", paramString);
  }
  
  private static void m(Context paramContext) throws GooglePlayServicesAvailabilityException, GoogleAuthException {
    try {
      GooglePlayServicesUtil.m(paramContext);
      return;
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      throw new GooglePlayServicesAvailabilityException(googlePlayServicesRepairableException.getConnectionStatusCode(), googlePlayServicesRepairableException.getMessage(), googlePlayServicesRepairableException.getIntent());
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      throw new GoogleAuthException(googlePlayServicesNotAvailableException.getMessage());
    } 
  }
  
  private static boolean w(String paramString) {
    return ("NetworkError".equals(paramString) || "ServiceUnavailable".equals(paramString) || "Timeout".equals(paramString));
  }
  
  private static boolean x(String paramString) {
    return ("BadAuthentication".equals(paramString) || "CaptchaRequired".equals(paramString) || "DeviceManagementRequiredOrSyncDisabled".equals(paramString) || "NeedPermission".equals(paramString) || "NeedsBrowser".equals(paramString) || "UserCancel".equals(paramString) || "AppDownloadRequired".equals(paramString));
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 11);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\auth\GoogleAuthUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */