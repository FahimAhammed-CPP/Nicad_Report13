package com.google.android.gms.auth;

public class GoogleAuthException extends Exception {
  public GoogleAuthException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\auth\GoogleAuthException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */