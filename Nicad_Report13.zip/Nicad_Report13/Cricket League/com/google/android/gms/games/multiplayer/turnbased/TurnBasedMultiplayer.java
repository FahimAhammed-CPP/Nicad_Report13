package com.google.android.gms.games.multiplayer.turnbased;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import java.util.List;

public interface TurnBasedMultiplayer {
  PendingResult<InitiateMatchResult> acceptInvitation(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<CancelMatchResult> cancelMatch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<InitiateMatchResult> createMatch(GoogleApiClient paramGoogleApiClient, TurnBasedMatchConfig paramTurnBasedMatchConfig);
  
  void declineInvitation(GoogleApiClient paramGoogleApiClient, String paramString);
  
  void dismissInvitation(GoogleApiClient paramGoogleApiClient, String paramString);
  
  void dismissMatch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient paramGoogleApiClient, String paramString, byte[] paramArrayOfbyte, List<ParticipantResult> paramList);
  
  PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient paramGoogleApiClient, String paramString, byte[] paramArrayOfbyte, ParticipantResult... paramVarArgs);
  
  Intent getInboxIntent(GoogleApiClient paramGoogleApiClient);
  
  int getMaxMatchDataSize(GoogleApiClient paramGoogleApiClient);
  
  Intent getSelectOpponentsIntent(GoogleApiClient paramGoogleApiClient, int paramInt1, int paramInt2);
  
  Intent getSelectOpponentsIntent(GoogleApiClient paramGoogleApiClient, int paramInt1, int paramInt2, boolean paramBoolean);
  
  PendingResult<LeaveMatchResult> leaveMatch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<LeaveMatchResult> leaveMatchDuringTurn(GoogleApiClient paramGoogleApiClient, String paramString1, String paramString2);
  
  PendingResult<LoadMatchResult> loadMatch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<LoadMatchesResult> loadMatchesByStatus(GoogleApiClient paramGoogleApiClient, int... paramVarArgs);
  
  void registerMatchUpdateListener(GoogleApiClient paramGoogleApiClient, OnTurnBasedMatchUpdateReceivedListener paramOnTurnBasedMatchUpdateReceivedListener);
  
  PendingResult<InitiateMatchResult> rematch(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient paramGoogleApiClient, String paramString1, byte[] paramArrayOfbyte, String paramString2);
  
  PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient paramGoogleApiClient, String paramString1, byte[] paramArrayOfbyte, String paramString2, List<ParticipantResult> paramList);
  
  PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient paramGoogleApiClient, String paramString1, byte[] paramArrayOfbyte, String paramString2, ParticipantResult... paramVarArgs);
  
  void unregisterMatchUpdateListener(GoogleApiClient paramGoogleApiClient);
  
  public static interface CancelMatchResult extends Result {
    String getMatchId();
  }
  
  public static interface InitiateMatchResult extends Result {
    TurnBasedMatch getMatch();
  }
  
  public static interface LeaveMatchResult extends Result {
    TurnBasedMatch getMatch();
  }
  
  public static interface LoadMatchResult extends Result {
    TurnBasedMatch getMatch();
  }
  
  public static interface LoadMatchesResult extends Releasable, Result {
    LoadMatchesResponse getMatches();
  }
  
  public static interface UpdateMatchResult extends Result {
    TurnBasedMatch getMatch();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\turnbased\TurnBasedMultiplayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */