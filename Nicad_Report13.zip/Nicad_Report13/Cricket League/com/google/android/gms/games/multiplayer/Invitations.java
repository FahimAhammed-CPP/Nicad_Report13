package com.google.android.gms.games.multiplayer;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;

public interface Invitations {
  Intent getInvitationInboxIntent(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<LoadInvitationsResult> loadInvitations(GoogleApiClient paramGoogleApiClient);
  
  void registerInvitationListener(GoogleApiClient paramGoogleApiClient, OnInvitationReceivedListener paramOnInvitationReceivedListener);
  
  void unregisterInvitationListener(GoogleApiClient paramGoogleApiClient);
  
  public static interface LoadInvitationsResult extends Releasable, Result {
    InvitationBuffer getInvitations();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\Invitations.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */