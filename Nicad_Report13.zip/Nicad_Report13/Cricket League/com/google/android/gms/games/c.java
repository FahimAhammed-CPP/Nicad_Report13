package com.google.android.gms.games;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class c implements Parcelable.Creator<PlayerEntity> {
  static void a(PlayerEntity paramPlayerEntity, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.a(paramParcel, 1, paramPlayerEntity.getPlayerId(), false);
    b.c(paramParcel, 1000, paramPlayerEntity.getVersionCode());
    b.a(paramParcel, 2, paramPlayerEntity.getDisplayName(), false);
    b.a(paramParcel, 3, (Parcelable)paramPlayerEntity.getIconImageUri(), paramInt, false);
    b.a(paramParcel, 4, (Parcelable)paramPlayerEntity.getHiResImageUri(), paramInt, false);
    b.a(paramParcel, 5, paramPlayerEntity.getRetrievedTimestamp());
    b.c(paramParcel, 6, paramPlayerEntity.db());
    b.a(paramParcel, 7, paramPlayerEntity.getLastPlayedWithTimestamp());
    b.D(paramParcel, i);
  }
  
  public PlayerEntity Z(Parcel paramParcel) {
    long l1 = 0L;
    int i = 0;
    Uri uri1 = null;
    int k = a.n(paramParcel);
    long l2 = 0L;
    Uri uri2 = null;
    String str1 = null;
    String str2 = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.m(paramParcel);
      switch (a.M(m)) {
        default:
          a.b(paramParcel, m);
          continue;
        case 1:
          str2 = a.m(paramParcel, m);
          continue;
        case 1000:
          j = a.g(paramParcel, m);
          continue;
        case 2:
          str1 = a.m(paramParcel, m);
          continue;
        case 3:
          uri2 = (Uri)a.a(paramParcel, m, Uri.CREATOR);
          continue;
        case 4:
          uri1 = (Uri)a.a(paramParcel, m, Uri.CREATOR);
          continue;
        case 5:
          l2 = a.h(paramParcel, m);
          continue;
        case 6:
          i = a.g(paramParcel, m);
          continue;
        case 7:
          break;
      } 
      l1 = a.h(paramParcel, m);
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new PlayerEntity(j, str2, str1, uri2, uri1, l2, i, l1);
  }
  
  public PlayerEntity[] aA(int paramInt) {
    return new PlayerEntity[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */