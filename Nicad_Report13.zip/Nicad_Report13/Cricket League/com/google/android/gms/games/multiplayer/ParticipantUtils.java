package com.google.android.gms.games.multiplayer;

import com.google.android.gms.games.Player;
import com.google.android.gms.internal.eg;
import java.util.ArrayList;

public final class ParticipantUtils {
  public static boolean am(String paramString) {
    eg.b(paramString, "Participant ID must not be null");
    return paramString.startsWith("p_");
  }
  
  public static String getParticipantId(ArrayList<Participant> paramArrayList, String paramString) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      Participant participant = paramArrayList.get(i);
      Player player = participant.getPlayer();
      if (player != null && player.getPlayerId().equals(paramString))
        return participant.getParticipantId(); 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\ParticipantUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */