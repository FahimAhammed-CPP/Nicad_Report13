package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcelable;
import com.google.android.gms.common.data.Freezable;

public interface Player extends Parcelable, Freezable<Player> {
  int db();
  
  String getDisplayName();
  
  void getDisplayName(CharArrayBuffer paramCharArrayBuffer);
  
  Uri getHiResImageUri();
  
  Uri getIconImageUri();
  
  long getLastPlayedWithTimestamp();
  
  String getPlayerId();
  
  long getRetrievedTimestamp();
  
  boolean hasHiResImage();
  
  boolean hasIconImage();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\Player.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */