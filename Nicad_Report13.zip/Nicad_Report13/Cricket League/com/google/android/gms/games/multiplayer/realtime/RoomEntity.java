package com.google.android.gms.games.multiplayer.realtime;

import android.database.CharArrayBuffer;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.ParticipantEntity;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.fc;
import com.google.android.gms.internal.fm;
import java.util.ArrayList;

public final class RoomEntity extends fm implements Room {
  public static final Parcelable.Creator<RoomEntity> CREATOR = new a();
  
  private final int kg;
  
  private final String sJ;
  
  private final String uk;
  
  private final Bundle wH;
  
  private final String wL;
  
  private final int wM;
  
  private final int wN;
  
  private final long wk;
  
  private final ArrayList<ParticipantEntity> wn;
  
  private final int wo;
  
  RoomEntity(int paramInt1, String paramString1, String paramString2, long paramLong, int paramInt2, String paramString3, int paramInt3, Bundle paramBundle, ArrayList<ParticipantEntity> paramArrayList, int paramInt4) {
    this.kg = paramInt1;
    this.uk = paramString1;
    this.wL = paramString2;
    this.wk = paramLong;
    this.wM = paramInt2;
    this.sJ = paramString3;
    this.wo = paramInt3;
    this.wH = paramBundle;
    this.wn = paramArrayList;
    this.wN = paramInt4;
  }
  
  public RoomEntity(Room paramRoom) {
    this.kg = 2;
    this.uk = paramRoom.getRoomId();
    this.wL = paramRoom.getCreatorId();
    this.wk = paramRoom.getCreationTimestamp();
    this.wM = paramRoom.getStatus();
    this.sJ = paramRoom.getDescription();
    this.wo = paramRoom.getVariant();
    this.wH = paramRoom.getAutoMatchCriteria();
    ArrayList<Participant> arrayList = paramRoom.getParticipants();
    int j = arrayList.size();
    this.wn = new ArrayList<ParticipantEntity>(j);
    for (int i = 0; i < j; i++)
      this.wn.add((ParticipantEntity)((Participant)arrayList.get(i)).freeze()); 
    this.wN = paramRoom.getAutoMatchWaitEstimateSeconds();
  }
  
  static int a(Room paramRoom) {
    return ee.hashCode(new Object[] { paramRoom.getRoomId(), paramRoom.getCreatorId(), Long.valueOf(paramRoom.getCreationTimestamp()), Integer.valueOf(paramRoom.getStatus()), paramRoom.getDescription(), Integer.valueOf(paramRoom.getVariant()), paramRoom.getAutoMatchCriteria(), paramRoom.getParticipants(), Integer.valueOf(paramRoom.getAutoMatchWaitEstimateSeconds()) });
  }
  
  static int a(Room paramRoom, String paramString) {
    ArrayList<Participant> arrayList = paramRoom.getParticipants();
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      Participant participant = arrayList.get(i);
      if (participant.getParticipantId().equals(paramString))
        return participant.getStatus(); 
    } 
    throw new IllegalStateException("Participant " + paramString + " is not in room " + paramRoom.getRoomId());
  }
  
  static boolean a(Room paramRoom, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof Room))
      return false; 
    boolean bool1 = bool2;
    if (paramRoom != paramObject) {
      paramObject = paramObject;
      if (ee.equal(paramObject.getRoomId(), paramRoom.getRoomId()) && ee.equal(paramObject.getCreatorId(), paramRoom.getCreatorId()) && ee.equal(Long.valueOf(paramObject.getCreationTimestamp()), Long.valueOf(paramRoom.getCreationTimestamp())) && ee.equal(Integer.valueOf(paramObject.getStatus()), Integer.valueOf(paramRoom.getStatus())) && ee.equal(paramObject.getDescription(), paramRoom.getDescription()) && ee.equal(Integer.valueOf(paramObject.getVariant()), Integer.valueOf(paramRoom.getVariant())) && ee.equal(paramObject.getAutoMatchCriteria(), paramRoom.getAutoMatchCriteria()) && ee.equal(paramObject.getParticipants(), paramRoom.getParticipants())) {
        bool1 = bool2;
        return !ee.equal(Integer.valueOf(paramObject.getAutoMatchWaitEstimateSeconds()), Integer.valueOf(paramRoom.getAutoMatchWaitEstimateSeconds())) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(Room paramRoom) {
    return ee.e(paramRoom).a("RoomId", paramRoom.getRoomId()).a("CreatorId", paramRoom.getCreatorId()).a("CreationTimestamp", Long.valueOf(paramRoom.getCreationTimestamp())).a("RoomStatus", Integer.valueOf(paramRoom.getStatus())).a("Description", paramRoom.getDescription()).a("Variant", Integer.valueOf(paramRoom.getVariant())).a("AutoMatchCriteria", paramRoom.getAutoMatchCriteria()).a("Participants", paramRoom.getParticipants()).a("AutoMatchWaitEstimateSeconds", Integer.valueOf(paramRoom.getAutoMatchWaitEstimateSeconds())).toString();
  }
  
  static String b(Room paramRoom, String paramString) {
    ArrayList<Participant> arrayList = paramRoom.getParticipants();
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      Participant participant = arrayList.get(i);
      Player player = participant.getPlayer();
      if (player != null && player.getPlayerId().equals(paramString))
        return participant.getParticipantId(); 
    } 
    return null;
  }
  
  static Participant c(Room paramRoom, String paramString) {
    ArrayList<Participant> arrayList = paramRoom.getParticipants();
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      Participant participant = arrayList.get(i);
      if (participant.getParticipantId().equals(paramString))
        return participant; 
    } 
    throw new IllegalStateException("Participant " + paramString + " is not in match " + paramRoom.getRoomId());
  }
  
  static ArrayList<String> c(Room paramRoom) {
    ArrayList<Participant> arrayList = paramRoom.getParticipants();
    int j = arrayList.size();
    ArrayList<String> arrayList1 = new ArrayList(j);
    for (int i = 0; i < j; i++)
      arrayList1.add(((Participant)arrayList.get(i)).getParticipantId()); 
    return arrayList1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public Room freeze() {
    return this;
  }
  
  public Bundle getAutoMatchCriteria() {
    return this.wH;
  }
  
  public int getAutoMatchWaitEstimateSeconds() {
    return this.wN;
  }
  
  public long getCreationTimestamp() {
    return this.wk;
  }
  
  public String getCreatorId() {
    return this.wL;
  }
  
  public String getDescription() {
    return this.sJ;
  }
  
  public void getDescription(CharArrayBuffer paramCharArrayBuffer) {
    fc.b(this.sJ, paramCharArrayBuffer);
  }
  
  public Participant getParticipant(String paramString) {
    return c(this, paramString);
  }
  
  public String getParticipantId(String paramString) {
    return b(this, paramString);
  }
  
  public ArrayList<String> getParticipantIds() {
    return c(this);
  }
  
  public int getParticipantStatus(String paramString) {
    return a(this, paramString);
  }
  
  public ArrayList<Participant> getParticipants() {
    return new ArrayList(this.wn);
  }
  
  public String getRoomId() {
    return this.uk;
  }
  
  public int getStatus() {
    return this.wM;
  }
  
  public int getVariant() {
    return this.wo;
  }
  
  public int getVersionCode() {
    return this.kg;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    if (!bN()) {
      b.a(this, paramParcel, paramInt);
      return;
    } 
    paramParcel.writeString(this.uk);
    paramParcel.writeString(this.wL);
    paramParcel.writeLong(this.wk);
    paramParcel.writeInt(this.wM);
    paramParcel.writeString(this.sJ);
    paramParcel.writeInt(this.wo);
    paramParcel.writeBundle(this.wH);
    int j = this.wn.size();
    paramParcel.writeInt(j);
    int i = 0;
    while (true) {
      if (i < j) {
        ((ParticipantEntity)this.wn.get(i)).writeToParcel(paramParcel, paramInt);
        i++;
        continue;
      } 
      return;
    } 
  }
  
  static final class a extends b {
    public RoomEntity ad(Parcel param1Parcel) {
      if (RoomEntity.b(RoomEntity.da()) || RoomEntity.ad(RoomEntity.class.getCanonicalName()))
        return super.ad(param1Parcel); 
      String str1 = param1Parcel.readString();
      String str2 = param1Parcel.readString();
      long l = param1Parcel.readLong();
      int j = param1Parcel.readInt();
      String str3 = param1Parcel.readString();
      int k = param1Parcel.readInt();
      Bundle bundle = param1Parcel.readBundle();
      int m = param1Parcel.readInt();
      ArrayList<Object> arrayList = new ArrayList(m);
      for (int i = 0; i < m; i++)
        arrayList.add(ParticipantEntity.CREATOR.createFromParcel(param1Parcel)); 
      return new RoomEntity(2, str1, str2, l, j, str3, k, bundle, (ArrayList)arrayList, -1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\realtime\RoomEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */