package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.ge;
import java.util.HashMap;

@Deprecated
public final class SubmitScoreResult {
  private static final String[] wh = new String[] { "leaderboardId", "playerId", "timeSpan", "hasResult", "rawScore", "formattedScore", "newBest", "scoreTag" };
  
  private int mC;
  
  private String tC;
  
  private String vD;
  
  private HashMap<Integer, Result> wi;
  
  public SubmitScoreResult(int paramInt, String paramString1, String paramString2) {
    this(paramInt, paramString1, paramString2, new HashMap<Integer, Result>());
  }
  
  public SubmitScoreResult(int paramInt, String paramString1, String paramString2, HashMap<Integer, Result> paramHashMap) {
    this.mC = paramInt;
    this.vD = paramString1;
    this.tC = paramString2;
    this.wi = paramHashMap;
  }
  
  public SubmitScoreResult(DataHolder paramDataHolder) {
    boolean bool;
    this.mC = paramDataHolder.getStatusCode();
    this.wi = new HashMap<Integer, Result>();
    int j = paramDataHolder.getCount();
    if (j == 3) {
      bool = true;
    } else {
      bool = false;
    } 
    eg.r(bool);
    for (int i = 0; i < j; i++) {
      int k = paramDataHolder.C(i);
      if (i == 0) {
        this.vD = paramDataHolder.getString("leaderboardId", i, k);
        this.tC = paramDataHolder.getString("playerId", i, k);
      } 
      if (paramDataHolder.getBoolean("hasResult", i, k))
        a(new Result(paramDataHolder.getLong("rawScore", i, k), paramDataHolder.getString("formattedScore", i, k), paramDataHolder.getString("scoreTag", i, k), paramDataHolder.getBoolean("newBest", i, k)), paramDataHolder.getInteger("timeSpan", i, k)); 
    } 
  }
  
  private void a(Result paramResult, int paramInt) {
    this.wi.put(Integer.valueOf(paramInt), paramResult);
  }
  
  public String getLeaderboardId() {
    return this.vD;
  }
  
  public String getPlayerId() {
    return this.tC;
  }
  
  public Result getScoreResult(int paramInt) {
    return this.wi.get(Integer.valueOf(paramInt));
  }
  
  public int getStatusCode() {
    return this.mC;
  }
  
  public String toString() {
    ee.a a = ee.e(this).a("PlayerId", this.tC).a("StatusCode", Integer.valueOf(this.mC));
    for (int i = 0; i < 3; i++) {
      String str;
      Result result = this.wi.get(Integer.valueOf(i));
      a.a("TimesSpan", ge.aG(i));
      if (result == null) {
        str = "null";
      } else {
        str = str.toString();
      } 
      a.a("Result", str);
    } 
    return a.toString();
  }
  
  public static final class Result {
    public final String formattedScore;
    
    public final boolean newBest;
    
    public final long rawScore;
    
    public final String scoreTag;
    
    public Result(long param1Long, String param1String1, String param1String2, boolean param1Boolean) {
      this.rawScore = param1Long;
      this.formattedScore = param1String1;
      this.scoreTag = param1String2;
      this.newBest = param1Boolean;
    }
    
    public String toString() {
      return ee.e(this).a("RawScore", Long.valueOf(this.rawScore)).a("FormattedScore", this.formattedScore).a("ScoreTag", this.scoreTag).a("NewBest", Boolean.valueOf(this.newBest)).toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\SubmitScoreResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */