package com.google.android.gms.games.multiplayer.turnbased;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.Participatable;
import java.util.ArrayList;

public interface TurnBasedMatch extends Parcelable, Freezable<TurnBasedMatch>, Participatable {
  public static final int MATCH_STATUS_ACTIVE = 1;
  
  public static final int MATCH_STATUS_AUTO_MATCHING = 0;
  
  public static final int MATCH_STATUS_CANCELED = 4;
  
  public static final int MATCH_STATUS_COMPLETE = 2;
  
  public static final int MATCH_STATUS_EXPIRED = 3;
  
  public static final int MATCH_TURN_STATUS_COMPLETE = 3;
  
  public static final int MATCH_TURN_STATUS_INVITED = 0;
  
  public static final int MATCH_TURN_STATUS_MY_TURN = 1;
  
  public static final int MATCH_TURN_STATUS_THEIR_TURN = 2;
  
  public static final int MATCH_VARIANT_ANY = -1;
  
  public static final int[] wS = new int[] { 0, 1, 2, 3 };
  
  boolean canRematch();
  
  Bundle getAutoMatchCriteria();
  
  int getAvailableAutoMatchSlots();
  
  long getCreationTimestamp();
  
  String getCreatorId();
  
  byte[] getData();
  
  Game getGame();
  
  long getLastUpdatedTimestamp();
  
  String getLastUpdaterId();
  
  String getMatchId();
  
  int getMatchNumber();
  
  Participant getParticipant(String paramString);
  
  String getParticipantId(String paramString);
  
  ArrayList<String> getParticipantIds();
  
  int getParticipantStatus(String paramString);
  
  String getPendingParticipantId();
  
  byte[] getPreviousMatchData();
  
  String getRematchId();
  
  int getStatus();
  
  int getTurnStatus();
  
  int getVariant();
  
  int getVersion();
  
  boolean isLocallyModified();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\turnbased\TurnBasedMatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */