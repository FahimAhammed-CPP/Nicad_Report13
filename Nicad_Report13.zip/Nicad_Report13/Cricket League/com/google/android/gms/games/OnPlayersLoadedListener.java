package com.google.android.gms.games;

@Deprecated
public interface OnPlayersLoadedListener {
  void onPlayersLoaded(int paramInt, PlayerBuffer paramPlayerBuffer);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\OnPlayersLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */