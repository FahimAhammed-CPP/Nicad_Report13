package com.google.android.gms.games.multiplayer.turnbased;

import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;

@Deprecated
public interface TurnBasedMultiplayerListener extends OnInvitationReceivedListener, OnTurnBasedMatchCanceledListener, OnTurnBasedMatchInitiatedListener, OnTurnBasedMatchLeftListener, OnTurnBasedMatchUpdateReceivedListener, OnTurnBasedMatchUpdatedListener, OnTurnBasedMatchesLoadedListener {}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\turnbased\TurnBasedMultiplayerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */