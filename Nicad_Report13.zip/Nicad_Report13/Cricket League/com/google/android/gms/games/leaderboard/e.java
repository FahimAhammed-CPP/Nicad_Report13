package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.b;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.d;

public final class e extends b implements LeaderboardScore {
  private final d vU;
  
  e(DataHolder paramDataHolder, int paramInt) {
    super(paramDataHolder, paramInt);
    this.vU = new d(paramDataHolder, paramInt);
  }
  
  public LeaderboardScore ds() {
    return new d(this);
  }
  
  public boolean equals(Object paramObject) {
    return d.a(this, paramObject);
  }
  
  public String getDisplayRank() {
    return getString("display_rank");
  }
  
  public void getDisplayRank(CharArrayBuffer paramCharArrayBuffer) {
    a("display_rank", paramCharArrayBuffer);
  }
  
  public String getDisplayScore() {
    return getString("display_score");
  }
  
  public void getDisplayScore(CharArrayBuffer paramCharArrayBuffer) {
    a("display_score", paramCharArrayBuffer);
  }
  
  public long getRank() {
    return getLong("rank");
  }
  
  public long getRawScore() {
    return getLong("raw_score");
  }
  
  public Player getScoreHolder() {
    return (Player)(M("external_player_id") ? null : this.vU);
  }
  
  public String getScoreHolderDisplayName() {
    return M("external_player_id") ? getString("default_display_name") : this.vU.getDisplayName();
  }
  
  public void getScoreHolderDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    if (M("external_player_id")) {
      a("default_display_name", paramCharArrayBuffer);
      return;
    } 
    this.vU.getDisplayName(paramCharArrayBuffer);
  }
  
  public Uri getScoreHolderHiResImageUri() {
    return M("external_player_id") ? null : this.vU.getHiResImageUri();
  }
  
  public Uri getScoreHolderIconImageUri() {
    return M("external_player_id") ? L("default_display_image_uri") : this.vU.getIconImageUri();
  }
  
  public String getScoreTag() {
    return getString("score_tag");
  }
  
  public long getTimestampMillis() {
    return getLong("achieved_timestamp");
  }
  
  public int hashCode() {
    return d.a(this);
  }
  
  public String toString() {
    return d.b(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */