package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.fc;
import java.util.ArrayList;
import java.util.Collection;

public final class a implements Leaderboard {
  private final String qa;
  
  private final Uri sL;
  
  private final String vD;
  
  private final int vE;
  
  private final ArrayList<f> vF;
  
  private final Game vG;
  
  public a(Leaderboard paramLeaderboard) {
    GameEntity gameEntity;
    this.vD = paramLeaderboard.getLeaderboardId();
    this.qa = paramLeaderboard.getDisplayName();
    this.sL = paramLeaderboard.getIconImageUri();
    this.vE = paramLeaderboard.getScoreOrder();
    Game game = paramLeaderboard.getGame();
    if (game == null) {
      game = null;
    } else {
      gameEntity = new GameEntity(game);
    } 
    this.vG = (Game)gameEntity;
    ArrayList<LeaderboardVariant> arrayList = paramLeaderboard.getVariants();
    int j = arrayList.size();
    this.vF = new ArrayList<f>(j);
    for (int i = 0; i < j; i++)
      this.vF.add((f)((LeaderboardVariant)arrayList.get(i)).freeze()); 
  }
  
  static int a(Leaderboard paramLeaderboard) {
    return ee.hashCode(new Object[] { paramLeaderboard.getLeaderboardId(), paramLeaderboard.getDisplayName(), paramLeaderboard.getIconImageUri(), Integer.valueOf(paramLeaderboard.getScoreOrder()), paramLeaderboard.getVariants() });
  }
  
  static boolean a(Leaderboard paramLeaderboard, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof Leaderboard))
      return false; 
    boolean bool1 = bool2;
    if (paramLeaderboard != paramObject) {
      paramObject = paramObject;
      if (ee.equal(paramObject.getLeaderboardId(), paramLeaderboard.getLeaderboardId()) && ee.equal(paramObject.getDisplayName(), paramLeaderboard.getDisplayName()) && ee.equal(paramObject.getIconImageUri(), paramLeaderboard.getIconImageUri()) && ee.equal(Integer.valueOf(paramObject.getScoreOrder()), Integer.valueOf(paramLeaderboard.getScoreOrder()))) {
        bool1 = bool2;
        return !ee.equal(paramObject.getVariants(), paramLeaderboard.getVariants()) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(Leaderboard paramLeaderboard) {
    return ee.e(paramLeaderboard).a("LeaderboardId", paramLeaderboard.getLeaderboardId()).a("DisplayName", paramLeaderboard.getDisplayName()).a("IconImageUri", paramLeaderboard.getIconImageUri()).a("ScoreOrder", Integer.valueOf(paramLeaderboard.getScoreOrder())).a("Variants", paramLeaderboard.getVariants()).toString();
  }
  
  public Leaderboard dp() {
    return this;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public String getDisplayName() {
    return this.qa;
  }
  
  public void getDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    fc.b(this.qa, paramCharArrayBuffer);
  }
  
  public Game getGame() {
    return this.vG;
  }
  
  public Uri getIconImageUri() {
    return this.sL;
  }
  
  public String getLeaderboardId() {
    return this.vD;
  }
  
  public int getScoreOrder() {
    return this.vE;
  }
  
  public ArrayList<LeaderboardVariant> getVariants() {
    return new ArrayList<LeaderboardVariant>((Collection)this.vF);
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */