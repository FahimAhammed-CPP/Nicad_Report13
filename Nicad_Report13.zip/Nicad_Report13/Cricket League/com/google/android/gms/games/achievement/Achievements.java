package com.google.android.gms.games.achievement;

import android.content.Intent;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;

public interface Achievements {
  Intent getAchievementsIntent(GoogleApiClient paramGoogleApiClient);
  
  void increment(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt);
  
  PendingResult<UpdateAchievementResult> incrementImmediate(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt);
  
  PendingResult<LoadAchievementsResult> load(GoogleApiClient paramGoogleApiClient, boolean paramBoolean);
  
  void reveal(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<UpdateAchievementResult> revealImmediate(GoogleApiClient paramGoogleApiClient, String paramString);
  
  void setSteps(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt);
  
  PendingResult<UpdateAchievementResult> setStepsImmediate(GoogleApiClient paramGoogleApiClient, String paramString, int paramInt);
  
  void unlock(GoogleApiClient paramGoogleApiClient, String paramString);
  
  PendingResult<UpdateAchievementResult> unlockImmediate(GoogleApiClient paramGoogleApiClient, String paramString);
  
  public static interface LoadAchievementsResult extends Releasable, Result {
    AchievementBuffer getAchievements();
  }
  
  public static interface UpdateAchievementResult extends Result {
    String getAchievementId();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\achievement\Achievements.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */