package com.google.android.gms.games.multiplayer;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.fm;
import java.util.ArrayList;
import java.util.Collection;

public final class InvitationEntity extends fm implements Invitation {
  public static final Parcelable.Creator<InvitationEntity> CREATOR = new a();
  
  private final int kg;
  
  private final String uf;
  
  private final GameEntity wj;
  
  private final long wk;
  
  private final int wl;
  
  private final ParticipantEntity wm;
  
  private final ArrayList<ParticipantEntity> wn;
  
  private final int wo;
  
  private final int wp;
  
  InvitationEntity(int paramInt1, GameEntity paramGameEntity, String paramString, long paramLong, int paramInt2, ParticipantEntity paramParticipantEntity, ArrayList<ParticipantEntity> paramArrayList, int paramInt3, int paramInt4) {
    this.kg = paramInt1;
    this.wj = paramGameEntity;
    this.uf = paramString;
    this.wk = paramLong;
    this.wl = paramInt2;
    this.wm = paramParticipantEntity;
    this.wn = paramArrayList;
    this.wo = paramInt3;
    this.wp = paramInt4;
  }
  
  InvitationEntity(Invitation paramInvitation) {
    Participant participant;
    this.kg = 2;
    this.wj = new GameEntity(paramInvitation.getGame());
    this.uf = paramInvitation.getInvitationId();
    this.wk = paramInvitation.getCreationTimestamp();
    this.wl = paramInvitation.getInvitationType();
    this.wo = paramInvitation.getVariant();
    this.wp = paramInvitation.getAvailableAutoMatchSlots();
    String str = paramInvitation.getInviter().getParticipantId();
    Invitation invitation = null;
    ArrayList<Participant> arrayList = paramInvitation.getParticipants();
    int j = arrayList.size();
    this.wn = new ArrayList<ParticipantEntity>(j);
    int i = 0;
    paramInvitation = invitation;
    while (i < j) {
      Participant participant1 = arrayList.get(i);
      if (participant1.getParticipantId().equals(str))
        participant = participant1; 
      this.wn.add((ParticipantEntity)participant1.freeze());
      i++;
    } 
    eg.b(participant, "Must have a valid inviter!");
    this.wm = (ParticipantEntity)participant.freeze();
  }
  
  static int a(Invitation paramInvitation) {
    return ee.hashCode(new Object[] { paramInvitation.getGame(), paramInvitation.getInvitationId(), Long.valueOf(paramInvitation.getCreationTimestamp()), Integer.valueOf(paramInvitation.getInvitationType()), paramInvitation.getInviter(), paramInvitation.getParticipants(), Integer.valueOf(paramInvitation.getVariant()), Integer.valueOf(paramInvitation.getAvailableAutoMatchSlots()) });
  }
  
  static boolean a(Invitation paramInvitation, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof Invitation))
      return false; 
    boolean bool1 = bool2;
    if (paramInvitation != paramObject) {
      paramObject = paramObject;
      if (ee.equal(paramObject.getGame(), paramInvitation.getGame()) && ee.equal(paramObject.getInvitationId(), paramInvitation.getInvitationId()) && ee.equal(Long.valueOf(paramObject.getCreationTimestamp()), Long.valueOf(paramInvitation.getCreationTimestamp())) && ee.equal(Integer.valueOf(paramObject.getInvitationType()), Integer.valueOf(paramInvitation.getInvitationType())) && ee.equal(paramObject.getInviter(), paramInvitation.getInviter()) && ee.equal(paramObject.getParticipants(), paramInvitation.getParticipants()) && ee.equal(Integer.valueOf(paramObject.getVariant()), Integer.valueOf(paramInvitation.getVariant()))) {
        bool1 = bool2;
        return !ee.equal(Integer.valueOf(paramObject.getAvailableAutoMatchSlots()), Integer.valueOf(paramInvitation.getAvailableAutoMatchSlots())) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(Invitation paramInvitation) {
    return ee.e(paramInvitation).a("Game", paramInvitation.getGame()).a("InvitationId", paramInvitation.getInvitationId()).a("CreationTimestamp", Long.valueOf(paramInvitation.getCreationTimestamp())).a("InvitationType", Integer.valueOf(paramInvitation.getInvitationType())).a("Inviter", paramInvitation.getInviter()).a("Participants", paramInvitation.getParticipants()).a("Variant", Integer.valueOf(paramInvitation.getVariant())).a("AvailableAutoMatchSlots", Integer.valueOf(paramInvitation.getAvailableAutoMatchSlots())).toString();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public Invitation freeze() {
    return this;
  }
  
  public int getAvailableAutoMatchSlots() {
    return this.wp;
  }
  
  public long getCreationTimestamp() {
    return this.wk;
  }
  
  public Game getGame() {
    return (Game)this.wj;
  }
  
  public String getInvitationId() {
    return this.uf;
  }
  
  public int getInvitationType() {
    return this.wl;
  }
  
  public Participant getInviter() {
    return this.wm;
  }
  
  public ArrayList<Participant> getParticipants() {
    return new ArrayList<Participant>((Collection)this.wn);
  }
  
  public int getVariant() {
    return this.wo;
  }
  
  public int getVersionCode() {
    return this.kg;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    if (!bN()) {
      a.a(this, paramParcel, paramInt);
      return;
    } 
    this.wj.writeToParcel(paramParcel, paramInt);
    paramParcel.writeString(this.uf);
    paramParcel.writeLong(this.wk);
    paramParcel.writeInt(this.wl);
    this.wm.writeToParcel(paramParcel, paramInt);
    int j = this.wn.size();
    paramParcel.writeInt(j);
    int i = 0;
    while (true) {
      if (i < j) {
        ((ParticipantEntity)this.wn.get(i)).writeToParcel(paramParcel, paramInt);
        i++;
        continue;
      } 
      return;
    } 
  }
  
  static final class a extends a {
    public InvitationEntity aa(Parcel param1Parcel) {
      if (InvitationEntity.b(InvitationEntity.da()) || InvitationEntity.ad(InvitationEntity.class.getCanonicalName()))
        return super.aa(param1Parcel); 
      GameEntity gameEntity = (GameEntity)GameEntity.CREATOR.createFromParcel(param1Parcel);
      String str = param1Parcel.readString();
      long l = param1Parcel.readLong();
      int j = param1Parcel.readInt();
      ParticipantEntity participantEntity = (ParticipantEntity)ParticipantEntity.CREATOR.createFromParcel(param1Parcel);
      int k = param1Parcel.readInt();
      ArrayList<Object> arrayList = new ArrayList(k);
      for (int i = 0; i < k; i++)
        arrayList.add(ParticipantEntity.CREATOR.createFromParcel(param1Parcel)); 
      return new InvitationEntity(2, gameEntity, str, l, j, participantEntity, (ArrayList)arrayList, -1, 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\InvitationEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */