package com.google.android.gms.games.leaderboard;

@Deprecated
public interface OnLeaderboardScoresLoadedListener {
  void onLeaderboardScoresLoaded(int paramInt, Leaderboard paramLeaderboard, LeaderboardScoreBuffer paramLeaderboardScoreBuffer);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\leaderboard\OnLeaderboardScoresLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */