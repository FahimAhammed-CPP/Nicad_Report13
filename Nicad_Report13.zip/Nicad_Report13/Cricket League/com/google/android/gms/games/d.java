package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.text.TextUtils;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.b;

public final class d extends b implements Player {
  private final a tG;
  
  public d(DataHolder paramDataHolder, int paramInt) {
    this(paramDataHolder, paramInt, (String)null);
  }
  
  public d(DataHolder paramDataHolder, int paramInt, String paramString) {
    super(paramDataHolder, paramInt);
    this.tG = new a(paramString);
  }
  
  public int db() {
    return getInteger(this.tG.tM);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    return PlayerEntity.a(this, paramObject);
  }
  
  public Player freeze() {
    return new PlayerEntity(this);
  }
  
  public String getDisplayName() {
    return getString(this.tG.tI);
  }
  
  public void getDisplayName(CharArrayBuffer paramCharArrayBuffer) {
    a(this.tG.tI, paramCharArrayBuffer);
  }
  
  public Uri getHiResImageUri() {
    return L(this.tG.tK);
  }
  
  public Uri getIconImageUri() {
    return L(this.tG.tJ);
  }
  
  public long getLastPlayedWithTimestamp() {
    return !hasColumn(this.tG.tN) ? -1L : getLong(this.tG.tN);
  }
  
  public String getPlayerId() {
    return getString(this.tG.tH);
  }
  
  public long getRetrievedTimestamp() {
    return getLong(this.tG.tL);
  }
  
  public boolean hasHiResImage() {
    return (getHiResImageUri() != null);
  }
  
  public boolean hasIconImage() {
    return (getIconImageUri() != null);
  }
  
  public int hashCode() {
    return PlayerEntity.a(this);
  }
  
  public String toString() {
    return PlayerEntity.b(this);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ((PlayerEntity)freeze()).writeToParcel(paramParcel, paramInt);
  }
  
  private static final class a {
    public final String tH;
    
    public final String tI;
    
    public final String tJ;
    
    public final String tK;
    
    public final String tL;
    
    public final String tM;
    
    public final String tN;
    
    public a(String param1String) {
      if (TextUtils.isEmpty(param1String)) {
        this.tH = "external_player_id";
        this.tI = "profile_name";
        this.tJ = "profile_icon_image_uri";
        this.tK = "profile_hi_res_image_uri";
        this.tL = "last_updated";
        this.tM = "is_in_circles";
        this.tN = "played_with_timestamp";
        return;
      } 
      this.tH = param1String + "external_player_id";
      this.tI = param1String + "profile_name";
      this.tJ = param1String + "profile_icon_image_uri";
      this.tK = param1String + "profile_hi_res_image_uri";
      this.tL = param1String + "last_updated";
      this.tM = param1String + "is_in_circles";
      this.tN = param1String + "played_with_timestamp";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */