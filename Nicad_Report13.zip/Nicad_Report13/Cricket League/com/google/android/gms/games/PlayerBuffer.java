package com.google.android.gms.games;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;

public final class PlayerBuffer extends DataBuffer<Player> {
  public PlayerBuffer(DataHolder paramDataHolder) {
    super(paramDataHolder);
  }
  
  public Player get(int paramInt) {
    return new d(this.nE, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\PlayerBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */