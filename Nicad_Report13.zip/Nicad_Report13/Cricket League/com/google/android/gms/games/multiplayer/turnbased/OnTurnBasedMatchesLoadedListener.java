package com.google.android.gms.games.multiplayer.turnbased;

@Deprecated
public interface OnTurnBasedMatchesLoadedListener {
  void onTurnBasedMatchesLoaded(int paramInt, LoadMatchesResponse paramLoadMatchesResponse);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\games\multiplayer\turnbased\OnTurnBasedMatchesLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */