package com.google.android.gms.dynamic;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.common.GooglePlayServicesUtil;
import java.util.Iterator;
import java.util.LinkedList;

public abstract class a<T extends LifecycleDelegate> {
  private T ss;
  
  private Bundle st;
  
  private LinkedList<a> su;
  
  private final d<T> sv = new d<T>(this) {
      public void a(T param1T) {
        a.a(this.sw, (LifecycleDelegate)param1T);
        Iterator<a.a> iterator = a.a(this.sw).iterator();
        while (iterator.hasNext())
          ((a.a)iterator.next()).b(a.b(this.sw)); 
        a.a(this.sw).clear();
        a.a(this.sw, (Bundle)null);
      }
    };
  
  private void a(Bundle paramBundle, a parama) {
    if (this.ss != null) {
      parama.b((LifecycleDelegate)this.ss);
      return;
    } 
    if (this.su == null)
      this.su = new LinkedList<a>(); 
    this.su.add(parama);
    if (paramBundle != null)
      if (this.st == null) {
        this.st = (Bundle)paramBundle.clone();
      } else {
        this.st.putAll(paramBundle);
      }  
    a(this.sv);
  }
  
  private void ay(int paramInt) {
    while (!this.su.isEmpty() && ((a)this.su.getLast()).getState() >= paramInt)
      this.su.removeLast(); 
  }
  
  public void a(FrameLayout paramFrameLayout) {
    Context context = paramFrameLayout.getContext();
    int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(context);
    String str2 = GooglePlayServicesUtil.b(context, i, -1);
    String str1 = GooglePlayServicesUtil.b(context, i);
    LinearLayout linearLayout = new LinearLayout(paramFrameLayout.getContext());
    linearLayout.setOrientation(1);
    linearLayout.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
    paramFrameLayout.addView((View)linearLayout);
    TextView textView = new TextView(paramFrameLayout.getContext());
    textView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
    textView.setText(str2);
    linearLayout.addView((View)textView);
    if (str1 != null) {
      Button button = new Button(context);
      button.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2));
      button.setText(str1);
      linearLayout.addView((View)button);
      button.setOnClickListener(new View.OnClickListener(this, context, i) {
            public void onClick(View param1View) {
              this.hF.startActivity(GooglePlayServicesUtil.a(this.hF, this.sD, -1));
            }
          });
    } 
  }
  
  protected abstract void a(d<T> paramd);
  
  public T cZ() {
    return this.ss;
  }
  
  public void onCreate(Bundle paramBundle) {
    a(paramBundle, new a(this, paramBundle) {
          public void b(LifecycleDelegate param1LifecycleDelegate) {
            a.b(this.sw).onCreate(this.sz);
          }
          
          public int getState() {
            return 1;
          }
        });
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    FrameLayout frameLayout = new FrameLayout(paramLayoutInflater.getContext());
    a(paramBundle, new a(this, frameLayout, paramLayoutInflater, paramViewGroup, paramBundle) {
          public void b(LifecycleDelegate param1LifecycleDelegate) {
            this.sA.removeAllViews();
            this.sA.addView(a.b(this.sw).onCreateView(this.sB, this.sC, this.sz));
          }
          
          public int getState() {
            return 2;
          }
        });
    if (this.ss == null)
      a(frameLayout); 
    return (View)frameLayout;
  }
  
  public void onDestroy() {
    if (this.ss != null) {
      this.ss.onDestroy();
      return;
    } 
    ay(1);
  }
  
  public void onDestroyView() {
    if (this.ss != null) {
      this.ss.onDestroyView();
      return;
    } 
    ay(2);
  }
  
  public void onInflate(Activity paramActivity, Bundle paramBundle1, Bundle paramBundle2) {
    a(paramBundle2, new a(this, paramActivity, paramBundle1, paramBundle2) {
          public void b(LifecycleDelegate param1LifecycleDelegate) {
            a.b(this.sw).onInflate(this.sx, this.sy, this.sz);
          }
          
          public int getState() {
            return 0;
          }
        });
  }
  
  public void onLowMemory() {
    if (this.ss != null)
      this.ss.onLowMemory(); 
  }
  
  public void onPause() {
    if (this.ss != null) {
      this.ss.onPause();
      return;
    } 
    ay(3);
  }
  
  public void onResume() {
    a((Bundle)null, new a(this) {
          public void b(LifecycleDelegate param1LifecycleDelegate) {
            a.b(this.sw).onResume();
          }
          
          public int getState() {
            return 3;
          }
        });
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    if (this.ss != null) {
      this.ss.onSaveInstanceState(paramBundle);
      return;
    } 
    if (this.st != null) {
      paramBundle.putAll(this.st);
      return;
    } 
  }
  
  private static interface a {
    void b(LifecycleDelegate param1LifecycleDelegate);
    
    int getState();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\dynamic\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */