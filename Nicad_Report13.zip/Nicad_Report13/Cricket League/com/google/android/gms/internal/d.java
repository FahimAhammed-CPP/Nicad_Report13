package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;

public interface d {
  String a(Context paramContext);
  
  String a(Context paramContext, String paramString);
  
  void a(int paramInt1, int paramInt2, int paramInt3);
  
  void a(MotionEvent paramMotionEvent);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */