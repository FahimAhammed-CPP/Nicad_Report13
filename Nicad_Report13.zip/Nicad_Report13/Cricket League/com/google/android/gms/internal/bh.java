package com.google.android.gms.internal;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

public final class bh {
  public static boolean a(Context paramContext, bj parambj, bq parambq) {
    if (parambj == null) {
      ct.v("No intent data for launcher overlay.");
      return false;
    } 
    Intent intent = new Intent();
    if (TextUtils.isEmpty(parambj.go)) {
      ct.v("Open GMSG did not contain a URL.");
      return false;
    } 
    if (!TextUtils.isEmpty(parambj.mimeType)) {
      intent.setDataAndType(Uri.parse(parambj.go), parambj.mimeType);
    } else {
      intent.setData(Uri.parse(parambj.go));
    } 
    intent.setAction("android.intent.action.VIEW");
    if (!TextUtils.isEmpty(parambj.packageName))
      intent.setPackage(parambj.packageName); 
    if (!TextUtils.isEmpty(parambj.gp)) {
      String[] arrayOfString = parambj.gp.split("/", 2);
      if (arrayOfString.length < 2) {
        ct.v("Could not parse component name from open GMSG: " + parambj.gp);
        return false;
      } 
      intent.setClassName(arrayOfString[0], arrayOfString[1]);
    } 
    try {
      ct.u("Launching an intent: " + intent);
      paramContext.startActivity(intent);
      parambq.z();
      return true;
    } catch (ActivityNotFoundException activityNotFoundException) {
      ct.v(activityNotFoundException.getMessage());
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */