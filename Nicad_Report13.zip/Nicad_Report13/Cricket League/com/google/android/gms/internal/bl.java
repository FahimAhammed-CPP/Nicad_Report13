package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bl implements Parcelable.Creator<bm> {
  static void a(bm parambm, Parcel paramParcel, int paramInt) {
    int i = b.o(paramParcel);
    b.c(paramParcel, 1, parambm.versionCode);
    b.a(paramParcel, 2, (Parcelable)parambm.gG, paramInt, false);
    b.a(paramParcel, 3, parambm.aa(), false);
    b.a(paramParcel, 4, parambm.ab(), false);
    b.a(paramParcel, 5, parambm.ac(), false);
    b.a(paramParcel, 6, parambm.ad(), false);
    b.a(paramParcel, 7, parambm.gL, false);
    b.a(paramParcel, 8, parambm.gM);
    b.a(paramParcel, 9, parambm.gN, false);
    b.a(paramParcel, 10, parambm.ae(), false);
    b.c(paramParcel, 11, parambm.orientation);
    b.c(paramParcel, 12, parambm.gP);
    b.a(paramParcel, 13, parambm.go, false);
    b.a(paramParcel, 14, (Parcelable)parambm.ej, paramInt, false);
    b.D(paramParcel, i);
  }
  
  public bm e(Parcel paramParcel) {
    int m = a.n(paramParcel);
    int k = 0;
    bj bj = null;
    IBinder iBinder5 = null;
    IBinder iBinder4 = null;
    IBinder iBinder3 = null;
    IBinder iBinder2 = null;
    String str3 = null;
    boolean bool = false;
    String str2 = null;
    IBinder iBinder1 = null;
    int j = 0;
    int i = 0;
    String str1 = null;
    cu cu = null;
    while (paramParcel.dataPosition() < m) {
      int n = a.m(paramParcel);
      switch (a.M(n)) {
        case 1:
          k = a.g(paramParcel, n);
          break;
        case 2:
          bj = (bj)a.a(paramParcel, n, bj.CREATOR);
          break;
        case 3:
          iBinder5 = a.n(paramParcel, n);
          break;
        case 4:
          iBinder4 = a.n(paramParcel, n);
          break;
        case 5:
          iBinder3 = a.n(paramParcel, n);
          break;
        case 6:
          iBinder2 = a.n(paramParcel, n);
          break;
        case 7:
          str3 = a.m(paramParcel, n);
          break;
        case 8:
          bool = a.c(paramParcel, n);
          break;
        case 9:
          str2 = a.m(paramParcel, n);
          break;
        case 10:
          iBinder1 = a.n(paramParcel, n);
          break;
        case 11:
          j = a.g(paramParcel, n);
          break;
        case 12:
          i = a.g(paramParcel, n);
          break;
        case 13:
          str1 = a.m(paramParcel, n);
          break;
        case 14:
          cu = (cu)a.a(paramParcel, n, cu.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new a.a("Overread allowed size end=" + m, paramParcel); 
    return new bm(k, bj, iBinder5, iBinder4, iBinder3, iBinder2, str3, bool, str2, iBinder1, j, i, str1, cu);
  }
  
  public bm[] j(int paramInt) {
    return new bm[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */