package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.common.images.WebImage;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class dp {
  private static final dk lA = new dk("MetadataUtils");
  
  private static final String[] mx = new String[] { "Z", "+hh", "+hhmm", "+hh:mm" };
  
  private static final String my = "yyyyMMdd'T'HHmmss" + mx[0];
  
  public static Calendar G(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      lA.b("Input string is empty or null", new Object[0]);
      return null;
    } 
    String str2 = H(paramString);
    if (TextUtils.isEmpty(str2)) {
      lA.b("Invalid date format", new Object[0]);
      return null;
    } 
    String str3 = I(paramString);
    paramString = "yyyyMMdd";
    String str1 = str2;
    if (!TextUtils.isEmpty(str3)) {
      str1 = str2 + "T" + str3;
      if (str3.length() == "HHmmss".length()) {
        paramString = "yyyyMMdd'T'HHmmss";
      } else {
        paramString = my;
      } 
    } 
    Calendar calendar = GregorianCalendar.getInstance();
    try {
      Date date = (new SimpleDateFormat(paramString)).parse(str1);
      calendar.setTime(date);
      return calendar;
    } catch (ParseException parseException) {
      lA.b("Error parsing string: %s", new Object[] { parseException.getMessage() });
      return null;
    } 
  }
  
  private static String H(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      lA.b("Input string is empty or null", new Object[0]);
      return null;
    } 
    try {
      return paramString.substring(0, "yyyyMMdd".length());
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      lA.c("Error extracting the date: %s", new Object[] { indexOutOfBoundsException.getMessage() });
      return null;
    } 
  }
  
  private static String I(String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      lA.b("string is empty or null", new Object[0]);
      return null;
    } 
    int i = paramString.indexOf('T');
    if (i != "yyyyMMdd".length()) {
      lA.b("T delimeter is not found", new Object[0]);
      return null;
    } 
    try {
      paramString = paramString.substring(i + 1);
      if (paramString.length() == "HHmmss".length())
        return paramString; 
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      lA.b("Error extracting the time substring: %s", new Object[] { indexOutOfBoundsException.getMessage() });
      return null;
    } 
    switch (indexOutOfBoundsException.charAt("HHmmss".length())) {
      default:
        return null;
      case '+':
      case '-':
        return J((String)indexOutOfBoundsException) ? indexOutOfBoundsException.replaceAll("([\\+\\-]\\d\\d):(\\d\\d)", "$1$2") : null;
      case 'Z':
        break;
    } 
    return (indexOutOfBoundsException.length() == "HHmmss".length() + mx[0].length()) ? (indexOutOfBoundsException.substring(0, indexOutOfBoundsException.length() - 1) + "+0000") : null;
  }
  
  private static boolean J(String paramString) {
    int i = paramString.length();
    int j = "HHmmss".length();
    return (i == mx[1].length() + j || i == mx[2].length() + j || i == j + mx[3].length());
  }
  
  public static String a(Calendar paramCalendar) {
    if (paramCalendar == null) {
      lA.b("Calendar object cannot be null", new Object[0]);
      return null;
    } 
    String str4 = my;
    String str3 = str4;
    if (paramCalendar.get(11) == 0) {
      str3 = str4;
      if (paramCalendar.get(12) == 0) {
        str3 = str4;
        if (paramCalendar.get(13) == 0)
          str3 = "yyyyMMdd"; 
      } 
    } 
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str3);
    simpleDateFormat.setTimeZone(paramCalendar.getTimeZone());
    String str2 = simpleDateFormat.format(paramCalendar.getTime());
    String str1 = str2;
    return str2.endsWith("+0000") ? str2.replace("+0000", mx[0]) : str1;
  }
  
  public static void a(List<WebImage> paramList, JSONObject paramJSONObject) {
    try {
      paramList.clear();
      JSONArray jSONArray = paramJSONObject.getJSONArray("images");
      int j = jSONArray.length();
      int i = 0;
      while (true) {
        if (i < j) {
          JSONObject jSONObject = jSONArray.getJSONObject(i);
          try {
            paramList.add(new WebImage(jSONObject));
          } catch (IllegalArgumentException illegalArgumentException) {}
          i++;
          continue;
        } 
        return;
      } 
    } catch (JSONException jSONException) {}
  }
  
  public static void a(JSONObject paramJSONObject, List<WebImage> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      JSONArray jSONArray = new JSONArray();
      Iterator<WebImage> iterator = paramList.iterator();
      while (iterator.hasNext())
        jSONArray.put(((WebImage)iterator.next()).aP()); 
      try {
        paramJSONObject.put("images", jSONArray);
        return;
      } catch (JSONException jSONException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */