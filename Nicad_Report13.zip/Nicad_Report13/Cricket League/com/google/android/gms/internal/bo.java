package com.google.android.gms.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.VideoView;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public final class bo extends FrameLayout implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener {
  private final MediaController gQ;
  
  private final a gR;
  
  private final VideoView gS;
  
  private long gT;
  
  private String gU;
  
  private final cw gv;
  
  public bo(Context paramContext, cw paramcw) {
    super(paramContext);
    this.gv = paramcw;
    this.gS = new VideoView(paramContext);
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
    addView((View)this.gS, (ViewGroup.LayoutParams)layoutParams);
    this.gQ = new MediaController(paramContext);
    this.gR = new a(this);
    this.gR.ah();
    this.gS.setOnCompletionListener(this);
    this.gS.setOnPreparedListener(this);
    this.gS.setOnErrorListener(this);
  }
  
  private static void a(cw paramcw, String paramString) {
    a(paramcw, paramString, new HashMap<String, String>(1));
  }
  
  public static void a(cw paramcw, String paramString1, String paramString2) {
    boolean bool;
    byte b;
    if (paramString2 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      b = 2;
    } else {
      b = 3;
    } 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(b);
    hashMap.put("what", paramString1);
    if (!bool)
      hashMap.put("extra", paramString2); 
    a(paramcw, "error", (Map)hashMap);
  }
  
  private static void a(cw paramcw, String paramString1, String paramString2, String paramString3) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(2);
    hashMap.put(paramString2, paramString3);
    a(paramcw, paramString1, (Map)hashMap);
  }
  
  private static void a(cw paramcw, String paramString, Map<String, String> paramMap) {
    paramMap.put("event", paramString);
    paramcw.a("onVideoEvent", paramMap);
  }
  
  public void af() {
    if (!TextUtils.isEmpty(this.gU)) {
      this.gS.setVideoPath(this.gU);
      return;
    } 
    a(this.gv, "no_src", (String)null);
  }
  
  public void ag() {
    long l = this.gS.getCurrentPosition();
    if (this.gT != l) {
      float f = (float)l / 1000.0F;
      a(this.gv, "timeupdate", "time", String.valueOf(f));
      this.gT = l;
    } 
  }
  
  public void b(MotionEvent paramMotionEvent) {
    this.gS.dispatchTouchEvent(paramMotionEvent);
  }
  
  public void destroy() {
    this.gR.cancel();
    this.gS.stopPlayback();
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean) {
      this.gS.setMediaController(this.gQ);
      return;
    } 
    this.gQ.hide();
    this.gS.setMediaController(null);
  }
  
  public void n(String paramString) {
    this.gU = paramString;
  }
  
  public void onCompletion(MediaPlayer paramMediaPlayer) {
    a(this.gv, "ended");
  }
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2) {
    a(this.gv, String.valueOf(paramInt1), String.valueOf(paramInt2));
    return true;
  }
  
  public void onPrepared(MediaPlayer paramMediaPlayer) {
    float f = this.gS.getDuration() / 1000.0F;
    a(this.gv, "canplaythrough", "duration", String.valueOf(f));
  }
  
  public void pause() {
    this.gS.pause();
  }
  
  public void play() {
    this.gS.start();
  }
  
  public void seekTo(int paramInt) {
    this.gS.seekTo(paramInt);
  }
  
  private static final class a {
    private final Runnable ep;
    
    private volatile boolean gV = false;
    
    public a(bo param1bo) {
      this.ep = new Runnable(this, param1bo) {
          private final WeakReference<bo> gW = new WeakReference<bo>(this.gX);
          
          public void run() {
            bo bo1 = this.gW.get();
            if (!bo.a.a(this.gY) && bo1 != null) {
              bo1.ag();
              this.gY.ah();
            } 
          }
        };
    }
    
    public void ah() {
      cs.iI.postDelayed(this.ep, 250L);
    }
    
    public void cancel() {
      this.gV = true;
      cs.iI.removeCallbacks(this.ep);
    }
  }
  
  class null implements Runnable {
    private final WeakReference<bo> gW = new WeakReference<bo>(this.gX);
    
    null(bo this$0, bo param1bo) {}
    
    public void run() {
      bo bo1 = this.gW.get();
      if (!bo.a.a(this.gY) && bo1 != null) {
        bo1.ag();
        this.gY.ah();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */