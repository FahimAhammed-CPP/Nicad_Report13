package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface cd extends IInterface {
  cb b(bz parambz) throws RemoteException;
  
  public static abstract class a extends Binder implements cd {
    public a() {
      attachInterface(this, "com.google.android.gms.ads.internal.request.IAdRequestService");
    }
    
    public static cd q(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
      return (iInterface != null && iInterface instanceof cd) ? (cd)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.request.IAdRequestService");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.request.IAdRequestService");
      if (param1Parcel1.readInt() != 0) {
        bz bz = bz.CREATOR.f(param1Parcel1);
      } else {
        param1Parcel1 = null;
      } 
      cb cb = b((bz)param1Parcel1);
      param1Parcel2.writeNoException();
      if (cb != null) {
        param1Parcel2.writeInt(1);
        cb.writeToParcel(param1Parcel2, 1);
        return true;
      } 
      param1Parcel2.writeInt(0);
      return true;
    }
    
    private static class a implements cd {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public cb b(bz param2bz) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
          if (param2bz != null) {
            parcel1.writeInt(1);
            param2bz.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.dU.transact(1, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2bz = null;
        parcel2.recycle();
        parcel1.recycle();
        return (cb)param2bz;
      }
    }
  }
  
  private static class a implements cd {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public cb b(bz param1bz) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.request.IAdRequestService");
        if (param1bz != null) {
          parcel1.writeInt(1);
          param1bz.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.dU.transact(1, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1bz = null;
      parcel2.recycle();
      parcel1.recycle();
      return (cb)param1bz;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */