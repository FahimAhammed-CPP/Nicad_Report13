package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public final class ce extends cd.a {
  private static final Object hC = new Object();
  
  private static ce hD;
  
  private final aq hE;
  
  private final Context mContext;
  
  private ce(Context paramContext, aq paramaq) {
    this.mContext = paramContext;
    this.hE = paramaq;
  }
  
  private static cb a(Context paramContext, aq paramaq, bz parambz) {
    ct.r("Starting ad request from service.");
    paramaq.init();
    ci ci = new ci(paramContext);
    if (ci.ik == -1) {
      ct.r("Device is offline.");
      return new cb(2);
    } 
    cg cg = new cg(parambz.applicationInfo.packageName);
    if (parambz.hr.extras != null) {
      String str1 = parambz.hr.extras.getString("_ad");
      if (str1 != null)
        return cf.a(paramContext, parambz, str1); 
    } 
    String str = cf.a(parambz, ci, paramaq.a(250L));
    if (str == null)
      return new cb(0); 
    cs.iI.post(new Runnable(paramContext, parambz, cg, str) {
          public void run() {
            cw cw = cw.a(this.hF, new x(), false, false, (h)null, this.hG.ej);
            cw.setWillNotDraw(true);
            this.hH.b(cw);
            cx cx = cw.aC();
            cx.a("/invalidRequest", this.hH.hM);
            cx.a("/loadAdURL", this.hH.hN);
            cx.a("/log", am.fs);
            ct.r("Getting the ad request URL.");
            cw.loadDataWithBaseURL("http://googleads.g.doubleclick.net", "<!DOCTYPE html><html><head><script src=\"http://googleads.g.doubleclick.net/mads/static/sdk/native/sdk-core-v40.js\"></script><script>AFMA_buildAdURL(" + this.hI + ");</script></head><body></body></html>", "text/html", "UTF-8", null);
          }
        });
    str = cg.ap();
    return TextUtils.isEmpty(str) ? new cb(cg.getErrorCode()) : a(paramContext, parambz.ej.iJ, str);
  }
  
  public static cb a(Context paramContext, String paramString1, String paramString2) {
    try {
      ch ch = new ch();
      URL uRL = new URL(paramString2);
      int i = 0;
      while (true) {
        HttpURLConnection httpURLConnection = (HttpURLConnection)uRL.openConnection();
        try {
          co.a(paramContext, paramString1, false, httpURLConnection);
          int j = httpURLConnection.getResponseCode();
          Map<String, List<String>> map = httpURLConnection.getHeaderFields();
          if (j >= 200 && j < 300) {
            String str = uRL.toString();
            paramString1 = co.a(new InputStreamReader(httpURLConnection.getInputStream()));
            a(str, map, paramString1, j);
            ch.a(str, map, paramString1);
            return ch.aq();
          } 
          a(uRL.toString(), map, null, j);
          if (j >= 300 && j < 400) {
            String str = httpURLConnection.getHeaderField("Location");
            if (TextUtils.isEmpty(str)) {
              ct.v("No location header to follow redirect.");
              return new cb(0);
            } 
            URL uRL1 = new URL(str);
            if (++i > 5) {
              ct.v("Too many redirects.");
              return new cb(0);
            } 
          } else {
            ct.v("Received error HTTP response code: " + j);
            return new cb(0);
          } 
          ch.d(map);
        } finally {
          httpURLConnection.disconnect();
        } 
      } 
    } catch (IOException iOException) {
      ct.v("Error while connecting to ad server: " + iOException.getMessage());
      return new cb(2);
    } 
  }
  
  public static ce a(Context paramContext, aq paramaq) {
    synchronized (hC) {
      if (hD == null)
        hD = new ce(paramContext.getApplicationContext(), paramaq); 
      return hD;
    } 
  }
  
  private static void a(String paramString1, Map<String, List<String>> paramMap, String paramString2, int paramInt) {
    if (ct.n(2)) {
      ct.u("Http Response: {\n  URL:\n    " + paramString1 + "\n  Headers:");
      if (paramMap != null)
        for (String str : paramMap.keySet()) {
          ct.u("    " + str + ":");
          for (String str1 : paramMap.get(str))
            ct.u("      " + str1); 
        }  
      ct.u("  Body:");
      if (paramString2 != null) {
        int i;
        for (i = 0; i < Math.min(paramString2.length(), 100000); i += 1000)
          ct.u(paramString2.substring(i, Math.min(paramString2.length(), i + 1000))); 
      } else {
        ct.u("    null");
      } 
      ct.u("  Response Code:\n    " + paramInt + "\n}");
    } 
  }
  
  public cb b(bz parambz) {
    return a(this.mContext, this.hE, parambz);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */