package com.google.android.gms.internal;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.util.HashMap;
import java.util.Map;

public final class am {
  public static final an fn = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        String str = param1Map.get("urls");
        if (str == null) {
          ct.v("URLs missing in canOpenURLs GMSG.");
          return;
        } 
        String[] arrayOfString = str.split(",");
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        PackageManager packageManager = param1cw.getContext().getPackageManager();
        int j = arrayOfString.length;
        for (int i = 0; i < j; i++) {
          String str1;
          boolean bool;
          String str2 = arrayOfString[i];
          String[] arrayOfString1 = str2.split(";", 2);
          String str3 = arrayOfString1[0].trim();
          if (arrayOfString1.length > 1) {
            str1 = arrayOfString1[1].trim();
          } else {
            str1 = "android.intent.action.VIEW";
          } 
          if (packageManager.resolveActivity(new Intent(str1, Uri.parse(str3)), 65536) != null) {
            bool = true;
          } else {
            bool = false;
          } 
          hashMap.put(str2, Boolean.valueOf(bool));
        } 
        param1cw.a("openableURLs", (Map)hashMap);
      }
    };
  
  public static final an fo = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        String str2 = param1Map.get("u");
        if (str2 == null) {
          ct.v("URL missing from click GMSG.");
          return;
        } 
        Uri uri = Uri.parse(str2);
        try {
          h h = param1cw.aD();
          if (h != null && h.a(uri)) {
            Uri uri1 = h.a(uri, param1cw.getContext());
            uri = uri1;
          } 
        } catch (i i) {
          ct.v("Unable to append parameter to URL: " + str2);
        } 
        String str1 = uri.toString();
        (new cr(param1cw.getContext(), (param1cw.aE()).iJ, str1)).start();
      }
    };
  
  public static final an fp = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        bk bk = param1cw.aB();
        if (bk == null) {
          ct.v("A GMSG tried to close something that wasn't an overlay.");
          return;
        } 
        bk.close();
      }
    };
  
  public static final an fq = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        bk bk = param1cw.aB();
        if (bk == null) {
          ct.v("A GMSG tried to use a custom close button on something that wasn't an overlay.");
          return;
        } 
        bk.g("1".equals(param1Map.get("custom_close")));
      }
    };
  
  public static final an fr = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        String str = param1Map.get("u");
        if (str == null) {
          ct.v("URL missing from httpTrack GMSG.");
          return;
        } 
        (new cr(param1cw.getContext(), (param1cw.aE()).iJ, str)).start();
      }
    };
  
  public static final an fs = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        ct.t("Received log message: " + (String)param1Map.get("string"));
      }
    };
  
  public static final an ft = new ao();
  
  public static final an fu = new an() {
      public void a(cw param1cw, Map<String, String> param1Map) {
        String str2 = param1Map.get("tx");
        String str3 = param1Map.get("ty");
        String str1 = param1Map.get("td");
        try {
          int i = Integer.parseInt(str2);
          int j = Integer.parseInt(str3);
          int k = Integer.parseInt(str1);
          h h = param1cw.aD();
          if (h != null)
            h.g().a(i, j, k); 
          return;
        } catch (NumberFormatException numberFormatException) {
          ct.v("Could not parse touch parameters from gmsg.");
          return;
        } 
      }
    };
  
  public static final an fv = new ap();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */