package com.google.android.gms.internal;

import android.location.Location;

public interface aq {
  Location a(long paramLong);
  
  void init();
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */