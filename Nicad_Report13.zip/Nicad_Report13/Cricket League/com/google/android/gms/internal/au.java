package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class au {
  public final List<at> fI;
  
  public final long fJ;
  
  public final List<String> fK;
  
  public final List<String> fL;
  
  public final List<String> fM;
  
  public final String fN;
  
  public final long fO;
  
  public au(String paramString) throws JSONException {
    JSONObject jSONObject = new JSONObject(paramString);
    if (ct.n(2))
      ct.u("Mediation Response JSON: " + jSONObject.toString(2)); 
    JSONArray jSONArray = jSONObject.getJSONArray("ad_networks");
    ArrayList<at> arrayList = new ArrayList(jSONArray.length());
    for (int i = 0; i < jSONArray.length(); i++)
      arrayList.add(new at(jSONArray.getJSONObject(i))); 
    this.fI = Collections.unmodifiableList(arrayList);
    this.fN = jSONObject.getString("qdata");
    jSONObject = jSONObject.optJSONObject("settings");
    if (jSONObject != null) {
      this.fJ = jSONObject.optLong("ad_network_timeout_millis", -1L);
      this.fK = az.a(jSONObject, "click_urls");
      this.fL = az.a(jSONObject, "imp_urls");
      this.fM = az.a(jSONObject, "nofill_urls");
      long l = jSONObject.optLong("refresh", -1L);
      if (l > 0L) {
        l *= 1000L;
      } else {
        l = -1L;
      } 
      this.fO = l;
      return;
    } 
    this.fJ = -1L;
    this.fK = null;
    this.fL = null;
    this.fM = null;
    this.fO = -1L;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\au.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */