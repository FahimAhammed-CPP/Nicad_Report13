package com.google.android.gms.internal;

import java.util.Map;

public final class ak implements an {
  private final al fm;
  
  public ak(al paramal) {
    this.fm = paramal;
  }
  
  public void a(cw paramcw, Map<String, String> paramMap) {
    String str = paramMap.get("name");
    if (str == null) {
      ct.v("App event with no name parameter.");
      return;
    } 
    this.fm.onAppEvent(str, paramMap.get("info"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */