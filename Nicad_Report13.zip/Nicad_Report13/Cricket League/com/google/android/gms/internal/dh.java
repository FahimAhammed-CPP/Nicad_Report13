package com.google.android.gms.internal;

public final class dh {
  public static <T> boolean a(T paramT1, T paramT2) {
    return ((paramT1 == null && paramT2 == null) || (paramT1 != null && paramT2 != null && paramT1.equals(paramT2)));
  }
  
  public static long b(double paramDouble) {
    return (long)(1000.0D * paramDouble);
  }
  
  public static double h(long paramLong) {
    return paramLong / 1000.0D;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */