package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.cast.ApplicationMetadata;

public interface dj extends IInterface {
  void a(ApplicationMetadata paramApplicationMetadata, String paramString1, String paramString2, boolean paramBoolean) throws RemoteException;
  
  void a(String paramString, long paramLong) throws RemoteException;
  
  void a(String paramString, long paramLong, int paramInt) throws RemoteException;
  
  void a(String paramString1, String paramString2) throws RemoteException;
  
  void b(String paramString, double paramDouble, boolean paramBoolean) throws RemoteException;
  
  void b(String paramString, byte[] paramArrayOfbyte) throws RemoteException;
  
  void onApplicationDisconnected(int paramInt) throws RemoteException;
  
  void t(int paramInt) throws RemoteException;
  
  void u(int paramInt) throws RemoteException;
  
  void v(int paramInt) throws RemoteException;
  
  void w(int paramInt) throws RemoteException;
  
  public static abstract class a extends Binder implements dj {
    public a() {
      attachInterface(this, "com.google.android.gms.cast.internal.ICastDeviceControllerListener");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      String str1;
      double d;
      String str2;
      String str3;
      boolean bool2 = false;
      boolean bool1 = false;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          t(param1Parcel1.readInt());
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          if (param1Parcel1.readInt() != 0) {
            ApplicationMetadata applicationMetadata = (ApplicationMetadata)ApplicationMetadata.CREATOR.createFromParcel(param1Parcel1);
          } else {
            param1Parcel2 = null;
          } 
          str2 = param1Parcel1.readString();
          str3 = param1Parcel1.readString();
          if (param1Parcel1.readInt() != 0)
            bool1 = true; 
          a((ApplicationMetadata)param1Parcel2, str2, str3, bool1);
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          u(param1Parcel1.readInt());
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          str1 = param1Parcel1.readString();
          d = param1Parcel1.readDouble();
          bool1 = bool2;
          if (param1Parcel1.readInt() != 0)
            bool1 = true; 
          b(str1, d, bool1);
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          a(param1Parcel1.readString(), param1Parcel1.readString());
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          b(param1Parcel1.readString(), param1Parcel1.createByteArray());
          return true;
        case 7:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          w(param1Parcel1.readInt());
          return true;
        case 8:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          v(param1Parcel1.readInt());
          return true;
        case 9:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          onApplicationDisconnected(param1Parcel1.readInt());
          return true;
        case 10:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
          a(param1Parcel1.readString(), param1Parcel1.readLong(), param1Parcel1.readInt());
          return true;
        case 11:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
      a(param1Parcel1.readString(), param1Parcel1.readLong());
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */