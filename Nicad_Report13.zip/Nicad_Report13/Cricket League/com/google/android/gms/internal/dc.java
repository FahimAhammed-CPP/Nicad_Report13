package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.AppStateManager;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

public final class dc extends dw<de> {
  private final String jG;
  
  @Deprecated
  public dc(Context paramContext, GooglePlayServicesClient.ConnectionCallbacks paramConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString, String[] paramArrayOfString) {
    this(paramContext, new dw.c(paramConnectionCallbacks), new dw.g(paramOnConnectionFailedListener), paramString, paramArrayOfString);
  }
  
  public dc(Context paramContext, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String paramString, String[] paramArrayOfString) {
    super(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, paramArrayOfString);
    this.jG = eg.<String>f(paramString);
  }
  
  public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateListResult> paramc) {
    try {
      bQ().a(new c(this, paramc));
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult> paramc, int paramInt) {
    try {
      bQ().b(new a(this, paramc), paramInt);
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateResult> paramc, int paramInt, String paramString, byte[] paramArrayOfbyte) {
    try {
      bQ().a(new e(this, paramc), paramInt, paramString, paramArrayOfbyte);
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateResult> paramc, int paramInt, byte[] paramArrayOfbyte) {
    e e;
    if (paramc == null) {
      paramc = null;
    } else {
      e = new e(this, paramc);
    } 
    try {
      bQ().a(e, paramInt, paramArrayOfbyte);
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  protected void a(ec paramec, dw.e parame) throws RemoteException {
    paramec.a(parame, 4242000, getContext().getPackageName(), this.jG, bO());
  }
  
  protected void a(String... paramVarArgs) {
    int i = 0;
    boolean bool = false;
    while (i < paramVarArgs.length) {
      if (paramVarArgs[i].equals("https://www.googleapis.com/auth/appstate"))
        bool = true; 
      i++;
    } 
    eg.a(bool, String.format("App State APIs requires %s to function.", new Object[] { "https://www.googleapis.com/auth/appstate" }));
  }
  
  protected String am() {
    return "com.google.android.gms.appstate.service.START";
  }
  
  protected String an() {
    return "com.google.android.gms.appstate.internal.IAppStateService";
  }
  
  public void b(com.google.android.gms.common.api.a.c<Status> paramc) {
    try {
      bQ().b(new g(this, paramc));
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  public void b(com.google.android.gms.common.api.a.c<AppStateManager.StateResult> paramc, int paramInt) {
    try {
      bQ().a(new e(this, paramc), paramInt);
      return;
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return;
    } 
  }
  
  public int getMaxNumKeys() {
    try {
      return bQ().getMaxNumKeys();
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return 2;
    } 
  }
  
  public int getMaxStateSize() {
    try {
      return bQ().getMaxStateSize();
    } catch (RemoteException remoteException) {
      Log.w("AppStateClient", "service died");
      return 2;
    } 
  }
  
  protected de r(IBinder paramIBinder) {
    return de.a.t(paramIBinder);
  }
  
  final class a extends db {
    private final com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult> jW;
    
    public a(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult> param1c) {
      this.jW = eg.<com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult>>b(param1c, "Result holder must not be null");
    }
    
    public void onStateDeleted(int param1Int1, int param1Int2) {
      Status status = new Status(param1Int1);
      this.jX.a(new dc.b(this.jX, this.jW, status, param1Int2));
    }
  }
  
  final class b extends dw<de>.b<com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult>> implements AppStateManager.StateDeletedResult {
    private final Status jY;
    
    private final int jZ;
    
    public b(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult> param1c, Status param1Status, int param1Int) {
      super(this$0, param1c);
      this.jY = param1Status;
      this.jZ = param1Int;
    }
    
    protected void aL() {}
    
    public void c(com.google.android.gms.common.api.a.c<AppStateManager.StateDeletedResult> param1c) {
      param1c.a(this);
    }
    
    public int getStateKey() {
      return this.jZ;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
  
  final class c extends db {
    private final com.google.android.gms.common.api.a.c<AppStateManager.StateListResult> jW;
    
    public c(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateListResult> param1c) {
      this.jW = eg.<com.google.android.gms.common.api.a.c<AppStateManager.StateListResult>>b(param1c, "Result holder must not be null");
    }
    
    public void a(DataHolder param1DataHolder) {
      Status status = new Status(param1DataHolder.getStatusCode());
      this.jX.a(new dc.d(this.jX, this.jW, status, param1DataHolder));
    }
  }
  
  final class d extends dw<de>.d<com.google.android.gms.common.api.a.c<AppStateManager.StateListResult>> implements AppStateManager.StateListResult {
    private final Status jY;
    
    private final AppStateBuffer ka;
    
    public d(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateListResult> param1c, Status param1Status, DataHolder param1DataHolder) {
      super(this$0, param1c, param1DataHolder);
      this.jY = param1Status;
      this.ka = new AppStateBuffer(param1DataHolder);
    }
    
    public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateListResult> param1c, DataHolder param1DataHolder) {
      param1c.a(this);
    }
    
    public AppStateBuffer getStateBuffer() {
      return this.ka;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
  
  final class e extends db {
    private final com.google.android.gms.common.api.a.c<AppStateManager.StateResult> jW;
    
    public e(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateResult> param1c) {
      this.jW = eg.<com.google.android.gms.common.api.a.c<AppStateManager.StateResult>>b(param1c, "Result holder must not be null");
    }
    
    public void a(int param1Int, DataHolder param1DataHolder) {
      this.jX.a(new dc.f(this.jX, this.jW, param1Int, param1DataHolder));
    }
  }
  
  final class f extends dw<de>.d<com.google.android.gms.common.api.a.c<AppStateManager.StateResult>> implements AppStateManager.StateConflictResult, AppStateManager.StateLoadedResult, AppStateManager.StateResult {
    private final Status jY;
    
    private final int jZ;
    
    private final AppStateBuffer ka;
    
    public f(dc this$0, com.google.android.gms.common.api.a.c<AppStateManager.StateResult> param1c, int param1Int, DataHolder param1DataHolder) {
      super(this$0, param1c, param1DataHolder);
      this.jZ = param1Int;
      this.jY = new Status(param1DataHolder.getStatusCode());
      this.ka = new AppStateBuffer(param1DataHolder);
    }
    
    private boolean aM() {
      return (this.jY.getStatusCode() == 2000);
    }
    
    public void a(com.google.android.gms.common.api.a.c<AppStateManager.StateResult> param1c, DataHolder param1DataHolder) {
      param1c.a(this);
    }
    
    public AppStateManager.StateConflictResult getConflictResult() {
      return aM() ? this : null;
    }
    
    public AppStateManager.StateLoadedResult getLoadedResult() {
      f f1 = this;
      if (aM())
        f1 = null; 
      return f1;
    }
    
    public byte[] getLocalData() {
      return (this.ka.getCount() == 0) ? null : this.ka.get(0).getLocalData();
    }
    
    public String getResolvedVersion() {
      return (this.ka.getCount() == 0) ? null : this.ka.get(0).getConflictVersion();
    }
    
    public byte[] getServerData() {
      return (this.ka.getCount() == 0) ? null : this.ka.get(0).getConflictData();
    }
    
    public int getStateKey() {
      return this.jZ;
    }
    
    public Status getStatus() {
      return this.jY;
    }
  }
  
  final class g extends db {
    com.google.android.gms.common.api.a.c<Status> jW;
    
    public g(dc this$0, com.google.android.gms.common.api.a.c<Status> param1c) {
      this.jW = eg.<com.google.android.gms.common.api.a.c<Status>>b(param1c, "Holder must not be null");
    }
    
    public void onSignOutComplete() {
      Status status = new Status(0);
      this.jX.a(new dc.h(this.jX, this.jW, status));
    }
  }
  
  final class h extends dw<de>.b<com.google.android.gms.common.api.a.c<Status>> {
    private final Status jY;
    
    public h(dc this$0, com.google.android.gms.common.api.a.c<Status> param1c, Status param1Status) {
      super(this$0, param1c);
      this.jY = param1Status;
    }
    
    protected void aL() {}
    
    public void c(com.google.android.gms.common.api.a.c<Status> param1c) {
      param1c.a(this.jY);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */