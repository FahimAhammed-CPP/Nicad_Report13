package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class at {
  public final String adJson;
  
  public final String fD;
  
  public final List<String> fE;
  
  public final String fF;
  
  public final List<String> fG;
  
  public final String fH;
  
  public at(JSONObject paramJSONObject) throws JSONException {
    String str;
    this.fD = paramJSONObject.getString("id");
    JSONArray jSONArray = paramJSONObject.getJSONArray("adapters");
    ArrayList<String> arrayList = new ArrayList(jSONArray.length());
    for (int i = 0; i < jSONArray.length(); i++)
      arrayList.add(jSONArray.getString(i)); 
    this.fE = Collections.unmodifiableList(arrayList);
    this.fF = paramJSONObject.optString("allocation_id", null);
    this.fG = az.a(paramJSONObject, "imp_urls");
    JSONObject jSONObject1 = paramJSONObject.optJSONObject("ad");
    if (jSONObject1 != null) {
      String str1 = jSONObject1.toString();
    } else {
      jSONObject1 = null;
    } 
    this.adJson = (String)jSONObject1;
    jSONObject1 = paramJSONObject.optJSONObject("data");
    paramJSONObject = jSONObject2;
    if (jSONObject1 != null)
      str = jSONObject1.toString(); 
    this.fH = str;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */