package com.google.android.gms.internal;

public abstract class cm {
  private final Runnable ep = new Runnable(this) {
      public final void run() {
        cm.a(this.iy, Thread.currentThread());
        this.iy.ai();
      }
    };
  
  private volatile Thread ix;
  
  public abstract void ai();
  
  public final void cancel() {
    onStop();
    if (this.ix != null)
      this.ix.interrupt(); 
  }
  
  public abstract void onStop();
  
  public final void start() {
    cn.execute(this.ep);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */