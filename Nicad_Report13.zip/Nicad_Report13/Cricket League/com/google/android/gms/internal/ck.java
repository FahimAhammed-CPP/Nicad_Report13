package com.google.android.gms.internal;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public final class ck {
  private static final Object hC;
  
  public static final String iu;
  
  private static BigInteger iv;
  
  static {
    UUID uUID = UUID.randomUUID();
    byte[] arrayOfByte1 = BigInteger.valueOf(uUID.getLeastSignificantBits()).toByteArray();
    byte[] arrayOfByte2 = BigInteger.valueOf(uUID.getMostSignificantBits()).toByteArray();
    String str = (new BigInteger(1, arrayOfByte1)).toString();
    int i = 0;
    while (true) {
      if (i < 2) {
        try {
          MessageDigest messageDigest = MessageDigest.getInstance("MD5");
          messageDigest.update(arrayOfByte1);
          messageDigest.update(arrayOfByte2);
          byte[] arrayOfByte = new byte[8];
          System.arraycopy(messageDigest.digest(), 0, arrayOfByte, 0, 8);
          String str1 = (new BigInteger(1, arrayOfByte)).toString();
          str = str1;
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
        i++;
        continue;
      } 
      iu = str;
      hC = new Object();
      iv = BigInteger.ONE;
      return;
    } 
  }
  
  public static String ar() {
    synchronized (hC) {
      String str = iv.toString();
      iv.add(BigInteger.ONE);
      return str;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */