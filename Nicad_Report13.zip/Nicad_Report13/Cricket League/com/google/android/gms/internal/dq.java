package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

public final class dq extends Drawable implements Drawable.Callback {
  private int oB = 0;
  
  private long oC;
  
  private int oD;
  
  private int oE;
  
  private int oF = 255;
  
  private int oG;
  
  private int oH = 0;
  
  private boolean oI;
  
  private b oJ;
  
  private Drawable oK;
  
  private Drawable oL;
  
  private boolean oM;
  
  private boolean oN;
  
  private boolean oO;
  
  private int oP;
  
  private boolean oy = true;
  
  public dq(Drawable paramDrawable1, Drawable paramDrawable2) {
    this((b)null);
    Drawable drawable2 = paramDrawable1;
    if (paramDrawable1 == null)
      drawable2 = a.bD(); 
    this.oK = drawable2;
    drawable2.setCallback(this);
    b b1 = this.oJ;
    b1.oT |= drawable2.getChangingConfigurations();
    Drawable drawable1 = paramDrawable2;
    if (paramDrawable2 == null)
      drawable1 = a.bD(); 
    this.oL = drawable1;
    drawable1.setCallback(this);
    b b2 = this.oJ;
    b2.oT |= drawable1.getChangingConfigurations();
  }
  
  dq(b paramb) {
    this.oJ = new b(paramb);
  }
  
  public Drawable bC() {
    return this.oL;
  }
  
  public boolean canConstantState() {
    if (!this.oM) {
      boolean bool;
      if (this.oK.getConstantState() != null && this.oL.getConstantState() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.oN = bool;
      this.oM = true;
    } 
    return this.oN;
  }
  
  public void draw(Canvas paramCanvas) {
    boolean bool;
    Drawable drawable1;
    Drawable drawable2;
    int j = 1;
    int i = 1;
    byte b1 = 0;
    switch (this.oB) {
      default:
        j = this.oH;
        bool = this.oy;
        drawable1 = this.oK;
        drawable2 = this.oL;
        if (i) {
          if (!bool || j == 0)
            drawable1.draw(paramCanvas); 
          if (j == this.oF) {
            drawable2.setAlpha(this.oF);
            drawable2.draw(paramCanvas);
          } 
          return;
        } 
        break;
      case 1:
        this.oC = SystemClock.uptimeMillis();
        this.oB = 2;
        i = b1;
      case 2:
        if (this.oC >= 0L) {
          float f1 = (float)(SystemClock.uptimeMillis() - this.oC) / this.oG;
          if (f1 >= 1.0F) {
            i = j;
          } else {
            i = 0;
          } 
          if (i != 0)
            this.oB = 0; 
          f1 = Math.min(f1, 1.0F);
          float f2 = this.oD;
          this.oH = (int)(f1 * (this.oE - this.oD) + f2);
        } 
    } 
    if (bool)
      drawable1.setAlpha(this.oF - j); 
    drawable1.draw(paramCanvas);
    if (bool)
      drawable1.setAlpha(this.oF); 
    if (j > 0) {
      drawable2.setAlpha(j);
      drawable2.draw(paramCanvas);
      drawable2.setAlpha(this.oF);
    } 
    invalidateSelf();
  }
  
  public int getChangingConfigurations() {
    return super.getChangingConfigurations() | this.oJ.oS | this.oJ.oT;
  }
  
  public Drawable.ConstantState getConstantState() {
    if (canConstantState()) {
      this.oJ.oS = getChangingConfigurations();
      return this.oJ;
    } 
    return null;
  }
  
  public int getIntrinsicHeight() {
    return Math.max(this.oK.getIntrinsicHeight(), this.oL.getIntrinsicHeight());
  }
  
  public int getIntrinsicWidth() {
    return Math.max(this.oK.getIntrinsicWidth(), this.oL.getIntrinsicWidth());
  }
  
  public int getOpacity() {
    if (!this.oO) {
      this.oP = Drawable.resolveOpacity(this.oK.getOpacity(), this.oL.getOpacity());
      this.oO = true;
    } 
    return this.oP;
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    if (fg.cD()) {
      Drawable.Callback callback = getCallback();
      if (callback != null)
        callback.invalidateDrawable(this); 
    } 
  }
  
  public Drawable mutate() {
    if (!this.oI && super.mutate() == this) {
      if (!canConstantState())
        throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated."); 
      this.oK.mutate();
      this.oL.mutate();
      this.oI = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    this.oK.setBounds(paramRect);
    this.oL.setBounds(paramRect);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    if (fg.cD()) {
      Drawable.Callback callback = getCallback();
      if (callback != null)
        callback.scheduleDrawable(this, paramRunnable, paramLong); 
    } 
  }
  
  public void setAlpha(int paramInt) {
    if (this.oH == this.oF)
      this.oH = paramInt; 
    this.oF = paramInt;
    invalidateSelf();
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.oK.setColorFilter(paramColorFilter);
    this.oL.setColorFilter(paramColorFilter);
  }
  
  public void startTransition(int paramInt) {
    this.oD = 0;
    this.oE = this.oF;
    this.oH = 0;
    this.oG = paramInt;
    this.oB = 1;
    invalidateSelf();
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    if (fg.cD()) {
      Drawable.Callback callback = getCallback();
      if (callback != null)
        callback.unscheduleDrawable(this, paramRunnable); 
    } 
  }
  
  private static final class a extends Drawable {
    private static final a oQ = new a();
    
    private static final a oR = new a();
    
    public void draw(Canvas param1Canvas) {}
    
    public Drawable.ConstantState getConstantState() {
      return oR;
    }
    
    public int getOpacity() {
      return -2;
    }
    
    public void setAlpha(int param1Int) {}
    
    public void setColorFilter(ColorFilter param1ColorFilter) {}
    
    private static final class a extends Drawable.ConstantState {
      private a() {}
      
      public int getChangingConfigurations() {
        return 0;
      }
      
      public Drawable newDrawable() {
        return dq.a.bD();
      }
    }
  }
  
  private static final class a extends Drawable.ConstantState {
    private a() {}
    
    public int getChangingConfigurations() {
      return 0;
    }
    
    public Drawable newDrawable() {
      return dq.a.bD();
    }
  }
  
  static final class b extends Drawable.ConstantState {
    int oS;
    
    int oT;
    
    b(b param1b) {
      if (param1b != null) {
        this.oS = param1b.oS;
        this.oT = param1b.oT;
      } 
    }
    
    public int getChangingConfigurations() {
      return this.oS;
    }
    
    public Drawable newDrawable() {
      return new dq(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */