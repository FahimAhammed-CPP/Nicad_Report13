package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.ads.AdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

public final class bf<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
  private final bd gi;
  
  public bf(bd parambd) {
    this.gi = parambd;
  }
  
  public void onClick(MediationBannerAdapter<?, ?> paramMediationBannerAdapter) {
    ct.r("Adapter called onClick.");
    if (!cs.ay()) {
      ct.v("onClick must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).w();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdClicked.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.w();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdClicked.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onDismissScreen(MediationBannerAdapter<?, ?> paramMediationBannerAdapter) {
    ct.r("Adapter called onDismissScreen.");
    if (!cs.ay()) {
      ct.v("onDismissScreen must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdClosed();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdClosed.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdClosed();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdClosed.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onDismissScreen(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter) {
    ct.r("Adapter called onDismissScreen.");
    if (!cs.ay()) {
      ct.v("onDismissScreen must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdClosed();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdClosed.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdClosed();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdClosed.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> paramMediationBannerAdapter, AdRequest.ErrorCode paramErrorCode) {
    ct.r("Adapter called onFailedToReceiveAd with error. " + paramErrorCode);
    if (!cs.ay()) {
      ct.v("onFailedToReceiveAd must be called on the main UI thread.");
      cs.iI.post(new Runnable(this, paramErrorCode) {
            public void run() {
              try {
                bf.a(this.gj).onAdFailedToLoad(bg.a(this.gk));
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdFailedToLoad.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdFailedToLoad(bg.a(paramErrorCode));
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdFailedToLoad.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter, AdRequest.ErrorCode paramErrorCode) {
    ct.r("Adapter called onFailedToReceiveAd with error " + paramErrorCode + ".");
    if (!cs.ay()) {
      ct.v("onFailedToReceiveAd must be called on the main UI thread.");
      cs.iI.post(new Runnable(this, paramErrorCode) {
            public void run() {
              try {
                bf.a(this.gj).onAdFailedToLoad(bg.a(this.gk));
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdFailedToLoad.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdFailedToLoad(bg.a(paramErrorCode));
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdFailedToLoad.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onLeaveApplication(MediationBannerAdapter<?, ?> paramMediationBannerAdapter) {
    ct.r("Adapter called onLeaveApplication.");
    if (!cs.ay()) {
      ct.v("onLeaveApplication must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdLeftApplication();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdLeftApplication.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdLeftApplication();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdLeftApplication.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onLeaveApplication(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter) {
    ct.r("Adapter called onLeaveApplication.");
    if (!cs.ay()) {
      ct.v("onLeaveApplication must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdLeftApplication();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdLeftApplication.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdLeftApplication();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdLeftApplication.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onPresentScreen(MediationBannerAdapter<?, ?> paramMediationBannerAdapter) {
    ct.r("Adapter called onPresentScreen.");
    if (!cs.ay()) {
      ct.v("onPresentScreen must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdOpened();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdOpened.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdOpened();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdOpened.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onPresentScreen(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter) {
    ct.r("Adapter called onPresentScreen.");
    if (!cs.ay()) {
      ct.v("onPresentScreen must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdOpened();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdOpened.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdOpened();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdOpened.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onReceivedAd(MediationBannerAdapter<?, ?> paramMediationBannerAdapter) {
    ct.r("Adapter called onReceivedAd.");
    if (!cs.ay()) {
      ct.v("onReceivedAd must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdLoaded();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdLoaded.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdLoaded();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdLoaded.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void onReceivedAd(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter) {
    ct.r("Adapter called onReceivedAd.");
    if (!cs.ay()) {
      ct.v("onReceivedAd must be called on the main UI thread.");
      cs.iI.post(new Runnable(this) {
            public void run() {
              try {
                bf.a(this.gj).onAdLoaded();
                return;
              } catch (RemoteException remoteException) {
                ct.b("Could not call onAdLoaded.", (Throwable)remoteException);
                return;
              } 
            }
          });
      return;
    } 
    try {
      this.gi.onAdLoaded();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Could not call onAdLoaded.", (Throwable)remoteException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */