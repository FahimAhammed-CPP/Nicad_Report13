package com.google.android.gms.internal;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public final class ch {
  private String hP;
  
  private String hQ;
  
  private String hR;
  
  private List<String> hS;
  
  private List<String> hT;
  
  private long hU = -1L;
  
  private boolean hV = false;
  
  private final long hW = -1L;
  
  private List<String> hX;
  
  private long hY = -1L;
  
  private int mOrientation = -1;
  
  private static long a(Map<String, List<String>> paramMap, String paramString) {
    List<String> list = paramMap.get(paramString);
    if (list != null && !list.isEmpty()) {
      String str = list.get(0);
      try {
        float f = Float.parseFloat(str);
        return (long)(f * 1000.0F);
      } catch (NumberFormatException numberFormatException) {
        ct.v("Could not parse float from " + paramString + " header: " + str);
      } 
    } 
    return -1L;
  }
  
  private static List<String> b(Map<String, List<String>> paramMap, String paramString) {
    List<String> list = paramMap.get(paramString);
    if (list != null && !list.isEmpty()) {
      String str = list.get(0);
      if (str != null)
        return Arrays.asList(str.trim().split("\\s+")); 
    } 
    return null;
  }
  
  private void e(Map<String, List<String>> paramMap) {
    List<String> list = paramMap.get("X-Afma-Ad-Size");
    if (list != null && !list.isEmpty())
      this.hP = list.get(0); 
  }
  
  private void f(Map<String, List<String>> paramMap) {
    List<String> list = b(paramMap, "X-Afma-Click-Tracking-Urls");
    if (list != null)
      this.hS = list; 
  }
  
  private void g(Map<String, List<String>> paramMap) {
    List<String> list = b(paramMap, "X-Afma-Tracking-Urls");
    if (list != null)
      this.hT = list; 
  }
  
  private void h(Map<String, List<String>> paramMap) {
    long l = a(paramMap, "X-Afma-Interstitial-Timeout");
    if (l != -1L)
      this.hU = l; 
  }
  
  private void i(Map<String, List<String>> paramMap) {
    List<String> list = paramMap.get("X-Afma-Mediation");
    if (list != null && !list.isEmpty())
      this.hV = Boolean.valueOf(list.get(0)).booleanValue(); 
  }
  
  private void j(Map<String, List<String>> paramMap) {
    List<String> list = b(paramMap, "X-Afma-Manual-Tracking-Urls");
    if (list != null)
      this.hX = list; 
  }
  
  private void k(Map<String, List<String>> paramMap) {
    long l = a(paramMap, "X-Afma-Refresh-Rate");
    if (l != -1L)
      this.hY = l; 
  }
  
  private void l(Map<String, List<String>> paramMap) {
    String str;
    List<String> list = paramMap.get("X-Afma-Orientation");
    if (list != null && !list.isEmpty()) {
      str = list.get(0);
      if ("portrait".equalsIgnoreCase(str)) {
        this.mOrientation = co.av();
        return;
      } 
    } else {
      return;
    } 
    if ("landscape".equalsIgnoreCase(str)) {
      this.mOrientation = co.au();
      return;
    } 
  }
  
  public void a(String paramString1, Map<String, List<String>> paramMap, String paramString2) {
    this.hQ = paramString1;
    this.hR = paramString2;
    d(paramMap);
  }
  
  public cb aq() {
    return new cb(this.hQ, this.hR, this.hS, this.hT, this.hU, this.hV, -1L, this.hX, this.hY, this.mOrientation, this.hP);
  }
  
  public void d(Map<String, List<String>> paramMap) {
    e(paramMap);
    f(paramMap);
    g(paramMap);
    h(paramMap);
    i(paramMap);
    j(paramMap);
    k(paramMap);
    l(paramMap);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */