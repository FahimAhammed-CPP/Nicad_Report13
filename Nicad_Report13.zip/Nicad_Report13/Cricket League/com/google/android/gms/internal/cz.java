package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public final class cz extends cx {
  public cz(cw paramcw, boolean paramBoolean) {
    super(paramcw, paramBoolean);
  }
  
  private static WebResourceResponse d(Context paramContext, String paramString1, String paramString2) throws IOException {
    HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(paramString2)).openConnection();
    try {
      co.a(paramContext, paramString1, true, httpURLConnection);
      httpURLConnection.connect();
      return new WebResourceResponse("application/javascript", "UTF-8", new ByteArrayInputStream(co.a(new InputStreamReader(httpURLConnection.getInputStream())).getBytes("UTF-8")));
    } finally {
      httpURLConnection.disconnect();
    } 
  }
  
  public WebResourceResponse shouldInterceptRequest(WebView paramWebView, String paramString) {
    try {
      if (!"mraid.js".equalsIgnoreCase((new File(paramString)).getName()))
        return super.shouldInterceptRequest(paramWebView, paramString); 
      if (!(paramWebView instanceof cw)) {
        ct.v("Tried to intercept request from a WebView that wasn't an AdWebView.");
        return super.shouldInterceptRequest(paramWebView, paramString);
      } 
      cw cw = (cw)paramWebView;
      cw.aC().Y();
      if ((cw.y()).eG) {
        ct.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_interstitial.js)");
        return d(cw.getContext(), (this.gv.aE()).iJ, "http://media.admob.com/mraid/v1/mraid_app_interstitial.js");
      } 
      if (cw.aF()) {
        ct.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_expanded_banner.js)");
        return d(cw.getContext(), (this.gv.aE()).iJ, "http://media.admob.com/mraid/v1/mraid_app_expanded_banner.js");
      } 
      ct.u("shouldInterceptRequest(http://media.admob.com/mraid/v1/mraid_app_banner.js)");
      return d(cw.getContext(), (this.gv.aE()).iJ, "http://media.admob.com/mraid/v1/mraid_app_banner.js");
    } catch (IOException iOException) {
      ct.v("Could not fetching MRAID JS. " + iOException.getMessage());
      return super.shouldInterceptRequest(paramWebView, paramString);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cz.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */