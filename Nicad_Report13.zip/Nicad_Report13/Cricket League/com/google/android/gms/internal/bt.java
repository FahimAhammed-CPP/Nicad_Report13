package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.b;

public interface bt extends IInterface {
  IBinder a(b paramb) throws RemoteException;
  
  public static abstract class a extends Binder implements bt {
    public static bt n(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
      return (iInterface != null && iInterface instanceof bt) ? (bt)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
      IBinder iBinder = a(b.a.E(param1Parcel1.readStrongBinder()));
      param1Parcel2.writeNoException();
      param1Parcel2.writeStrongBinder(iBinder);
      return true;
    }
    
    private static class a implements bt {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public IBinder a(b param2b) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
          if (param2b != null) {
            IBinder iBinder = param2b.asBinder();
            parcel1.writeStrongBinder(iBinder);
            this.dU.transact(1, parcel1, parcel2, 0);
            parcel2.readException();
            iBinder = parcel2.readStrongBinder();
            return iBinder;
          } 
          param2b = null;
          parcel1.writeStrongBinder((IBinder)param2b);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readStrongBinder();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
    }
  }
  
  private static class a implements bt {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public IBinder a(b param1b) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.ads.internal.overlay.client.IAdOverlayCreator");
        if (param1b != null) {
          IBinder iBinder = param1b.asBinder();
          parcel1.writeStrongBinder(iBinder);
          this.dU.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          iBinder = parcel2.readStrongBinder();
          return iBinder;
        } 
        param1b = null;
        parcel1.writeStrongBinder((IBinder)param1b);
        this.dU.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readStrongBinder();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */