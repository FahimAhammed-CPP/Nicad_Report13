package com.google.android.gms.internal;

import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.a;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public final class bg {
  public static int a(AdRequest.ErrorCode paramErrorCode) {
    switch (null.gm[paramErrorCode.ordinal()]) {
      default:
        return 0;
      case 2:
        return 1;
      case 3:
        return 2;
      case 4:
        break;
    } 
    return 3;
  }
  
  public static int a(AdRequest.Gender paramGender) {
    switch (null.gl[paramGender.ordinal()]) {
      default:
        return 0;
      case 1:
        return 2;
      case 2:
        break;
    } 
    return 1;
  }
  
  public static AdSize b(x paramx) {
    return new AdSize(a.a(paramx.width, paramx.height, paramx.eF));
  }
  
  public static MediationAdRequest e(v paramv) {
    if (paramv.ez != null) {
      HashSet<String> hashSet = new HashSet<String>(paramv.ez);
      return new MediationAdRequest(new Date(paramv.ex), g(paramv.ey), hashSet, paramv.eA);
    } 
    Set set = null;
    return new MediationAdRequest(new Date(paramv.ex), g(paramv.ey), set, paramv.eA);
  }
  
  public static AdRequest.Gender g(int paramInt) {
    switch (paramInt) {
      default:
        return AdRequest.Gender.UNKNOWN;
      case 2:
        return AdRequest.Gender.FEMALE;
      case 1:
        break;
    } 
    return AdRequest.Gender.MALE;
  }
  
  public static final AdRequest.ErrorCode h(int paramInt) {
    switch (paramInt) {
      default:
        return AdRequest.ErrorCode.INTERNAL_ERROR;
      case 1:
        return AdRequest.ErrorCode.INVALID_REQUEST;
      case 2:
        return AdRequest.ErrorCode.NETWORK_ERROR;
      case 3:
        break;
    } 
    return AdRequest.ErrorCode.NO_FILL;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */