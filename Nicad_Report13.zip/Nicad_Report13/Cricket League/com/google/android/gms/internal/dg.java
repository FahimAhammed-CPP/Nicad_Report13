package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class dg extends dw<di> {
  private static final dk lA = new dk("CastClientImpl");
  
  private static final Object lQ = new Object();
  
  private static final Object lR = new Object();
  
  private final Cast.Listener kw;
  
  private ApplicationMetadata lB;
  
  private final CastDevice lC;
  
  private final dj lD;
  
  private final Map<String, Cast.MessageReceivedCallback> lE;
  
  private final long lF;
  
  private String lG;
  
  private boolean lH;
  
  private boolean lI;
  
  private final AtomicLong lJ;
  
  private String lK;
  
  private String lL;
  
  private Bundle lM;
  
  private Map<Long, com.google.android.gms.common.api.a.c<Status>> lN;
  
  private com.google.android.gms.common.api.a.c<Cast.ApplicationConnectionResult> lO;
  
  private com.google.android.gms.common.api.a.c<Status> lP;
  
  private double lb;
  
  private boolean lc;
  
  private final Handler mHandler;
  
  public dg(Context paramContext, CastDevice paramCastDevice, long paramLong, Cast.Listener paramListener, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    super(paramContext, paramConnectionCallbacks, paramOnConnectionFailedListener, (String[])null);
    this.lC = paramCastDevice;
    this.kw = paramListener;
    this.lF = paramLong;
    this.mHandler = new Handler(Looper.getMainLooper());
    this.lE = new HashMap<String, Cast.MessageReceivedCallback>();
    this.lI = false;
    this.lB = null;
    this.lG = null;
    this.lb = 0.0D;
    this.lc = false;
    this.lJ = new AtomicLong(0L);
    this.lN = new HashMap<Long, com.google.android.gms.common.api.a.c<Status>>();
    this.lD = new dj.a(this) {
        private void b(long param1Long, int param1Int) {
          synchronized (dg.g(this.lS)) {
            com.google.android.gms.common.api.a.c c = (com.google.android.gms.common.api.a.c)dg.g(this.lS).remove(Long.valueOf(param1Long));
            if (c != null)
              c.a(new Status(param1Int)); 
            return;
          } 
        }
        
        private boolean x(int param1Int) {
          synchronized (dg.ba()) {
            if (dg.h(this.lS) != null) {
              dg.h(this.lS).a(new Status(param1Int));
              dg.b(this.lS, (com.google.android.gms.common.api.a.c)null);
              return true;
            } 
            return false;
          } 
        }
        
        public void a(ApplicationMetadata param1ApplicationMetadata, String param1String1, String param1String2, boolean param1Boolean) {
          dg.a(this.lS, param1ApplicationMetadata.getApplicationId());
          dg.b(this.lS, param1String2);
          synchronized (dg.aZ()) {
            if (dg.b(this.lS) != null) {
              dg.b(this.lS).a(new dg.a(new Status(0), param1ApplicationMetadata, param1String1, param1String2, param1Boolean));
              dg.a(this.lS, (com.google.android.gms.common.api.a.c)null);
            } 
            return;
          } 
        }
        
        public void a(String param1String, long param1Long) {
          b(param1Long, 0);
        }
        
        public void a(String param1String, long param1Long, int param1Int) {
          b(param1Long, param1Int);
        }
        
        public void a(String param1String1, String param1String2) {
          dg.aY().b("Receive (type=text, ns=%s) %s", new Object[] { param1String1, param1String2 });
          dg.d(this.lS).post(new Runnable(this, param1String1, param1String2) {
                public void run() {
                  synchronized (dg.e(this.lU.lS)) {
                    Cast.MessageReceivedCallback messageReceivedCallback = (Cast.MessageReceivedCallback)dg.e(this.lU.lS).get(this.km);
                    if (messageReceivedCallback != null) {
                      messageReceivedCallback.onMessageReceived(dg.f(this.lU.lS), this.km, this.lW);
                      return;
                    } 
                  } 
                  dg.aY().b("Discarded message for unknown namespace '%s'", new Object[] { this.km });
                }
              });
        }
        
        public void b(String param1String, double param1Double, boolean param1Boolean) {
          dg.d(this.lS).post(new Runnable(this, param1String, param1Double, param1Boolean) {
                public void run() {
                  dg.a(this.lU.lS, this.lV, this.lp, this.lq);
                }
              });
        }
        
        public void b(String param1String, byte[] param1ArrayOfbyte) {
          dg.aY().b("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", new Object[] { param1String, Integer.valueOf(param1ArrayOfbyte.length) });
        }
        
        public void onApplicationDisconnected(int param1Int) {
          dg.a(this.lS, (String)null);
          dg.b(this.lS, (String)null);
          if (!x(param1Int) && dg.c(this.lS) != null) {
            dg.d(this.lS).post(new Runnable(this, param1Int) {
                  public void run() {
                    if (dg.c(this.lU.lS) != null)
                      dg.c(this.lU.lS).onApplicationDisconnected(this.lT); 
                  }
                });
            return;
          } 
        }
        
        public void t(int param1Int) {
          dg.aY().b("ICastDeviceControllerListener.onDisconnected", new Object[0]);
          dg.a(this.lS, false);
          dg.a(this.lS, (ApplicationMetadata)null);
          if (param1Int != 0)
            this.lS.I(2); 
        }
        
        public void u(int param1Int) {
          synchronized (dg.aZ()) {
            if (dg.b(this.lS) != null) {
              dg.b(this.lS).a(new dg.a(new Status(param1Int)));
              dg.a(this.lS, (com.google.android.gms.common.api.a.c)null);
            } 
            return;
          } 
        }
        
        public void v(int param1Int) {
          x(param1Int);
        }
        
        public void w(int param1Int) {
          x(param1Int);
        }
      };
  }
  
  private void a(String paramString, double paramDouble, boolean paramBoolean) {
    boolean bool1;
    boolean bool2;
    if (!dh.a(paramString, this.lG)) {
      this.lG = paramString;
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.kw != null && (bool1 || this.lH))
      this.kw.onApplicationStatusChanged(); 
    if (paramDouble != this.lb) {
      this.lb = paramDouble;
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramBoolean != this.lc) {
      this.lc = paramBoolean;
      bool2 = true;
    } 
    lA.b("hasChange=%b, mFirstStatusUpdate=%b", new Object[] { Boolean.valueOf(bool2), Boolean.valueOf(this.lH) });
    if (this.kw != null && (bool2 || this.lH))
      this.kw.onVolumeChanged(); 
    this.lH = false;
  }
  
  private void aX() throws IllegalStateException {
    if (!this.lI)
      throw new IllegalStateException("not connected to a device"); 
  }
  
  private void d(com.google.android.gms.common.api.a.c<Cast.ApplicationConnectionResult> paramc) {
    synchronized (lQ) {
      if (this.lO != null)
        this.lO.a(new a(new Status(2002))); 
      this.lO = paramc;
      return;
    } 
  }
  
  private void f(com.google.android.gms.common.api.a.c<Status> paramc) {
    synchronized (lR) {
      if (this.lP != null) {
        paramc.a(new Status(2001));
        return;
      } 
      this.lP = paramc;
      return;
    } 
  }
  
  public void C(String paramString) throws IllegalArgumentException, IllegalStateException, RemoteException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("Channel namespace cannot be null or empty"); 
    synchronized (this.lE) {
      Cast.MessageReceivedCallback messageReceivedCallback = this.lE.remove(paramString);
      if (messageReceivedCallback != null)
        bQ().F(paramString); 
      return;
    } 
  }
  
  public void a(double paramDouble) throws IllegalArgumentException, IllegalStateException, RemoteException {
    if (Double.isInfinite(paramDouble) || Double.isNaN(paramDouble))
      throw new IllegalArgumentException("Volume cannot be " + paramDouble); 
    bQ().a(paramDouble, this.lb, this.lc);
  }
  
  protected void a(int paramInt, IBinder paramIBinder, Bundle paramBundle) {
    if (paramInt == 0 || paramInt == 1001) {
      this.lI = true;
      this.lH = true;
    } else {
      this.lI = false;
    } 
    int i = paramInt;
    if (paramInt == 1001) {
      this.lM = new Bundle();
      this.lM.putBoolean("com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING", true);
      i = 0;
    } 
    super.a(i, paramIBinder, paramBundle);
  }
  
  protected void a(ec paramec, dw.e parame) throws RemoteException {
    Bundle bundle = new Bundle();
    lA.b("getServiceFromBroker(): mLastApplicationId=%s, mLastSessionId=%s", new Object[] { this.lK, this.lL });
    this.lC.putInBundle(bundle);
    bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.lF);
    if (this.lK != null) {
      bundle.putString("last_application_id", this.lK);
      if (this.lL != null)
        bundle.putString("last_session_id", this.lL); 
    } 
    paramec.a(parame, 4242000, getContext().getPackageName(), this.lD.asBinder(), bundle);
  }
  
  public void a(String paramString, Cast.MessageReceivedCallback paramMessageReceivedCallback) throws IllegalArgumentException, IllegalStateException, RemoteException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("Channel namespace cannot be null or empty"); 
    C(paramString);
    if (paramMessageReceivedCallback != null)
      synchronized (this.lE) {
        this.lE.put(paramString, paramMessageReceivedCallback);
        bQ().E(paramString);
        return;
      }  
  }
  
  public void a(String paramString, com.google.android.gms.common.api.a.c<Status> paramc) throws IllegalStateException, RemoteException {
    f(paramc);
    bQ().D(paramString);
  }
  
  public void a(String paramString1, String paramString2, com.google.android.gms.common.api.a.c<Status> paramc) throws IllegalArgumentException, IllegalStateException, RemoteException {
    if (TextUtils.isEmpty(paramString2))
      throw new IllegalArgumentException("The message payload cannot be null or empty"); 
    if (paramString1 == null || paramString1.length() > 128)
      throw new IllegalArgumentException("Invalid namespace length"); 
    if (paramString2.length() > 65536)
      throw new IllegalArgumentException("Message exceeds maximum size"); 
    aX();
    long l = this.lJ.incrementAndGet();
    bQ().a(paramString1, paramString2, l);
    this.lN.put(Long.valueOf(l), paramc);
  }
  
  public void a(String paramString, boolean paramBoolean, com.google.android.gms.common.api.a.c<Cast.ApplicationConnectionResult> paramc) throws IllegalStateException, RemoteException {
    d(paramc);
    bQ().c(paramString, paramBoolean);
  }
  
  public Bundle aU() {
    if (this.lM != null) {
      Bundle bundle = this.lM;
      this.lM = null;
      return bundle;
    } 
    return super.aU();
  }
  
  public void aV() throws IllegalStateException, RemoteException {
    bQ().aV();
  }
  
  public double aW() throws IllegalStateException {
    aX();
    return this.lb;
  }
  
  protected String am() {
    return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
  }
  
  protected String an() {
    return "com.google.android.gms.cast.internal.ICastDeviceController";
  }
  
  public void b(String paramString1, String paramString2, com.google.android.gms.common.api.a.c<Cast.ApplicationConnectionResult> paramc) throws IllegalStateException, RemoteException {
    d(paramc);
    bQ().b(paramString1, paramString2);
  }
  
  public void disconnect() {
    try {
      if (isConnected())
        synchronized (this.lE) {
          this.lE.clear();
          bQ().disconnect();
          return;
        }  
      return;
    } catch (RemoteException remoteException) {
      lA.b("Error while disconnecting the controller interface: %s", new Object[] { remoteException.getMessage() });
      return;
    } finally {
      super.disconnect();
    } 
  }
  
  public void e(com.google.android.gms.common.api.a.c<Status> paramc) throws IllegalStateException, RemoteException {
    f(paramc);
    bQ().bb();
  }
  
  public ApplicationMetadata getApplicationMetadata() throws IllegalStateException {
    aX();
    return this.lB;
  }
  
  public String getApplicationStatus() throws IllegalStateException {
    aX();
    return this.lG;
  }
  
  public boolean isMute() throws IllegalStateException {
    aX();
    return this.lc;
  }
  
  public void n(boolean paramBoolean) throws IllegalStateException, RemoteException {
    bQ().a(paramBoolean, this.lb, this.lc);
  }
  
  protected di u(IBinder paramIBinder) {
    return di.a.v(paramIBinder);
  }
  
  private static final class a implements Cast.ApplicationConnectionResult {
    private final Status jY;
    
    private final ApplicationMetadata lX;
    
    private final String lY;
    
    private final String lZ;
    
    private final boolean ma;
    
    public a(Status param1Status) {
      this(param1Status, null, null, null, false);
    }
    
    public a(Status param1Status, ApplicationMetadata param1ApplicationMetadata, String param1String1, String param1String2, boolean param1Boolean) {
      this.jY = param1Status;
      this.lX = param1ApplicationMetadata;
      this.lY = param1String1;
      this.lZ = param1String2;
      this.ma = param1Boolean;
    }
    
    public ApplicationMetadata getApplicationMetadata() {
      return this.lX;
    }
    
    public String getApplicationStatus() {
      return this.lY;
    }
    
    public String getSessionId() {
      return this.lZ;
    }
    
    public Status getStatus() {
      return this.jY;
    }
    
    public boolean getWasLaunched() {
      return this.ma;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */