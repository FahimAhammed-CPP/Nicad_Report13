package com.google.android.gms.internal;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaStatus;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class dl extends df {
  private static final long me = TimeUnit.SECONDS.toMillis(3L);
  
  private static final long mf = TimeUnit.HOURS.toMillis(24L);
  
  private static final long mg = TimeUnit.SECONDS.toMillis(5L);
  
  private static final long mh = TimeUnit.SECONDS.toMillis(1L);
  
  private final Handler mHandler = new Handler(Looper.getMainLooper());
  
  private long mi;
  
  private MediaStatus mj;
  
  private final do mk = new do(mf);
  
  private final do ml = new do(mg);
  
  private final do mm = new do(me);
  
  private final do mn = new do(me);
  
  private final do mo = new do(me);
  
  private final Runnable mp = new a();
  
  private boolean mq;
  
  public dl() {
    super("urn:x-cast:com.google.cast.media", "MediaControlChannel");
    bd();
  }
  
  private void a(long paramLong, JSONObject paramJSONObject) throws JSONException {
    // Byte code:
    //   0: iconst_1
    //   1: istore #6
    //   3: aload_0
    //   4: getfield mk : Lcom/google/android/gms/internal/do;
    //   7: lload_1
    //   8: invokevirtual i : (J)Z
    //   11: istore #7
    //   13: aload_0
    //   14: getfield ml : Lcom/google/android/gms/internal/do;
    //   17: invokevirtual bf : ()Z
    //   20: ifeq -> 243
    //   23: aload_0
    //   24: getfield ml : Lcom/google/android/gms/internal/do;
    //   27: lload_1
    //   28: invokevirtual i : (J)Z
    //   31: ifne -> 243
    //   34: iconst_1
    //   35: istore #4
    //   37: aload_0
    //   38: getfield mm : Lcom/google/android/gms/internal/do;
    //   41: invokevirtual bf : ()Z
    //   44: ifeq -> 62
    //   47: iload #6
    //   49: istore #5
    //   51: aload_0
    //   52: getfield mm : Lcom/google/android/gms/internal/do;
    //   55: lload_1
    //   56: invokevirtual i : (J)Z
    //   59: ifeq -> 87
    //   62: aload_0
    //   63: getfield mn : Lcom/google/android/gms/internal/do;
    //   66: invokevirtual bf : ()Z
    //   69: ifeq -> 249
    //   72: aload_0
    //   73: getfield mn : Lcom/google/android/gms/internal/do;
    //   76: lload_1
    //   77: invokevirtual i : (J)Z
    //   80: ifne -> 249
    //   83: iload #6
    //   85: istore #5
    //   87: iload #4
    //   89: ifeq -> 270
    //   92: iconst_2
    //   93: istore #4
    //   95: iload #4
    //   97: istore #6
    //   99: iload #5
    //   101: ifeq -> 110
    //   104: iload #4
    //   106: iconst_1
    //   107: ior
    //   108: istore #6
    //   110: iload #7
    //   112: ifne -> 122
    //   115: aload_0
    //   116: getfield mj : Lcom/google/android/gms/cast/MediaStatus;
    //   119: ifnonnull -> 255
    //   122: aload_0
    //   123: new com/google/android/gms/cast/MediaStatus
    //   126: dup
    //   127: aload_3
    //   128: invokespecial <init> : (Lorg/json/JSONObject;)V
    //   131: putfield mj : Lcom/google/android/gms/cast/MediaStatus;
    //   134: aload_0
    //   135: invokestatic elapsedRealtime : ()J
    //   138: putfield mi : J
    //   141: bipush #7
    //   143: istore #4
    //   145: iload #4
    //   147: iconst_1
    //   148: iand
    //   149: ifeq -> 163
    //   152: aload_0
    //   153: invokestatic elapsedRealtime : ()J
    //   156: putfield mi : J
    //   159: aload_0
    //   160: invokevirtual onStatusUpdated : ()V
    //   163: iload #4
    //   165: iconst_2
    //   166: iand
    //   167: ifeq -> 181
    //   170: aload_0
    //   171: invokestatic elapsedRealtime : ()J
    //   174: putfield mi : J
    //   177: aload_0
    //   178: invokevirtual onStatusUpdated : ()V
    //   181: iload #4
    //   183: iconst_4
    //   184: iand
    //   185: ifeq -> 192
    //   188: aload_0
    //   189: invokevirtual onMetadataUpdated : ()V
    //   192: aload_0
    //   193: getfield mk : Lcom/google/android/gms/internal/do;
    //   196: lload_1
    //   197: iconst_0
    //   198: invokevirtual c : (JI)Z
    //   201: pop
    //   202: aload_0
    //   203: getfield ml : Lcom/google/android/gms/internal/do;
    //   206: lload_1
    //   207: iconst_0
    //   208: invokevirtual c : (JI)Z
    //   211: pop
    //   212: aload_0
    //   213: getfield mm : Lcom/google/android/gms/internal/do;
    //   216: lload_1
    //   217: iconst_0
    //   218: invokevirtual c : (JI)Z
    //   221: pop
    //   222: aload_0
    //   223: getfield mn : Lcom/google/android/gms/internal/do;
    //   226: lload_1
    //   227: iconst_0
    //   228: invokevirtual c : (JI)Z
    //   231: pop
    //   232: aload_0
    //   233: getfield mo : Lcom/google/android/gms/internal/do;
    //   236: lload_1
    //   237: iconst_0
    //   238: invokevirtual c : (JI)Z
    //   241: pop
    //   242: return
    //   243: iconst_0
    //   244: istore #4
    //   246: goto -> 37
    //   249: iconst_0
    //   250: istore #5
    //   252: goto -> 87
    //   255: aload_0
    //   256: getfield mj : Lcom/google/android/gms/cast/MediaStatus;
    //   259: aload_3
    //   260: iload #6
    //   262: invokevirtual a : (Lorg/json/JSONObject;I)I
    //   265: istore #4
    //   267: goto -> 145
    //   270: iconst_0
    //   271: istore #4
    //   273: goto -> 95
  }
  
  private void bd() {
    o(false);
    this.mi = 0L;
    this.mj = null;
    this.mk.clear();
    this.ml.clear();
    this.mm.clear();
  }
  
  private void o(boolean paramBoolean) {
    if (this.mq != paramBoolean) {
      this.mq = paramBoolean;
      if (paramBoolean) {
        this.mHandler.postDelayed(this.mp, mh);
        return;
      } 
    } else {
      return;
    } 
    this.mHandler.removeCallbacks(this.mp);
  }
  
  public final void B(String paramString) {
    long l;
    JSONObject jSONObject;
    String str;
    this.lx.b("message received: %s", new Object[] { paramString });
    try {
      jSONObject = new JSONObject(paramString);
      str = jSONObject.getString("type");
      l = jSONObject.optLong("requestId", -1L);
      if (str.equals("MEDIA_STATUS")) {
        JSONArray jSONArray = jSONObject.getJSONArray("status");
        if (jSONArray.length() > 0) {
          a(l, jSONArray.getJSONObject(0));
          return;
        } 
        this.mj = null;
        onStatusUpdated();
        onMetadataUpdated();
        this.mo.c(l, 0);
        return;
      } 
    } catch (JSONException jSONException) {
      this.lx.d("Message is malformed (%s); ignoring: %s", new Object[] { jSONException.getMessage(), paramString });
      return;
    } 
    if (str.equals("INVALID_PLAYER_STATE")) {
      this.lx.d("received unexpected error: Invalid Player State.", new Object[0]);
      jSONObject = jSONException.optJSONObject("customData");
      this.mk.b(l, 1, jSONObject);
      this.ml.b(l, 1, jSONObject);
      this.mm.b(l, 1, jSONObject);
      this.mn.b(l, 1, jSONObject);
      this.mo.b(l, 1, jSONObject);
      return;
    } 
    if (str.equals("LOAD_FAILED")) {
      jSONObject = jSONObject.optJSONObject("customData");
      this.mk.b(l, 1, jSONObject);
      return;
    } 
    if (str.equals("LOAD_CANCELLED")) {
      jSONObject = jSONObject.optJSONObject("customData");
      this.mk.b(l, 2, jSONObject);
      return;
    } 
    if (str.equals("INVALID_REQUEST")) {
      this.lx.d("received unexpected error: Invalid Request.", new Object[0]);
      jSONObject = jSONObject.optJSONObject("customData");
      this.mk.b(l, 1, jSONObject);
      this.ml.b(l, 1, jSONObject);
      this.mm.b(l, 1, jSONObject);
      this.mn.b(l, 1, jSONObject);
      this.mo.b(l, 1, jSONObject);
    } 
  }
  
  public long a(dn paramdn) throws IOException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    this.mo.a(l, paramdn);
    o(true);
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "GET_STATUS");
      if (this.mj != null)
        jSONObject.put("mediaSessionId", this.mj.aQ()); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
    return l;
  }
  
  public long a(dn paramdn, double paramDouble, JSONObject paramJSONObject) throws IOException, IllegalStateException, IllegalArgumentException {
    if (Double.isInfinite(paramDouble) || Double.isNaN(paramDouble))
      throw new IllegalArgumentException("Volume cannot be " + paramDouble); 
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    this.mm.a(l, paramdn);
    o(true);
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "SET_VOLUME");
      jSONObject.put("mediaSessionId", aQ());
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put("level", paramDouble);
      jSONObject.put("volume", jSONObject1);
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
    return l;
  }
  
  public long a(dn paramdn, long paramLong, int paramInt, JSONObject paramJSONObject) throws IOException, IllegalStateException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    this.ml.a(l, paramdn);
    o(true);
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "SEEK");
      jSONObject.put("mediaSessionId", aQ());
      jSONObject.put("currentTime", dh.h(paramLong));
      if (paramInt == 1) {
        jSONObject.put("resumeState", "PLAYBACK_START");
      } else if (paramInt == 2) {
        jSONObject.put("resumeState", "PLAYBACK_PAUSE");
      } 
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
    return l;
  }
  
  public long a(dn paramdn, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong, JSONObject paramJSONObject) throws IOException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    this.mk.a(l, paramdn);
    o(true);
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "LOAD");
      jSONObject.put("media", paramMediaInfo.aP());
      jSONObject.put("autoplay", paramBoolean);
      jSONObject.put("currentTime", dh.h(paramLong));
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
    return l;
  }
  
  public long a(dn paramdn, boolean paramBoolean, JSONObject paramJSONObject) throws IOException, IllegalStateException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    this.mn.a(l, paramdn);
    o(true);
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "SET_VOLUME");
      jSONObject.put("mediaSessionId", aQ());
      JSONObject jSONObject1 = new JSONObject();
      jSONObject1.put("muted", paramBoolean);
      jSONObject.put("volume", jSONObject1);
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
    return l;
  }
  
  public void a(long paramLong, int paramInt) {
    this.mk.c(paramLong, paramInt);
    this.ml.c(paramLong, paramInt);
    this.mm.c(paramLong, paramInt);
    this.mn.c(paramLong, paramInt);
    this.mo.c(paramLong, paramInt);
  }
  
  public long aQ() throws IllegalStateException {
    if (this.mj == null)
      throw new IllegalStateException("No current media session"); 
    return this.mj.aQ();
  }
  
  public void aT() {
    bd();
  }
  
  public void c(JSONObject paramJSONObject) throws IOException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "PAUSE");
      jSONObject.put("mediaSessionId", aQ());
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
  }
  
  public void d(JSONObject paramJSONObject) throws IOException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "STOP");
      jSONObject.put("mediaSessionId", aQ());
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
  }
  
  public void e(JSONObject paramJSONObject) throws IOException, IllegalStateException {
    JSONObject jSONObject = new JSONObject();
    long l = aS();
    try {
      jSONObject.put("requestId", l);
      jSONObject.put("type", "PLAY");
      jSONObject.put("mediaSessionId", aQ());
      if (paramJSONObject != null)
        jSONObject.put("customData", paramJSONObject); 
    } catch (JSONException jSONException) {}
    a(jSONObject.toString(), l, (String)null);
  }
  
  public long getApproximateStreamPosition() {
    MediaInfo mediaInfo = getMediaInfo();
    if (mediaInfo != null && this.mi != 0L) {
      double d = this.mj.getPlaybackRate();
      long l3 = this.mj.getStreamPosition();
      int i = this.mj.getPlayerState();
      if (d == 0.0D || i != 2)
        return l3; 
      long l1 = SystemClock.elapsedRealtime() - this.mi;
      if (l1 < 0L)
        l1 = 0L; 
      if (l1 == 0L)
        return l3; 
      long l2 = mediaInfo.getStreamDuration();
      l1 = l3 + (long)(l1 * d);
      if (l1 > l2)
        return l2; 
      if (l1 < 0L)
        l1 = 0L; 
      return l1;
    } 
    return 0L;
  }
  
  public MediaInfo getMediaInfo() {
    return (this.mj == null) ? null : this.mj.getMediaInfo();
  }
  
  public MediaStatus getMediaStatus() {
    return this.mj;
  }
  
  public long getStreamDuration() {
    MediaInfo mediaInfo = getMediaInfo();
    return (mediaInfo != null) ? mediaInfo.getStreamDuration() : 0L;
  }
  
  protected void onMetadataUpdated() {}
  
  protected void onStatusUpdated() {}
  
  private class a implements Runnable {
    private a(dl this$0) {}
    
    public void run() {
      boolean bool = false;
      dl.a(this.mr, false);
      long l = SystemClock.elapsedRealtime();
      dl.a(this.mr).d(l, 3);
      dl.b(this.mr).d(l, 3);
      dl.c(this.mr).d(l, 3);
      dl.d(this.mr).d(l, 3);
      dl.e(this.mr).d(l, 3);
      synchronized (do.mw) {
        if (dl.a(this.mr).bf() || dl.b(this.mr).bf() || dl.c(this.mr).bf() || dl.d(this.mr).bf() || dl.e(this.mr).bf())
          bool = true; 
        dl.b(this.mr, bool);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */