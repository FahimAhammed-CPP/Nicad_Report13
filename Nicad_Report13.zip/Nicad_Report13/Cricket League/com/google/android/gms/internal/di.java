package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface di extends IInterface {
  void D(String paramString) throws RemoteException;
  
  void E(String paramString) throws RemoteException;
  
  void F(String paramString) throws RemoteException;
  
  void a(double paramDouble1, double paramDouble2, boolean paramBoolean) throws RemoteException;
  
  void a(String paramString1, String paramString2, long paramLong) throws RemoteException;
  
  void a(String paramString, byte[] paramArrayOfbyte, long paramLong) throws RemoteException;
  
  void a(boolean paramBoolean1, double paramDouble, boolean paramBoolean2) throws RemoteException;
  
  void aV() throws RemoteException;
  
  void b(String paramString1, String paramString2) throws RemoteException;
  
  void bb() throws RemoteException;
  
  void c(String paramString, boolean paramBoolean) throws RemoteException;
  
  void disconnect() throws RemoteException;
  
  public static abstract class a extends Binder implements di {
    public static di v(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.cast.internal.ICastDeviceController");
      return (iInterface != null && iInterface instanceof di) ? (di)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      String str;
      double d1;
      double d2;
      boolean bool2 = false;
      boolean bool1 = false;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.cast.internal.ICastDeviceController");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          disconnect();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          str = param1Parcel1.readString();
          if (param1Parcel1.readInt() != 0)
            bool1 = true; 
          c(str, bool1);
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          b(param1Parcel1.readString(), param1Parcel1.readString());
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          bb();
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          D(param1Parcel1.readString());
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          aV();
          return true;
        case 7:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          d1 = param1Parcel1.readDouble();
          d2 = param1Parcel1.readDouble();
          if (param1Parcel1.readInt() != 0) {
            bool1 = true;
            a(d1, d2, bool1);
            return true;
          } 
          bool1 = false;
          a(d1, d2, bool1);
          return true;
        case 8:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          if (param1Parcel1.readInt() != 0) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          d1 = param1Parcel1.readDouble();
          if (param1Parcel1.readInt() != 0)
            bool2 = true; 
          a(bool1, d1, bool2);
          return true;
        case 9:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          a(param1Parcel1.readString(), param1Parcel1.readString(), param1Parcel1.readLong());
          return true;
        case 10:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          a(param1Parcel1.readString(), param1Parcel1.createByteArray(), param1Parcel1.readLong());
          return true;
        case 11:
          param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
          E(param1Parcel1.readString());
          return true;
        case 12:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceController");
      F(param1Parcel1.readString());
      return true;
    }
    
    private static class a implements di {
      private IBinder dU;
      
      a(IBinder param2IBinder) {
        this.dU = param2IBinder;
      }
      
      public void D(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String);
          this.dU.transact(5, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void E(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String);
          this.dU.transact(11, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void F(String param2String) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String);
          this.dU.transact(12, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void a(double param2Double1, double param2Double2, boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeDouble(param2Double1);
          parcel.writeDouble(param2Double2);
          if (!param2Boolean)
            bool = false; 
          parcel.writeInt(bool);
          this.dU.transact(7, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void a(String param2String1, String param2String2, long param2Long) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String1);
          parcel.writeString(param2String2);
          parcel.writeLong(param2Long);
          this.dU.transact(9, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void a(String param2String, byte[] param2ArrayOfbyte, long param2Long) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String);
          parcel.writeByteArray(param2ArrayOfbyte);
          parcel.writeLong(param2Long);
          this.dU.transact(10, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void a(boolean param2Boolean1, double param2Double, boolean param2Boolean2) throws RemoteException {
        boolean bool = true;
        Parcel parcel = Parcel.obtain();
        try {
          boolean bool1;
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          if (param2Boolean1) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          parcel.writeInt(bool1);
          parcel.writeDouble(param2Double);
          if (param2Boolean2) {
            bool1 = bool;
          } else {
            bool1 = false;
          } 
          parcel.writeInt(bool1);
          this.dU.transact(8, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void aV() throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          this.dU.transact(6, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.dU;
      }
      
      public void b(String param2String1, String param2String2) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String1);
          parcel.writeString(param2String2);
          this.dU.transact(3, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void bb() throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          this.dU.transact(4, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void c(String param2String, boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          parcel.writeString(param2String);
          if (!param2Boolean)
            bool = false; 
          parcel.writeInt(bool);
          this.dU.transact(2, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public void disconnect() throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
          this.dU.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class a implements di {
    private IBinder dU;
    
    a(IBinder param1IBinder) {
      this.dU = param1IBinder;
    }
    
    public void D(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String);
        this.dU.transact(5, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void E(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String);
        this.dU.transact(11, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void F(String param1String) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String);
        this.dU.transact(12, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void a(double param1Double1, double param1Double2, boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeDouble(param1Double1);
        parcel.writeDouble(param1Double2);
        if (!param1Boolean)
          bool = false; 
        parcel.writeInt(bool);
        this.dU.transact(7, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void a(String param1String1, String param1String2, long param1Long) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String1);
        parcel.writeString(param1String2);
        parcel.writeLong(param1Long);
        this.dU.transact(9, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void a(String param1String, byte[] param1ArrayOfbyte, long param1Long) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String);
        parcel.writeByteArray(param1ArrayOfbyte);
        parcel.writeLong(param1Long);
        this.dU.transact(10, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void a(boolean param1Boolean1, double param1Double, boolean param1Boolean2) throws RemoteException {
      boolean bool = true;
      Parcel parcel = Parcel.obtain();
      try {
        boolean bool1;
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        if (param1Boolean1) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        parcel.writeInt(bool1);
        parcel.writeDouble(param1Double);
        if (param1Boolean2) {
          bool1 = bool;
        } else {
          bool1 = false;
        } 
        parcel.writeInt(bool1);
        this.dU.transact(8, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void aV() throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        this.dU.transact(6, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.dU;
    }
    
    public void b(String param1String1, String param1String2) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String1);
        parcel.writeString(param1String2);
        this.dU.transact(3, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void bb() throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        this.dU.transact(4, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void c(String param1String, boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        parcel.writeString(param1String);
        if (!param1Boolean)
          bool = false; 
        parcel.writeInt(bool);
        this.dU.transact(2, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public void disconnect() throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.cast.internal.ICastDeviceController");
        this.dU.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\di.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */