package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import java.math.BigInteger;
import java.util.Locale;

public final class cl {
  private static final Object hC = new Object();
  
  private static String iw;
  
  public static String as() {
    synchronized (hC) {
      return iw;
    } 
  }
  
  public static String b(Context paramContext, String paramString1, String paramString2) {
    synchronized (hC) {
      if (iw == null && !TextUtils.isEmpty(paramString1))
        c(paramContext, paramString1, paramString2); 
      return iw;
    } 
  }
  
  private static void c(Context paramContext, String paramString1, String paramString2) {
    try {
      ClassLoader classLoader = paramContext.createPackageContext(paramString2, 3).getClassLoader();
      Class<?> clazz = Class.forName("com.google.ads.mediation.MediationAdapter", false, classLoader);
      BigInteger bigInteger = new BigInteger(new byte[1]);
      String[] arrayOfString = paramString1.split(",");
      int i = 0;
      while (i < arrayOfString.length) {
        BigInteger bigInteger1 = bigInteger;
        if (co.a(classLoader, clazz, arrayOfString[i]))
          bigInteger1 = bigInteger.setBit(i); 
        i++;
        bigInteger = bigInteger1;
      } 
    } catch (Throwable throwable) {
      iw = "err";
      return;
    } 
    iw = String.format(Locale.US, "%X", new Object[] { throwable });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\cl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */