package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;

public abstract class bx extends cm {
  private final bz fw;
  
  private final bw.a hn;
  
  public bx(bz parambz, bw.a parama) {
    this.fw = parambz;
    this.hn = parama;
  }
  
  private static cb a(cd paramcd, bz parambz) {
    try {
      return paramcd.b(parambz);
    } catch (RemoteException remoteException) {
      ct.b("Could not fetch ad response from ad request service.", (Throwable)remoteException);
      return null;
    } 
  }
  
  public final void ai() {
    try {
      cb cb;
      cd cd = al();
      if (cd == null) {
        cb = new cb(0);
      } else {
        cb cb1 = a((cd)cb, this.fw);
        cb = cb1;
        if (cb1 == null)
          cb = new cb(0); 
      } 
      ak();
      return;
    } finally {
      ak();
    } 
  }
  
  public abstract void ak();
  
  public abstract cd al();
  
  public final void onStop() {
    ak();
  }
  
  public static final class a extends bx {
    private final Context mContext;
    
    public a(Context param1Context, bz param1bz, bw.a param1a) {
      super(param1bz, param1a);
      this.mContext = param1Context;
    }
    
    public void ak() {}
    
    public cd al() {
      return ce.a(this.mContext, new ar());
    }
  }
  
  public static final class b extends bx implements GooglePlayServicesClient.ConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener {
    private final Object fx = new Object();
    
    private final bw.a hn;
    
    private final by ho;
    
    public b(Context param1Context, bz param1bz, bw.a param1a) {
      super(param1bz, param1a);
      this.hn = param1a;
      this.ho = new by(param1Context, this, this, param1bz.ej.iL);
      this.ho.connect();
    }
    
    public void ak() {
      synchronized (this.fx) {
        if (this.ho.isConnected() || this.ho.isConnecting())
          this.ho.disconnect(); 
        return;
      } 
    }
    
    public cd al() {
      synchronized (this.fx) {
        return this.ho.ao();
      } 
    }
    
    public void onConnected(Bundle param1Bundle) {
      start();
    }
    
    public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
      this.hn.a(new cb(0));
    }
    
    public void onDisconnected() {
      ct.r("Disconnected from remote ad request service.");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */