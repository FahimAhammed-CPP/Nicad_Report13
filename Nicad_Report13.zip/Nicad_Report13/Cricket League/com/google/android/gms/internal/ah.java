package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.doubleclick.AppEventListener;

public final class ah {
  private AppEventListener eI;
  
  private String eK;
  
  private final ba eW = new ba();
  
  private ac eX;
  
  private AdListener ev;
  
  private final Context mContext;
  
  public ah(Context paramContext) {
    this.mContext = paramContext;
  }
  
  private void j(String paramString) throws RemoteException {
    if (this.eK == null)
      k(paramString); 
    this.eX = u.a(this.mContext, new x(), this.eK, this.eW);
    if (this.ev != null)
      this.eX.a(new t(this.ev)); 
    if (this.eI != null)
      this.eX.a(new z(this.eI)); 
  }
  
  private void k(String paramString) {
    if (this.eX == null)
      throw new IllegalStateException("The ad unit ID must be set on InterstitialAd before " + paramString + " is called."); 
  }
  
  public void a(af paramaf) {
    try {
      if (this.eX == null)
        j("loadAd"); 
      if (this.eX.a(new v(this.mContext, paramaf)))
        this.eW.c(paramaf.R()); 
      return;
    } catch (RemoteException remoteException) {
      ct.b("Failed to load ad.", (Throwable)remoteException);
      return;
    } 
  }
  
  public AdListener getAdListener() {
    return this.ev;
  }
  
  public String getAdUnitId() {
    return this.eK;
  }
  
  public AppEventListener getAppEventListener() {
    return this.eI;
  }
  
  public boolean isLoaded() {
    try {
      return (this.eX == null) ? false : this.eX.isReady();
    } catch (RemoteException remoteException) {
      ct.b("Failed to check if ad is ready.", (Throwable)remoteException);
      return false;
    } 
  }
  
  public void setAdListener(AdListener paramAdListener) {
    try {
      this.ev = paramAdListener;
      if (this.eX != null) {
        ac ac1 = this.eX;
        if (paramAdListener != null) {
          t t = new t(paramAdListener);
        } else {
          paramAdListener = null;
        } 
        ac1.a((ab)paramAdListener);
      } 
      return;
    } catch (RemoteException remoteException) {
      ct.b("Failed to set the AdListener.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void setAdUnitId(String paramString) {
    if (this.eK != null)
      throw new IllegalStateException("The ad unit ID can only be set once on InterstitialAd."); 
    this.eK = paramString;
  }
  
  public void setAppEventListener(AppEventListener paramAppEventListener) {
    try {
      this.eI = paramAppEventListener;
      if (this.eX != null) {
        ac ac1 = this.eX;
        if (paramAppEventListener != null) {
          z z = new z(paramAppEventListener);
        } else {
          paramAppEventListener = null;
        } 
        ac1.a((ae)paramAppEventListener);
      } 
      return;
    } catch (RemoteException remoteException) {
      ct.b("Failed to set the AppEventListener.", (Throwable)remoteException);
      return;
    } 
  }
  
  public void show() {
    try {
      k("show");
      this.eX.showInterstitial();
      return;
    } catch (RemoteException remoteException) {
      ct.b("Failed to show interstitial.", (Throwable)remoteException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */