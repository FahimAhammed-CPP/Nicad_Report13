package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import org.json.JSONException;

public final class bv extends cm implements bw.a, cx.a {
  private final bb ed;
  
  private final Object fx = new Object();
  
  private au fy;
  
  private final cw gv;
  
  private final bu.a hb;
  
  private final Object hc = new Object();
  
  private final bz.a hd;
  
  private final h he;
  
  private cm hf;
  
  private cb hg;
  
  private boolean hh = false;
  
  private as hi;
  
  private ay hj;
  
  private final Context mContext;
  
  public bv(Context paramContext, bz.a parama, h paramh, cw paramcw, bb parambb, bu.a parama1) {
    this.ed = parambb;
    this.hb = parama1;
    this.gv = paramcw;
    this.mContext = paramContext;
    this.hd = parama;
    this.he = paramh;
  }
  
  private x a(bz parambz) throws a {
    if (this.hg.hB == null)
      throw new a("The ad response must specify one of the supported ad sizes.", 0); 
    String[] arrayOfString = this.hg.hB.split("x");
    if (arrayOfString.length != 2)
      throw new a("Could not parse the ad size from the ad response: " + this.hg.hB, 0); 
    try {
      int i = Integer.parseInt(arrayOfString[0]);
      int j = Integer.parseInt(arrayOfString[1]);
      for (x x : parambz.em.eH) {
        int k;
        int m;
        float f = (this.mContext.getResources().getDisplayMetrics()).density;
        if (x.width == -1) {
          k = (int)(x.widthPixels / f);
        } else {
          k = x.width;
        } 
        if (x.height == -2) {
          m = (int)(x.heightPixels / f);
        } else {
          m = x.height;
        } 
        if (i == k && j == m)
          return new x(x, parambz.em.eH); 
      } 
    } catch (NumberFormatException numberFormatException) {
      throw new a("Could not parse the ad size from the ad response: " + this.hg.hB, 0);
    } 
    throw new a("The ad size from the ad response was not one of the requested sizes: " + this.hg.hB, 0);
  }
  
  private void a(bz parambz, long paramLong) throws a {
    synchronized (this.hc) {
      this.hi = new as(this.mContext, parambz, this.ed, this.fy);
      this.hj = this.hi.a(paramLong, 60000L);
      switch (this.hj.ga) {
        default:
          throw new a("Unexpected mediation result: " + this.hj.ga, 0);
        case 1:
          throw new a("No fill from any mediation ad networks.", 3);
        case 0:
          break;
      } 
    } 
  }
  
  private void aj() throws a {
    if (this.hg.errorCode != -3) {
      if (TextUtils.isEmpty(this.hg.hw))
        throw new a("No fill from ad server.", 3); 
      if (this.hg.hy)
        try {
          this.fy = new au(this.hg.hw);
          return;
        } catch (JSONException jSONException) {
          throw new a("Could not parse mediation config: " + this.hg.hw, 0);
        }  
    } 
  }
  
  private void b(long paramLong) throws a {
    cs.iI.post(new Runnable(this) {
          public void run() {
            synchronized (bv.a(this.hk)) {
              if ((bv.c(this.hk)).errorCode != -2)
                return; 
              bv.d(this.hk).aC().a(this.hk);
              if ((bv.c(this.hk)).errorCode == -3) {
                ct.u("Loading URL in WebView: " + (bv.c(this.hk)).gL);
                bv.d(this.hk).loadUrl((bv.c(this.hk)).gL);
              } else {
                ct.u("Loading HTML in WebView.");
                bv.d(this.hk).loadDataWithBaseURL(co.o((bv.c(this.hk)).gL), (bv.c(this.hk)).hw, "text/html", "UTF-8", null);
              } 
              return;
            } 
          }
        });
    d(paramLong);
  }
  
  private void c(long paramLong) throws a {
    // Byte code:
    //   0: aload_0
    //   1: lload_1
    //   2: invokespecial e : (J)Z
    //   5: ifne -> 19
    //   8: new com/google/android/gms/internal/bv$a
    //   11: dup
    //   12: ldc 'Timed out waiting for ad response.'
    //   14: iconst_2
    //   15: invokespecial <init> : (Ljava/lang/String;I)V
    //   18: athrow
    //   19: aload_0
    //   20: getfield hg : Lcom/google/android/gms/internal/cb;
    //   23: ifnull -> 0
    //   26: aload_0
    //   27: getfield hc : Ljava/lang/Object;
    //   30: astore_3
    //   31: aload_3
    //   32: monitorenter
    //   33: aload_0
    //   34: aconst_null
    //   35: putfield hf : Lcom/google/android/gms/internal/cm;
    //   38: aload_3
    //   39: monitorexit
    //   40: aload_0
    //   41: getfield hg : Lcom/google/android/gms/internal/cb;
    //   44: getfield errorCode : I
    //   47: bipush #-2
    //   49: if_icmpeq -> 111
    //   52: aload_0
    //   53: getfield hg : Lcom/google/android/gms/internal/cb;
    //   56: getfield errorCode : I
    //   59: bipush #-3
    //   61: if_icmpeq -> 111
    //   64: new com/google/android/gms/internal/bv$a
    //   67: dup
    //   68: new java/lang/StringBuilder
    //   71: dup
    //   72: invokespecial <init> : ()V
    //   75: ldc 'There was a problem getting an ad response. ErrorCode: '
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: aload_0
    //   81: getfield hg : Lcom/google/android/gms/internal/cb;
    //   84: getfield errorCode : I
    //   87: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   90: invokevirtual toString : ()Ljava/lang/String;
    //   93: aload_0
    //   94: getfield hg : Lcom/google/android/gms/internal/cb;
    //   97: getfield errorCode : I
    //   100: invokespecial <init> : (Ljava/lang/String;I)V
    //   103: athrow
    //   104: astore #4
    //   106: aload_3
    //   107: monitorexit
    //   108: aload #4
    //   110: athrow
    //   111: return
    // Exception table:
    //   from	to	target	type
    //   33	40	104	finally
    //   106	108	104	finally
  }
  
  private void d(long paramLong) throws a {
    do {
      if (!e(paramLong))
        throw new a("Timed out waiting for WebView to finish loading.", 2); 
    } while (!this.hh);
  }
  
  private boolean e(long paramLong) throws a {
    paramLong = 60000L - SystemClock.elapsedRealtime() - paramLong;
    if (paramLong <= 0L)
      return false; 
    try {
      this.fx.wait(paramLong);
      return true;
    } catch (InterruptedException interruptedException) {
      throw new a("Ad request cancelled.", -1);
    } 
  }
  
  public void a(cb paramcb) {
    synchronized (this.fx) {
      ct.r("Received ad response.");
      this.hg = paramcb;
      this.fx.notify();
      return;
    } 
  }
  
  public void a(cw paramcw) {
    synchronized (this.fx) {
      ct.r("WebView finished loading.");
      this.hh = true;
      this.fx.notify();
      return;
    } 
  }
  
  public void ai() {
    // Byte code:
    //   0: aload_0
    //   1: getfield fx : Ljava/lang/Object;
    //   4: astore #11
    //   6: aload #11
    //   8: monitorenter
    //   9: ldc_w 'AdLoaderBackgroundTask started.'
    //   12: invokestatic r : (Ljava/lang/String;)V
    //   15: aload_0
    //   16: getfield he : Lcom/google/android/gms/internal/h;
    //   19: invokevirtual g : ()Lcom/google/android/gms/internal/d;
    //   22: aload_0
    //   23: getfield mContext : Landroid/content/Context;
    //   26: invokeinterface a : (Landroid/content/Context;)Ljava/lang/String;
    //   31: astore #6
    //   33: new com/google/android/gms/internal/bz
    //   36: dup
    //   37: aload_0
    //   38: getfield hd : Lcom/google/android/gms/internal/bz$a;
    //   41: aload #6
    //   43: invokespecial <init> : (Lcom/google/android/gms/internal/bz$a;Ljava/lang/String;)V
    //   46: astore #9
    //   48: aconst_null
    //   49: astore #6
    //   51: aconst_null
    //   52: astore #8
    //   54: bipush #-2
    //   56: istore_1
    //   57: aload #8
    //   59: astore #7
    //   61: invokestatic elapsedRealtime : ()J
    //   64: lstore_3
    //   65: aload #8
    //   67: astore #7
    //   69: aload_0
    //   70: getfield mContext : Landroid/content/Context;
    //   73: aload #9
    //   75: aload_0
    //   76: invokestatic a : (Landroid/content/Context;Lcom/google/android/gms/internal/bz;Lcom/google/android/gms/internal/bw$a;)Lcom/google/android/gms/internal/cm;
    //   79: astore #12
    //   81: aload #8
    //   83: astore #7
    //   85: aload_0
    //   86: getfield hc : Ljava/lang/Object;
    //   89: astore #10
    //   91: aload #8
    //   93: astore #7
    //   95: aload #10
    //   97: monitorenter
    //   98: aload_0
    //   99: aload #12
    //   101: putfield hf : Lcom/google/android/gms/internal/cm;
    //   104: aload_0
    //   105: getfield hf : Lcom/google/android/gms/internal/cm;
    //   108: ifnonnull -> 407
    //   111: new com/google/android/gms/internal/bv$a
    //   114: dup
    //   115: ldc_w 'Could not start the ad request service.'
    //   118: iconst_0
    //   119: invokespecial <init> : (Ljava/lang/String;I)V
    //   122: athrow
    //   123: astore #6
    //   125: aload #10
    //   127: monitorexit
    //   128: aload #8
    //   130: astore #7
    //   132: aload #6
    //   134: athrow
    //   135: astore #6
    //   137: aload #6
    //   139: invokevirtual getErrorCode : ()I
    //   142: istore_1
    //   143: iload_1
    //   144: iconst_3
    //   145: if_icmpeq -> 153
    //   148: iload_1
    //   149: iconst_m1
    //   150: if_icmpne -> 502
    //   153: aload #6
    //   155: invokevirtual getMessage : ()Ljava/lang/String;
    //   158: invokestatic t : (Ljava/lang/String;)V
    //   161: aload_0
    //   162: new com/google/android/gms/internal/cb
    //   165: dup
    //   166: iload_1
    //   167: invokespecial <init> : (I)V
    //   170: putfield hg : Lcom/google/android/gms/internal/cb;
    //   173: getstatic com/google/android/gms/internal/cs.iI : Landroid/os/Handler;
    //   176: new com/google/android/gms/internal/bv$1
    //   179: dup
    //   180: aload_0
    //   181: invokespecial <init> : (Lcom/google/android/gms/internal/bv;)V
    //   184: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   187: pop
    //   188: aload #7
    //   190: astore #6
    //   192: aload #9
    //   194: getfield hr : Lcom/google/android/gms/internal/v;
    //   197: astore #12
    //   199: aload_0
    //   200: getfield gv : Lcom/google/android/gms/internal/cw;
    //   203: astore #13
    //   205: aload_0
    //   206: getfield hg : Lcom/google/android/gms/internal/cb;
    //   209: getfield fK : Ljava/util/List;
    //   212: astore #14
    //   214: aload_0
    //   215: getfield hg : Lcom/google/android/gms/internal/cb;
    //   218: getfield fL : Ljava/util/List;
    //   221: astore #15
    //   223: aload_0
    //   224: getfield hg : Lcom/google/android/gms/internal/cb;
    //   227: getfield hA : Ljava/util/List;
    //   230: astore #16
    //   232: aload_0
    //   233: getfield hg : Lcom/google/android/gms/internal/cb;
    //   236: getfield orientation : I
    //   239: istore_2
    //   240: aload_0
    //   241: getfield hg : Lcom/google/android/gms/internal/cb;
    //   244: getfield fO : J
    //   247: lstore_3
    //   248: aload #9
    //   250: getfield hu : Ljava/lang/String;
    //   253: astore #17
    //   255: aload_0
    //   256: getfield hg : Lcom/google/android/gms/internal/cb;
    //   259: getfield hy : Z
    //   262: istore #5
    //   264: aload_0
    //   265: getfield hj : Lcom/google/android/gms/internal/ay;
    //   268: ifnull -> 513
    //   271: aload_0
    //   272: getfield hj : Lcom/google/android/gms/internal/ay;
    //   275: getfield gb : Lcom/google/android/gms/internal/at;
    //   278: astore #7
    //   280: aload_0
    //   281: getfield hj : Lcom/google/android/gms/internal/ay;
    //   284: ifnull -> 519
    //   287: aload_0
    //   288: getfield hj : Lcom/google/android/gms/internal/ay;
    //   291: getfield gc : Lcom/google/android/gms/internal/bc;
    //   294: astore #8
    //   296: aload_0
    //   297: getfield hj : Lcom/google/android/gms/internal/ay;
    //   300: ifnull -> 525
    //   303: aload_0
    //   304: getfield hj : Lcom/google/android/gms/internal/ay;
    //   307: getfield gd : Ljava/lang/String;
    //   310: astore #9
    //   312: aload_0
    //   313: getfield fy : Lcom/google/android/gms/internal/au;
    //   316: astore #18
    //   318: aload_0
    //   319: getfield hj : Lcom/google/android/gms/internal/ay;
    //   322: ifnull -> 531
    //   325: aload_0
    //   326: getfield hj : Lcom/google/android/gms/internal/ay;
    //   329: getfield ge : Lcom/google/android/gms/internal/aw;
    //   332: astore #10
    //   334: new com/google/android/gms/internal/cj
    //   337: dup
    //   338: aload #12
    //   340: aload #13
    //   342: aload #14
    //   344: iload_1
    //   345: aload #15
    //   347: aload #16
    //   349: iload_2
    //   350: lload_3
    //   351: aload #17
    //   353: iload #5
    //   355: aload #7
    //   357: aload #8
    //   359: aload #9
    //   361: aload #18
    //   363: aload #10
    //   365: aload_0
    //   366: getfield hg : Lcom/google/android/gms/internal/cb;
    //   369: getfield hz : J
    //   372: aload #6
    //   374: aload_0
    //   375: getfield hg : Lcom/google/android/gms/internal/cb;
    //   378: getfield hx : J
    //   381: invokespecial <init> : (Lcom/google/android/gms/internal/v;Lcom/google/android/gms/internal/cw;Ljava/util/List;ILjava/util/List;Ljava/util/List;IJLjava/lang/String;ZLcom/google/android/gms/internal/at;Lcom/google/android/gms/internal/bc;Ljava/lang/String;Lcom/google/android/gms/internal/au;Lcom/google/android/gms/internal/aw;JLcom/google/android/gms/internal/x;J)V
    //   384: astore #6
    //   386: getstatic com/google/android/gms/internal/cs.iI : Landroid/os/Handler;
    //   389: new com/google/android/gms/internal/bv$2
    //   392: dup
    //   393: aload_0
    //   394: aload #6
    //   396: invokespecial <init> : (Lcom/google/android/gms/internal/bv;Lcom/google/android/gms/internal/cj;)V
    //   399: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   402: pop
    //   403: aload #11
    //   405: monitorexit
    //   406: return
    //   407: aload #10
    //   409: monitorexit
    //   410: aload #8
    //   412: astore #7
    //   414: aload_0
    //   415: lload_3
    //   416: invokespecial c : (J)V
    //   419: aload #8
    //   421: astore #7
    //   423: aload_0
    //   424: invokespecial aj : ()V
    //   427: aload #8
    //   429: astore #7
    //   431: aload #9
    //   433: getfield em : Lcom/google/android/gms/internal/x;
    //   436: getfield eH : [Lcom/google/android/gms/internal/x;
    //   439: ifnull -> 454
    //   442: aload #8
    //   444: astore #7
    //   446: aload_0
    //   447: aload #9
    //   449: invokespecial a : (Lcom/google/android/gms/internal/bz;)Lcom/google/android/gms/internal/x;
    //   452: astore #6
    //   454: aload #6
    //   456: astore #7
    //   458: aload_0
    //   459: getfield hg : Lcom/google/android/gms/internal/cb;
    //   462: getfield hy : Z
    //   465: ifeq -> 482
    //   468: aload #6
    //   470: astore #7
    //   472: aload_0
    //   473: aload #9
    //   475: lload_3
    //   476: invokespecial a : (Lcom/google/android/gms/internal/bz;J)V
    //   479: goto -> 537
    //   482: aload #6
    //   484: astore #7
    //   486: aload_0
    //   487: lload_3
    //   488: invokespecial b : (J)V
    //   491: goto -> 537
    //   494: astore #6
    //   496: aload #11
    //   498: monitorexit
    //   499: aload #6
    //   501: athrow
    //   502: aload #6
    //   504: invokevirtual getMessage : ()Ljava/lang/String;
    //   507: invokestatic v : (Ljava/lang/String;)V
    //   510: goto -> 161
    //   513: aconst_null
    //   514: astore #7
    //   516: goto -> 280
    //   519: aconst_null
    //   520: astore #8
    //   522: goto -> 296
    //   525: aconst_null
    //   526: astore #9
    //   528: goto -> 312
    //   531: aconst_null
    //   532: astore #10
    //   534: goto -> 334
    //   537: goto -> 192
    // Exception table:
    //   from	to	target	type
    //   9	48	494	finally
    //   61	65	135	com/google/android/gms/internal/bv$a
    //   61	65	494	finally
    //   69	81	135	com/google/android/gms/internal/bv$a
    //   69	81	494	finally
    //   85	91	135	com/google/android/gms/internal/bv$a
    //   85	91	494	finally
    //   95	98	135	com/google/android/gms/internal/bv$a
    //   95	98	494	finally
    //   98	123	123	finally
    //   125	128	123	finally
    //   132	135	135	com/google/android/gms/internal/bv$a
    //   132	135	494	finally
    //   137	143	494	finally
    //   153	161	494	finally
    //   161	188	494	finally
    //   192	280	494	finally
    //   280	296	494	finally
    //   296	312	494	finally
    //   312	334	494	finally
    //   334	406	494	finally
    //   407	410	123	finally
    //   414	419	135	com/google/android/gms/internal/bv$a
    //   414	419	494	finally
    //   423	427	135	com/google/android/gms/internal/bv$a
    //   423	427	494	finally
    //   431	442	135	com/google/android/gms/internal/bv$a
    //   431	442	494	finally
    //   446	454	135	com/google/android/gms/internal/bv$a
    //   446	454	494	finally
    //   458	468	135	com/google/android/gms/internal/bv$a
    //   458	468	494	finally
    //   472	479	135	com/google/android/gms/internal/bv$a
    //   472	479	494	finally
    //   486	491	135	com/google/android/gms/internal/bv$a
    //   486	491	494	finally
    //   496	499	494	finally
    //   502	510	494	finally
  }
  
  public void onStop() {
    synchronized (this.hc) {
      if (this.hf != null)
        this.hf.cancel(); 
      this.gv.stopLoading();
      co.a(this.gv);
      if (this.hi != null)
        this.hi.cancel(); 
      return;
    } 
  }
  
  private static final class a extends Exception {
    private final int hm;
    
    public a(String param1String, int param1Int) {
      super(param1String);
      this.hm = param1Int;
    }
    
    public int getErrorCode() {
      return this.hm;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */