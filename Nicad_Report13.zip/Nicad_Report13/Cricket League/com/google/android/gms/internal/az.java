package com.google.android.gms.internal;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class az {
  public static List<String> a(JSONObject paramJSONObject, String paramString) throws JSONException {
    JSONArray jSONArray = paramJSONObject.optJSONArray(paramString);
    if (jSONArray != null) {
      ArrayList<String> arrayList = new ArrayList(jSONArray.length());
      for (int i = 0; i < jSONArray.length(); i++)
        arrayList.add(jSONArray.getString(i)); 
      return Collections.unmodifiableList(arrayList);
    } 
    return null;
  }
  
  public static void a(Context paramContext, String paramString1, cj paramcj, String paramString2, boolean paramBoolean, List<String> paramList) {
    String str;
    if (paramBoolean) {
      str = "1";
    } else {
      str = "0";
    } 
    Iterator<String> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      String str2 = ((String)iterator.next()).replaceAll("@gw_adlocid@", paramString2).replaceAll("@gw_adnetrefresh@", str).replaceAll("@gw_qdata@", paramcj.is.fN).replaceAll("@gw_sdkver@", paramString1).replaceAll("@gw_sessid@", ck.iu).replaceAll("@gw_seqnum@", paramcj.hu);
      String str1 = str2;
      if (paramcj.gb != null)
        str1 = str2.replaceAll("@gw_adnetid@", paramcj.gb.fD).replaceAll("@gw_allocid@", paramcj.gb.fF); 
      (new cr(paramContext, paramString1, str1)).start();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */