package com.google.android.gms.internal;

import org.json.JSONObject;

public interface dn {
  void a(long paramLong, int paramInt, JSONObject paramJSONObject);
  
  void g(long paramLong);
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\dn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */