package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient;

public final class da extends cy {
  public da(cw paramcw) {
    super(paramcw);
  }
  
  public void onShowCustomView(View paramView, int paramInt, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
    a(paramView, paramInt, paramCustomViewCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\da.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */