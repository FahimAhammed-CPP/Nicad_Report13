package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;

public final class bp extends FrameLayout implements View.OnClickListener {
  private final ImageButton gZ;
  
  private final Activity gs;
  
  public bp(Activity paramActivity, int paramInt) {
    super((Context)paramActivity);
    this.gs = paramActivity;
    setOnClickListener(this);
    this.gZ = new ImageButton((Context)paramActivity);
    this.gZ.setImageResource(17301527);
    this.gZ.setBackgroundColor(0);
    this.gZ.setOnClickListener(this);
    this.gZ.setPadding(0, 0, 0, 0);
    paramInt = cs.a((Context)paramActivity, paramInt);
    addView((View)this.gZ, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(paramInt, paramInt, 17));
  }
  
  public void g(boolean paramBoolean) {
    boolean bool;
    ImageButton imageButton = this.gZ;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    imageButton.setVisibility(bool);
  }
  
  public void onClick(View paramView) {
    this.gs.finish();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Cricket Cup-dex2jar.jar!\com\google\android\gms\internal\bp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */